# run_latency.py - 仅启动「端到端耗时分析」页的独立窗口（与其它 Tab 隔离）
# 用法:  python run_latency.py
# 适合: 分析长录音时会占用较多 CPU/内存；单独进程可随时关闭，
#       不会影响/拖慢主工具其余页面。
import os
import sys

_APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _APP_DIR)
os.chdir(_APP_DIR)

from PyQt5.QtWidgets import QApplication, QMainWindow  # noqa: E402


def main():
    from ui.latency_page import LatencyPage  # noqa: E402
    app = QApplication(sys.argv)
    win = QMainWindow()
    win.setWindowTitle("NOMI 端到端耗时分析（独立窗口）")
    page = LatencyPage()
    win.setCentralWidget(page)
    try:
        scr = app.primaryScreen()
        geo = scr.availableGeometry()
        win.resize(min(1160, geo.width() - 60),
                   min(780, geo.height() - 80))
    except Exception:
        win.resize(1080, 700)
    win.show()
    rc = app.exec_()
    page.shutdown()
    sys.exit(rc)


if __name__ == "__main__":
    main()
