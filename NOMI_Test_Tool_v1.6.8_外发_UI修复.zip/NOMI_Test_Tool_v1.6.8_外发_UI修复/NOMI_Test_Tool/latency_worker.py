# latency_worker.py - 桌面「响应时延」分析子进程（v1.6.6）
#
# 由 ui/latency_page.AnalyzeWorker 以 subprocess 方式调用，避免在同一
# GUI 进程里 import PyQt 后加载 faster-whisper/ctranslate2（本机 3.12
# 环境 PyQt 与 ctranslate2 存在 DLL 冲突，同进程会 native crash/闪退）。
#
# 用法: python latency_worker.py <args.json> <result.json> [env.npy]
#   - 进度逐行输出到 stdout（父进程实时显示到状态栏/日志）
#   - result.json: rows/results/units/cal_* （UI 表格与 Excel 用）
#   - env.npy(可选): 波形包络数组 (times, envelope)，供「手动定位」绘图
import json
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def main():
    if len(sys.argv) < 3:
        print("[参数不足] 需要 args.json result.json [env.npy]", flush=True)
        return 2
    args_path, result_path = sys.argv[1], sys.argv[2]
    env_path = sys.argv[3] if len(sys.argv) > 3 else ""
    try:
        with open(args_path, "r", encoding="utf-8") as f:
            p = json.load(f)
    except Exception as e:                       # noqa: BLE001
        print(f"[参数读取失败] {e}", flush=True)
        return 2

    from core.latency_analyze import AnalyzeArgs, run_analysis

    def emit(msg):
        print(msg, flush=True)

    args = AnalyzeArgs(
        media_path=p.get("media_path", ""),
        template_path=p.get("template_path", ""),
        model_name=p.get("model_name", "base"),
        language=p.get("language", "auto"),
        wake_path=p.get("wake_path", ""),
        wake_text=p.get("wake_text", ""),
        use_cal=True,
        gap_ms=int(p.get("gap_ms") or 150))
    try:
        r = run_analysis(args, emit=emit)
    except Exception as e:                       # noqa: BLE001
        print(f"[分析失败] {e}", flush=True)
        return 3
    out = {
        "ok": True,
        "rows": _jsonable(r.rows),
        "results": _jsonable(r.results),
        "units": _jsonable(r.units),
        "cal_s": float(r.cal_s or 0.0),
        "cal_score": float(r.cal_score or 0.0),
        "sr": int(r.sr or 0),
        "media_path": p.get("media_path", ""),
        "template_path": p.get("template_path", ""),
    }
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    if env_path and r.env_t is not None and r.env_v is not None:
        try:
            import numpy as np
            np.savez_compressed(env_path, t=np.asarray(r.env_t),
                                v=np.asarray(r.env_v))
        except Exception:                        # noqa: BLE001
            pass
    print("[分析完成]", flush=True)
    return 0


def _jsonable(obj):
    import numpy as np

    def conv(o):
        if isinstance(o, dict):
            return {k: conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, float):
            return None if o != o else o
        return o
    return conv(obj)


if __name__ == "__main__":
    sys.exit(main())
