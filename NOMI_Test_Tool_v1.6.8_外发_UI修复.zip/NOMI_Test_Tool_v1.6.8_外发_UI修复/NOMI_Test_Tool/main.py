# main.py - NOMI 自动化测试工具入口
# 全局崩溃捕获: 未捕获异常 / 段错误均写入工具目录 crash.log，便于定位闪退
import sys
import os
import threading
import traceback
import atexit
from datetime import datetime

from PyQt5.QtWidgets import QApplication, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core import app_log  # noqa: E402

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CRASH_LOG = os.path.join(APP_DIR, "crash.log")


def _write_crash(kind: str, detail: str):
    """崩溃信息写入 crash.log（所有异常都吞掉，绝不让崩溃处理器再崩）"""
    try:
        with open(CRASH_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {kind}\n")
            f.write(detail.rstrip() + "\n")
    except Exception:
        pass


def _sys_excepthook(exc_type, exc_value, exc_tb):
    """未捕获 Python 异常: 记录 + 弹窗提示（不静默闪退）"""
    detail = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    _write_crash("未捕获异常", detail)
    try:
        QMessageBox.critical(
            None, "程序异常",
            f"发生未处理的异常，已记录到:\n{CRASH_LOG}\n\n{str(exc_value)[:400]}\n\n"
            "点击 OK 后程序将退出。")
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


def _thread_excepthook(args):
    """线程内未捕获异常（threading.excepthook，Python 3.8+）"""
    detail = "".join(traceback.format_exception(
        args.exc_type, args.exc_value, args.exc_tb))
    _write_crash(f"线程异常 ({args.name})", detail)


def install_crash_handlers():
    """安装全局崩溃捕获"""
    sys.excepthook = _sys_excepthook
    if hasattr(sys, "unraisablehook"):  # Python 3.8+: 无法回收的对象等
        def _unraisable(args):
            _write_crash("unraisable", str(getattr(args, "exc_value", "")))
        sys.unraisablehook = _unraisable
    if hasattr(threading, "excepthook"):
        threading.excepthook = _thread_excepthook
    # faulthandler 捕获 C 层段错误/死锁（Qt 底层崩溃时写崩溃栈到 crash.log）
    try:
        import faulthandler
        _fh = open(CRASH_LOG, "a", encoding="utf-8")
        _fh.write(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 程序启动\n")
        _fh.flush()
        faulthandler.enable(file=_fh, all_threads=True)
    except Exception:
        pass


# ===== 建立会话运行日志 =====
# 在导入任何重量级 UI 模块前初始化，确保从 python main.py 起的所有输出
# （控制台 print / 各 Tab 过程 / 命令执行）都归档到同目录 运行日志 文件夹。
app_log.init_log(APP_DIR)
app_log.log("系统", f"启动流程: main.py 加载完成 (APP_DIR={APP_DIR})")
atexit.register(app_log.close_log)


from ui.main_window import MainWindow, APP_VERSION  # noqa: E402

app_log.log("系统", f"工具版本: {APP_VERSION}")


def main():
    # 启用高 DPI 缩放，让字体在 Windows 下不模糊
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    install_crash_handlers()

    # v1.6.8: 可选硬件加速（对应“本地 UI 不如浏览器流畅”）。
    # 默认保持 Qt 自带渲染，兼容远程桌面/虚拟机；确需更强流畅度时
    # 在启动前设置环境变量 NOMI_OPENGL=1（见 run 说明）。
    if os.environ.get("NOMI_OPENGL") == "1":
        try:
            os.environ["QT_OPENGL"] = "desktop"
            QApplication.setAttribute(Qt.AA_UseDesktopOpenGL, True)
            app_log.log("系统", "已开启 OpenGL Desktop 渲染后端(NOMI_OPENGL=1)")
        except Exception:
            pass

    app = QApplication(sys.argv)

    # 全局字体：微软雅黑，Windows 下最清晰
    font = QFont("Microsoft YaHei", 9)
    app.setFont(font)

    window = MainWindow()
    window.show()
    app_log.log("系统", "主界面已显示，等待操作")

    rc = app.exec_()
    app_log.log("系统", f"主事件循环退出 (返回码 {rc})")
    app_log.close_log()
    sys.exit(rc)


if __name__ == "__main__":
    main()
