# ui/theme.py
# v1.6.6 深色主题：完整镜像浏览器 UI（webapp/static/index.html 调色板）
#
#   浏览器 :root       桌面等价
#   --bg  #0f1115   -> 窗口/页面底色
#   --card #181b22  -> 卡片（QGroupBox/QTab 选中底）
#   --line #262b36  -> 分隔线/边框
#   --tx  #e8eaee   -> 主文本
#   --mut #9aa3b2   -> 次要文本
#   --acc #3b82f6   -> 主蓝（选中 Tab / 主要按钮 / 焦点）
#   --ok  #22c55e / --warn #f59e0b / --err #ef4444
from string import Template

from PyQt5.QtGui import QColor, QPalette

PALETTE = {
    # 语义色（与浏览器一致）
    "bg":       "#0e1219",   # 页面底色
    "card":     "#171c26",   # 卡片底
    "line":     "#2a3242",   # 边框/分隔线
    "tx":       "#e7ebf2",   # 主文本
    "mut":      "#9aa6b8",   # 次要文本
    "accent":   "#3b82f6",   # 主蓝
    "accent_hi": "#5b9dff",  # 主蓝 hover（更亮）
    "link":     "#60a5fa",   # 深底上的链接蓝
    "ok":       "#22c55e",   # 绿
    "ok_hi":    "#2fd06b",   # 绿 hover
    "warn":     "#f59e0b",   # 橙/黄
    "err":      "#ef4444",   # 红
    # 控件专用（浏览器 input 底 #0d1016 / 选中行 #16233f）
    "inp":      "#10141d",
    "sel":      "#1b2a4c",
    "btn_hover": "#27303e",
    "disabled": "#66717f",
    # 滚动条
    "handle":   "#3d4656",
    "handle_h": "#535e70",
    # 日志区（浏览器 pre.log: 底 #0a0d12 字 #c9d4e3）
    "log_bg":   "#0b0f15",
    "log_tx":   "#cbd6e6",
    # 状态徽标底（浏览器 .tag）
    "tag_ok_bg":   "#0e3a24",
    "tag_warn_bg": "#3a3010",
    "tag_err_bg":  "#3a1620",
}

_QSS_TEMPLATE = r"""
QMainWindow { background-color: $bg; }
QDialog    { background-color: $bg; }
QWidget    { font-family: "Microsoft YaHei"; color: $tx; font-size: 13px; }

/* ===== Tab（浏览器 nav 胶囊按钮） ===== */
QTabWidget { background-color: $bg; }
QTabBar    { background-color: $bg; }
QTabWidget::pane {
    border: 1px solid $line;
    border-radius: 14px;
    background-color: $bg;
}
QTabBar::tab {
    background: transparent;
    border: 1px solid $line;
    border-radius: 10px;
    padding: 8px 18px;
    margin: 10px 4px 10px 0;
    color: $mut;
    font-weight: 600;
}
QTabBar::tab:selected {
    background-color: $accent;
    border-color: $accent;
    color: #ffffff;
}
QTabBar::tab:hover:!selected {
    background-color: $btn_hover;
    color: $tx;
}

/* ===== 按钮（未内联着色的自动成 ghost 风格） ===== */
QPushButton {
    background: transparent;
    border: 1px solid $line;
    border-radius: 10px;
    padding: 7px 15px;
    color: $tx;
}
QPushButton:hover { background-color: $btn_hover; border-color: #3a4659; }
QPushButton:pressed { background-color: $sel; }
QPushButton:disabled { color: $disabled; border-color: $line; background: transparent; }

/* ===== 输入控件 ===== */
QLineEdit, QComboBox, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox {
    background-color: $inp;
    border: 1px solid $line;
    border-radius: 10px;
    padding: 6px 9px;
    color: $tx;
    selection-background-color: $accent;
    selection-color: #ffffff;
}
QLineEdit:focus, QComboBox:focus, QTextEdit:focus, QPlainTextEdit:focus,
QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid $accent; }
QLineEdit:disabled, QComboBox:disabled, QTextEdit:disabled {
    color: $disabled; background-color: #12151c;
}
QComboBox::drop-down { border: none; width: 24px; }
QComboBox QAbstractItemView {
    background-color: $card;
    border: 1px solid $line;
    border-radius: 10px;
    selection-background-color: $accent;
    selection-color: #ffffff;
}

/* ===== 卡片容器（QGroupBox ≈ 浏览器 .card） ===== */
QGroupBox {
    background-color: $card;
    border: 1px solid $line;
    border-radius: 14px;
    margin-top: 14px;
    padding-top: 8px;
    font-weight: bold;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 14px;
    top: 4px;
    padding: 0 6px;
    color: $tx;
    background: transparent;
}

/* ===== 复选框 / 单选 ===== */
QCheckBox, QRadioButton { spacing: 6px; }
QCheckBox::indicator, QRadioButton::indicator {
    width: 15px; height: 15px;
    border: 1px solid $line;
    background-color: $inp;
}
QCheckBox::indicator { border-radius: 5px; }
QRadioButton::indicator { border-radius: 10px; }
QCheckBox::indicator:checked, QRadioButton::indicator:checked {
    background-color: $accent;
    border-color: $accent;
}

/* ===== 列表 / 表格 ===== */
QListWidget, QListView, QTableView, QTableWidget {
    background-color: $inp;
    alternate-background-color: #12151c;
    border: 1px solid $line;
    border-radius: 10px;
    color: $tx;
    gridline-color: $line;
    selection-background-color: $sel;
    selection-color: $tx;
}
QTableWidget::item { padding: 2px 4px; }
QHeaderView::section {
    background-color: $card;
    color: $mut;
    border: none;
    border-bottom: 1px solid $line;
    padding: 6px 9px;
    font-weight: 600;
}
QTableCornerButton::section { background-color: $card; border: none; }

/* ===== 滚动条 ===== */
QScrollBar:vertical {
    background: transparent; width: 10px; margin: 2px;
}
QScrollBar::handle:vertical {
    background: $handle; border-radius: 5px; min-height: 30px;
}
QScrollBar::handle:vertical:hover { background: $handle_h; }
QScrollBar:horizontal {
    background: transparent; height: 10px; margin: 2px;
}
QScrollBar::handle:horizontal {
    background: $handle; border-radius: 5px; min-width: 30px;
}
QScrollBar::handle:horizontal:hover { background: $handle_h; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }

/* ===== 进度条 ===== */
QProgressBar {
    border: 1px solid $line;
    border-radius: 9px;
    background-color: $inp;
    text-align: center;
    color: $tx;
    font-weight: bold;
}
QProgressBar::chunk {
    background-color: $accent;
    border-radius: 6px;
}

/* ===== 分隔 / 滚动区 / 提示 ===== */
QSplitter::handle { background-color: $line; }
QScrollArea { border: none; background: transparent; }
QToolTip {
    background-color: $card;
    color: $tx;
    border: 1px solid $line;
    padding: 4px 8px;
}
QStatusBar {
    background-color: $bg;
    color: $mut;
    border-top: 1px solid $line;
}
QStatusBar::item { border: none; }
QStatusBar QLabel { color: $mut; }

/* ===== 菜单（右键/输入框上下文） ===== */
QMenu {
    background-color: $card;
    border: 1px solid $line;
    border-radius: 10px;
}
QMenu::item { padding: 6px 24px; color: $tx; }
QMenu::item:selected { background-color: $sel; }
"""

GLOBAL_QSS = Template(_QSS_TEMPLATE).safe_substitute(PALETTE)


def apply_dark_theme(app) -> None:
    """把深色主题应用到 QApplication。

    QSS 对自定义 QWidget 容器不会自动上底色（需 WA_StyledBackground），
    因此再套一层 Fusion + 深色 QPalette，确保所有未显式着色的区域
    （页面根、对话框、列表默认底等）统一为深色。
    """
    if app is None:
        return
    try:
        app.setStyle("Fusion")
    except Exception:
        pass
    c = QPalette()
    c.setColor(QPalette.Window, QColor(PALETTE["bg"]))
    c.setColor(QPalette.WindowText, QColor(PALETTE["tx"]))
    c.setColor(QPalette.Base, QColor(PALETTE["inp"]))
    c.setColor(QPalette.AlternateBase, QColor("#141a26"))
    c.setColor(QPalette.ToolTipBase, QColor(PALETTE["card"]))
    c.setColor(QPalette.ToolTipText, QColor(PALETTE["tx"]))
    c.setColor(QPalette.Text, QColor(PALETTE["tx"]))
    c.setColor(QPalette.PlaceholderText, QColor(PALETTE["mut"]))
    c.setColor(QPalette.Button, QColor(PALETTE["card"]))
    c.setColor(QPalette.ButtonText, QColor(PALETTE["tx"]))
    c.setColor(QPalette.BrightText, QColor(PALETTE["err"]))
    c.setColor(QPalette.Link, QColor(PALETTE["link"]))
    c.setColor(QPalette.Highlight, QColor(PALETTE["accent"]))
    c.setColor(QPalette.HighlightedText, QColor("#ffffff"))
    c.setColor(QPalette.Disabled, QPalette.WindowText, QColor(PALETTE["disabled"]))
    c.setColor(QPalette.Disabled, QPalette.Text, QColor(PALETTE["disabled"]))
    c.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(PALETTE["disabled"]))
    app.setPalette(c)
