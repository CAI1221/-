# ui/main_window.py
# 主窗口：6 Tab（连接设备 / TTS 配置 / 执行测试 / 日志测试 / 端到端耗时 /
#          校准训练）+ 状态栏 + 全局 QSS
from PyQt5.QtWidgets import (QApplication, QLabel, QMainWindow, QStatusBar,
                             QTabWidget)

from ui.connect_page import ConnectPage
from ui.config_page import ConfigPage
from ui.run_page import RunPage
from ui.log_test_page import LogTestPage
from ui.latency_page import LatencyPage
from ui.cal_train_page import CalTrainPage
from ui.theme import GLOBAL_QSS, apply_dark_theme  # noqa: F401  v1.6.6 深色主题
from core import app_log

APP_VERSION = "v1.6.8"


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"NOMI 自动化测试工具 {APP_VERSION}")
        # v1.6.6: 先套 Fusion + 深色调色板，再上 QSS，
        # 保证自定义 QWidget 页面容器等未显式着色的区域也是深色
        apply_dark_theme(QApplication.instance())
        # v1.6.3: 不再写死 1220x820。按屏幕可用区自动适配，
        # 避免小屏/高 DPI 下按钮超出屏幕（用户需缩放才能看到）。
        self._fit_to_screen()
        self._first_show = True

        self.setStyleSheet(GLOBAL_QSS)

        self.tab_widget = QTabWidget()
        self.setCentralWidget(self.tab_widget)

        # 创建页面
        self.connect_page = ConnectPage()
        self.config_page = ConfigPage()
        self.run_page = RunPage()
        self.log_test_page = LogTestPage()
        self.latency_page = LatencyPage()
        self.cal_train_page = CalTrainPage()

        # 添加 Tab（6 个）
        self.tab_widget.addTab(self.connect_page, "连接设备")
        self.tab_widget.addTab(self.config_page, "TTS 配置")
        self.tab_widget.addTab(self.run_page, "执行测试")
        self.tab_widget.addTab(self.log_test_page, "日志测试")
        self.tab_widget.addTab(self.latency_page, "端到端耗时")
        self.tab_widget.addTab(self.cal_train_page, "校准训练")

        # 状态栏
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("就绪 | 请先连接设备并配置 TTS")

        self.status_label = QLabel("  未连接")
        self.status_bar.addPermanentWidget(self.status_label)

        # 连接信号
        # ConnectPage 状态变化 -> 更新主窗口状态栏
        self.connect_page.status_changed.connect(self.update_status)
        # 切换到执行页时刷新输出根目录 / MEM 脚本显示
        self.tab_widget.currentChanged.connect(self.on_tab_changed)

    def on_tab_changed(self, index):
        """切换 Tab 时的回调"""
        tab_text = self.tab_widget.tabText(index)
        app_log.log("页面", f"切换到 Tab: {tab_text}")
        if "执行" in tab_text:
            self.run_page.refresh_status()
        elif "日志" in tab_text:
            # 切到日志测试页: 刷新 scrcpy 探测 + 语音音频状态
            self.log_test_page.refresh_status()

    def update_status(self, adb_ok=False, ssh_ok=False):
        if adb_ok and ssh_ok:
            self.status_label.setText("  已连接 (ADB + SSH)")
            self.status_bar.showMessage("设备已就绪，可以开始测试")
            state = "已连接 (ADB + SSH)"
        elif adb_ok:
            self.status_label.setText("  ADB 已连，SSH 未连")
            self.status_bar.showMessage("ADB 已连接，请检查 SSH 隧道")
            state = "ADB 已连，SSH 未连"
        elif ssh_ok:
            self.status_label.setText("  SSH 已连，ADB 未连")
            self.status_bar.showMessage("SSH 已连接，请检查 ADB")
            state = "SSH 已连，ADB 未连"
        else:
            self.status_label.setText("  未连接")
            self.status_bar.showMessage("请连接设备")
            state = "未连接"
        app_log.log("状态", f"设备状态: {state}")

    def _fit_to_screen(self):
        """按主屏可用区自适应窗口大小并居中（小屏/高 DPI 不再截断按钮）"""
        try:
            from PyQt5.QtWidgets import QApplication
            screen = QApplication.primaryScreen()
            geo = screen.availableGeometry() if screen else None
            if geo is None or geo.width() < 400:
                self.resize(1100, 700)
                return
            w = min(1220, geo.width() - 60)
            h = min(820, geo.height() - 80)
            w = max(880, w)
            h = max(560, h)
            self.resize(w, h)
            self.move(geo.x() + (geo.width() - w) // 2,
                      geo.y() + max(0, (geo.height() - h) // 2 - 8))
        except Exception:
            self.resize(1100, 700)

    def showEvent(self, event):
        super().showEvent(event)
        if getattr(self, "_first_show", True):
            self._first_show = False
            self._fit_to_screen()      # 高分屏下首次显示时再次收敛到可用区

    def closeEvent(self, event):
        if hasattr(self, 'connect_page'):
            self.connect_page.closeEvent(event)
        if hasattr(self, 'config_page'):
            self.config_page.shutdown()
        if hasattr(self, 'run_page'):
            self.run_page.closeEvent(event)
        if hasattr(self, 'log_test_page'):
            self.log_test_page.closeEvent(event)
        if hasattr(self, 'latency_page'):
            self.latency_page.shutdown()
        if hasattr(self, 'cal_train_page'):
            self.cal_train_page.shutdown()
        # 退出时统一关闭所有自动建立的 SSH 隧道
        try:
            from core.tunnel_manager import shared_manager
            shared_manager().stop_all()
        except Exception:
            pass
        event.accept()
