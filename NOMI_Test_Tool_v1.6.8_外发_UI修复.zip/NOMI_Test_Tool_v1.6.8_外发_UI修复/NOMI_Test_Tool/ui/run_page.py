# ui/run_page.py
# 执行测试页：版本/PID 填写 + 场景勾选 + 一键执行 + 实时日志
# 布局: QSplitter 上下分区，上半配置(可滚动) / 下半进度+日志(可拖动调高度)
import json
import os
from datetime import datetime

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog,
                             QDialogButtonBox, QGridLayout, QGroupBox,
                             QHBoxLayout, QLabel, QLineEdit, QListWidget,
                             QMessageBox, QProgressBar, QPushButton,
                             QScrollArea, QSplitter, QVBoxLayout, QWidget)

from core.constants import (CAR_WAKEUP_WORDS, COLLECT_SECONDS, DIR_AUDIO,
                            INTERACTIVE_SCENARIOS, INTERVAL_SECONDS,
                            SCENARIOS, SCENARIO_KEYS,
                            QNX_VERSION_CMD, QNX_SPEECH_PID_PS_CMD,
                            QNX_SPEECH_PID_PIDIN_CMD)
from core.executors import AdbExecutor, LocalExecutor
from core.parsers import (parse_artifact_version, parse_speech_pids_ps,
                          parse_speech_pids_pidin)
from core.ssh_executor import SSHClientWrapper
from core.test_engine import TestConfig, TestEngine, find_audio_file
from core.tts import synth_one, tts_available
from ui.log_widget import LogPane

# 文件名非法字符（Windows）
_BAD_CHARS = '\\/:*?"<>|'

# 运行中的引擎线程兜底引用：防止页面销毁时 QThread 被回收导致进程闪退
_KEEP_ALIVE = []


class FetchLongVersionThread(QThread):
    """后台获取车机长版本（nio/version.txt 的 Artifact 字段）"""
    done = pyqtSignal(bool, str)

    def __init__(self, ssh_cfg):
        super().__init__()
        self.ssh_cfg = ssh_cfg

    def run(self):
        ssh = SSHClientWrapper()
        ssh.configure(self.ssh_cfg["ssh_host"], self.ssh_cfg["ssh_user"],
                      self.ssh_cfg["ssh_password"])
        try:
            ssh.connect(timeout=10)
            ok, out = ssh.exec(QNX_VERSION_CMD, timeout=10)
            if ok and out:
                version = parse_artifact_version(out)
                if version:
                    self.done.emit(True, version)
                    return
                self.done.emit(False,
                               "version.txt 中未找到 Artifact 字段:\n"
                               + (out.strip()[:200] or "(空输出)"))
            else:
                self.done.emit(False, out or "版本文件无输出")
        except Exception as e:
            self.done.emit(False, str(e))
        finally:
            ssh.close()


class FetchSpeechPidThread(QThread):
    """后台查询 speech-service PID（双命令兜底）
    首选: /etc/profile 环境下 ps -A（/nio/bin 的 ps，进程级输出干净）
    兜底: pidin（QNX 原生，线程级输出，按 PID 去重）
    """
    done = pyqtSignal(bool, str, list)  # ok, msg, pid 列表

    def __init__(self, ssh_cfg):
        super().__init__()
        self.ssh_cfg = ssh_cfg

    def run(self):
        ssh = SSHClientWrapper()
        ssh.configure(self.ssh_cfg["ssh_host"], self.ssh_cfg["ssh_user"],
                      self.ssh_cfg["ssh_password"])
        try:
            ssh.connect(timeout=10)
            # 命令 1: ps -A（进程级，首选）
            ok, out = ssh.exec(QNX_SPEECH_PID_PS_CMD, timeout=10)
            if ok and out:
                pids = parse_speech_pids_ps(out)
                if pids:
                    self.done.emit(True, "ps -A", pids)
                    return
            # 命令 2: pidin（线程级兜底，按 PID 去重）
            ok, out = ssh.exec(QNX_SPEECH_PID_PIDIN_CMD, timeout=10)
            if ok and out:
                pids = parse_speech_pids_pidin(out)
                if pids:
                    self.done.emit(True, "pidin", pids)
                    return
            self.done.emit(False, "ps/pidin 均未找到 speech-service 进程\n"
                            f"ps 输出: {(out or '')[:150]}", [])
        except Exception as e:
            self.done.emit(False, str(e), [])
        finally:
            ssh.close()


class PIDSelectionDialog(QDialog):
    """PID 选择弹窗"""

    def __init__(self, pid_list, title="选择 PID"):
        super().__init__()
        self.setWindowTitle(title)
        self.setModal(True)
        self.resize(380, 260)
        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()
        for pid in pid_list:
            self.list_widget.addItem(pid)
        if pid_list:
            self.list_widget.setCurrentRow(0)
        layout.addWidget(self.list_widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_selected(self):
        item = self.list_widget.currentItem()
        return item.text() if item else None


class RunPage(QWidget):
    """执行测试页"""

    def __init__(self):
        super().__init__()
        self.engine = None
        self.fetch_v_thread = None
        self.fetch_pid_thread = None
        self.session_dir = None
        self.splitter = None
        self.log_pane = None
        self.init_ui()

    # ==================== 主窗口引用 ====================
    def _main(self):
        w = self.window()
        return w if hasattr(w, "connect_page") else None

    def get_output_root(self):
        main = self._main()
        if main and hasattr(main, "config_page"):
            return main.config_page.output_root
        return os.path.join(os.path.expanduser("~"), "NOMI_Test_Data")

    def get_ssh_config(self):
        main = self._main()
        if main and hasattr(main, "connect_page"):
            cfg = main.connect_page.get_platform_config()
            return {
                "ssh_host": cfg.get("qnx_host", "192.0.2.2"),
                "ssh_user": cfg.get("qnx_user", "root"),
                "ssh_password": cfg.get("qnx_password", "CHANGE_ME"),
            }
        return {"ssh_host": "192.0.2.2", "ssh_user": "root",
                "ssh_password": "CHANGE_ME"}

    def get_queries(self):
        config_file = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "config.json")
        if os.path.exists(config_file):
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    return json.load(f).get("queries", {})
            except Exception:
                pass
        return {}

    # ==================== UI ====================
    def init_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        splitter = QSplitter()
        splitter.setOrientation(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        self.splitter = splitter

        # ---------- 上半: 配置区(可滚动) ----------
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: #0f1115; }")

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setSpacing(6)
        layout.setContentsMargins(8, 8, 8, 8)

        # ---- 基本信息 ----
        info_group = QGroupBox("基本信息")
        info_group.setStyleSheet(
            "QGroupBox { padding-top: 14px; } QGroupBox::title { subcontrol-origin: margin; left: 8px; }")
        g = QGridLayout(info_group)
        g.setVerticalSpacing(6)
        g.setHorizontalSpacing(6)

        g.addWidget(QLabel("车型:"), 0, 0)
        self.car_combo = QComboBox()
        self.car_combo.addItems(list(CAR_WAKEUP_WORDS.keys()))
        self.car_combo.currentTextChanged.connect(self.on_car_changed)
        g.addWidget(self.car_combo, 0, 1)
        g.addWidget(QLabel("唤醒词:"), 0, 2)
        self.wakeup_label = QLabel()
        self.wakeup_label.setStyleSheet("font-weight: bold; color: #3b82f6;")
        g.addWidget(self.wakeup_label, 0, 3)

        g.addWidget(QLabel("版本号 *:"), 1, 0)
        self.short_version_edit = QLineEdit()
        self.short_version_edit.setPlaceholderText("必填，如 NT3.0-160-daily")
        g.addWidget(self.short_version_edit, 1, 1)
        g.addWidget(QLabel("车机长版本:"), 1, 2)
        lv_h = QHBoxLayout()
        self.long_version_edit = QLineEdit()
        self.long_version_edit.setPlaceholderText("点「获取」自动填写")
        self.long_version_edit.setStyleSheet("background-color: #0d1016;")
        lv_h.addWidget(self.long_version_edit, 1)
        self.fetch_version_btn = QPushButton("获取")
        self.fetch_version_btn.setFixedWidth(52)
        self.fetch_version_btn.clicked.connect(self.fetch_long_version)
        lv_h.addWidget(self.fetch_version_btn)
        g.addLayout(lv_h, 1, 3)

        self.nomi_pid_label = QLabel("NOMI PID:")
        g.addWidget(self.nomi_pid_label, 2, 0)
        np_h = QHBoxLayout()
        self.nomi_pid_edit = QLineEdit()
        self.nomi_pid_edit.setPlaceholderText("showmap 用，静置场景必填")
        np_h.addWidget(self.nomi_pid_edit, 1)
        self.nomi_query_btn = QPushButton("查询")
        self.nomi_query_btn.setFixedWidth(52)
        self.nomi_query_btn.clicked.connect(self.query_nomi_pid)
        np_h.addWidget(self.nomi_query_btn)
        g.addLayout(np_h, 2, 1)

        g.addWidget(QLabel("speech PID:"), 2, 2)
        sp_h = QHBoxLayout()
        self.speech_pid_edit = QLineEdit()
        self.speech_pid_edit.setPlaceholderText("top2 用，勾选 top2 必填")
        sp_h.addWidget(self.speech_pid_edit, 1)
        self.speech_query_btn = QPushButton("查询")
        self.speech_query_btn.setFixedWidth(52)
        self.speech_query_btn.clicked.connect(self.query_speech_pid)
        sp_h.addWidget(self.speech_query_btn)
        g.addLayout(sp_h, 2, 3)

        g.addWidget(QLabel("top2 路径:"), 3, 0)
        self.top2_path_edit = QLineEdit()
        self.top2_path_edit.setPlaceholderText(
            "选填，自动探测失败时手填，如 /usr/bin/top2（SSH 登录 QNX 执行 which top2 可查）")
        g.addWidget(self.top2_path_edit, 3, 1, 1, 3)
        layout.addWidget(info_group)

        # ---- 输出位置 ----
        out_group = QGroupBox("输出位置")
        out_group.setStyleSheet(
            "QGroupBox { padding-top: 14px; } QGroupBox::title { subcontrol-origin: margin; left: 8px; }")
        og = QGridLayout(out_group)
        og.setVerticalSpacing(6)
        og.addWidget(QLabel("输出根目录:"), 0, 0)
        self.root_label = QLabel()
        self.root_label.setStyleSheet(
            "font-family: Consolas; font-size: 11px; color: #9aa3b2;")
        og.addWidget(self.root_label, 0, 1)
        og.addWidget(QLabel("总文件夹名:"), 1, 0)
        self.session_name_edit = QLineEdit()
        self.session_name_edit.setPlaceholderText(
            "留空自动生成: 版本号_日期_时间")
        og.addWidget(self.session_name_edit, 1, 1)
        self.mem_script_label = QLabel()
        self.mem_script_label.setStyleSheet("font-size: 11px;")
        og.addWidget(self.mem_script_label, 2, 0, 1, 2)
        layout.addWidget(out_group)

        # ---- 场景 ----
        scene_group = QGroupBox(
            f"测试场景（每场景 {COLLECT_SECONDS} 秒，间隔 {INTERVAL_SECONDS} 秒）")
        scene_group.setStyleSheet(
            "QGroupBox { padding-top: 14px; } QGroupBox::title { subcontrol-origin: margin; left: 8px; }")
        sv = QVBoxLayout(scene_group)
        sv.setSpacing(6)

        sel_h = QHBoxLayout()
        select_all_btn = QPushButton("全选")
        select_all_btn.setFixedWidth(56)
        select_all_btn.clicked.connect(self.select_all)
        deselect_btn = QPushButton("全不选")
        deselect_btn.setFixedWidth(64)
        deselect_btn.clicked.connect(self.deselect_all)
        sel_h.addWidget(select_all_btn)
        sel_h.addWidget(deselect_btn)
        sel_h.addStretch()
        sv.addLayout(sel_h)

        grid = QGridLayout()
        grid.setSpacing(2)
        self.scenario_checks = {}
        cols = 5
        for idx, (key, name) in enumerate(SCENARIOS):
            cb = QCheckBox(name)
            cb.setChecked(True)
            self.scenario_checks[key] = cb
            grid.addWidget(cb, idx // cols, idx % cols)
        sv.addLayout(grid)

        collect_h = QHBoxLayout()
        collect_h.addWidget(QLabel("采集项:"))
        self.mem_cb = QCheckBox("MEM 脚本")
        self.mem_cb.setChecked(True)
        self.cpu_cb = QCheckBox("ADB CPU")
        self.cpu_cb.setChecked(True)
        self.top2_cb = QCheckBox("QNX top2")
        self.top2_cb.setChecked(True)
        self.top2_cb.stateChanged.connect(self.on_top2_toggled)
        collect_h.addWidget(self.mem_cb)
        collect_h.addWidget(self.cpu_cb)
        collect_h.addWidget(self.top2_cb)
        collect_h.addWidget(QLabel(
            "系统日志(slog/logd)结束后不再自动拉取，"
            "需要请到「连接设备」页点「拉取 slog&logd」"))
        collect_h.addStretch()
        sv.addLayout(collect_h)

        b_h = QHBoxLayout()
        self.ab_test_cb = QCheckBox("B 测试（本轮全局跳过 QNX top2 采集）")
        self.ab_test_cb.setToolTip(
            "同一版本做 A/B 对照测试时，B 轮勾选此项：\n"
            "预检与执行阶段全部跳过 top2，无需填写 speech PID")
        self.ab_test_cb.stateChanged.connect(self.on_b_test_toggled)
        b_h.addWidget(self.ab_test_cb)
        b_h.addStretch()
        sv.addLayout(b_h)
        layout.addWidget(scene_group)

        # ---- 控制按钮 ----
        run_h = QHBoxLayout()
        self.start_btn = QPushButton("开始测试")
        self.start_btn.setStyleSheet(
            "background-color: #22c55e; color: white; padding: 7px 22px;"
            " border-radius: 4px; font-weight: bold; font-size: 13px;")
        self.start_btn.clicked.connect(self.start_test)
        run_h.addWidget(self.start_btn)
        self.stop_btn = QPushButton("停止")
        self.stop_btn.setStyleSheet(
            "background-color: #ef4444; color: white; padding: 7px 22px;"
            " border-radius: 4px; font-weight: bold; font-size: 13px;")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_test)
        run_h.addWidget(self.stop_btn)
        self.open_folder_btn = QPushButton("打开产物文件夹")
        self.open_folder_btn.setEnabled(False)
        self.open_folder_btn.clicked.connect(self.open_session_folder)
        run_h.addWidget(self.open_folder_btn)
        run_h.addStretch()
        layout.addLayout(run_h)
        layout.addStretch()

        scroll.setWidget(content)
        splitter.addWidget(scroll)

        # ---------- 下半: 进度 + 日志 ----------
        bottom = QWidget()
        bv = QVBoxLayout(bottom)
        bv.setContentsMargins(8, 4, 8, 8)
        bv.setSpacing(4)
        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.progress.setFormat("%v / %m 场景")
        self.progress.setMaximumHeight(16)
        bv.addWidget(self.progress)
        # 共享日志面板（QPlainTextEdit + 攒批刷新 + 镜像独立窗口）
        self.log_pane = LogPane(
            title="执行日志", tip="拖动上方分隔条调高度，右键调节字体，Ctrl+滚轮快速缩放")
        bv.addWidget(self.log_pane, 1)
        splitter.addWidget(bottom)

        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([420, 300])

        outer.addWidget(splitter)
        self.on_car_changed(self.car_combo.currentText())

    # ==================== 状态刷新 ====================
    def refresh_status(self):
        """切换到本页时刷新显示"""
        self.root_label.setText(self.get_output_root())
        script = os.path.join(self.get_output_root(), "mem_command_nomi.sh")
        if os.path.exists(script):
            self.mem_script_label.setText("MEM 脚本: 已上传")
            self.mem_script_label.setStyleSheet("font-size: 11px; color: #22c55e;")
        else:
            self.mem_script_label.setText("MEM 脚本: 未上传（到「TTS 配置」页上传）")
            self.mem_script_label.setStyleSheet("font-size: 11px; color: #ef4444;")
        # 同步实际生效的唤醒词（TTS 配置页同车型改过自定义词时这里保持一致）
        self.wakeup_label.setText(self._effective_wakeup())

    def on_car_changed(self, car):
        self.wakeup_label.setText(CAR_WAKEUP_WORDS.get(car, ""))
        # ALPS 平台车机助手是"小乐"（com.alps.xiaole），showmap 查询的是小乐进程
        self.nomi_pid_label.setText("小乐 PID:" if car == "ALPS" else "NOMI PID:")
        self.nomi_pid_edit.setPlaceholderText(
            "showmap 用，静置场景必填（{} 进程）".format(
                "小乐 com.alps.xiaole" if car == "ALPS" else "NOMI"))

    def _effective_wakeup(self) -> str:
        """实际生效的唤醒词: 车型默认词；若「TTS 配置」页同车型下改了
        自定义唤醒词，则以配置页的为准（保证音频文件名与播放一致）"""
        word = CAR_WAKEUP_WORDS.get(self.car_combo.currentText(), "")
        main = self._main()
        if main and hasattr(main, "config_page"):
            cp = main.config_page
            if cp.car_combo.currentText() == self.car_combo.currentText():
                cp_word = cp.get_wakeup_word()
                if cp_word:
                    word = cp_word
        return word

    def on_top2_toggled(self):
        # B 测试时 top2 区域整体禁用
        b_test = self.ab_test_cb.isChecked()
        enabled = self.top2_cb.isChecked() and not b_test
        self.speech_pid_edit.setEnabled(enabled)
        self.speech_query_btn.setEnabled(enabled)
        self.top2_path_edit.setEnabled(enabled)

    def on_b_test_toggled(self):
        b_test = self.ab_test_cb.isChecked()
        if b_test:
            self.top2_cb.setChecked(False)
        self.speech_pid_edit.setEnabled(not b_test)
        self.speech_query_btn.setEnabled(not b_test)
        self.top2_path_edit.setEnabled(not b_test)

    # ==================== 长版本 / PID 查询 ====================
    def fetch_long_version(self):
        main = self._main()
        if main and not main.connect_page.ssh_ok:
            QMessageBox.warning(self, "未连接",
                                "请先在「连接设备」页连接 QNX (SSH)")
            return
        self.fetch_version_btn.setEnabled(False)
        self.append_log("正在从车机获取长版本...")
        self.fetch_v_thread = FetchLongVersionThread(self.get_ssh_config())
        self.fetch_v_thread.done.connect(self.on_long_version)
        self.fetch_v_thread.start()

    def on_long_version(self, ok, version):
        self.fetch_version_btn.setEnabled(True)
        if ok:
            self.long_version_edit.setText(version)
            self.append_log(f"车机长版本: {version}")
        else:
            QMessageBox.warning(self, "获取失败", f"获取长版本失败:\n{version}")
            self.append_log(f"获取长版本失败: {version}")

    def query_nomi_pid(self):
        car = self.car_combo.currentText()
        pids = AdbExecutor.get_nomi_pids(car)
        if not pids:
            kw = "小乐 (com.alps.xiaole)" if car == "ALPS" else "NOMI"
            QMessageBox.warning(self, "无进程",
                                f"未找到 {kw} 进程，请检查 ADB 连接")
            return
        title = "选择小乐 PID" if car == "ALPS" else "选择 NOMI PID"
        dialog = PIDSelectionDialog(pids, title)
        if dialog.exec_() == QDialog.Accepted:
            selected = dialog.get_selected()
            if selected:
                self.nomi_pid_edit.setText(selected.split()[0])

    def query_speech_pid(self):
        main = self._main()
        if main and not main.connect_page.ssh_ok:
            QMessageBox.warning(self, "未连接",
                                "请先在「连接设备」页连接 QNX (SSH)")
            return
        self.speech_query_btn.setEnabled(False)
        self.append_log("正在查询 speech-service PID...")
        self.fetch_pid_thread = FetchSpeechPidThread(self.get_ssh_config())
        self.fetch_pid_thread.done.connect(self.on_speech_pid)
        self.fetch_pid_thread.start()

    def on_speech_pid(self, ok, msg, pids):
        self.speech_query_btn.setEnabled(True)
        if not ok:
            QMessageBox.warning(self, "查询失败",
                                f"查询 speech-service 失败:\n{msg}")
            return
        if not pids:
            QMessageBox.warning(self, "无进程", "未找到 speech-service 进程")
            return
        self.append_log(f"speech-service 查询成功 (来源: {msg})")
        dialog = PIDSelectionDialog(pids, "选择 speech-service PID")
        if dialog.exec_() == QDialog.Accepted:
            selected = dialog.get_selected()
            if selected:
                self.speech_pid_edit.setText(selected.split()[0])

    # ==================== 场景选择 ====================
    def select_all(self):
        for cb in self.scenario_checks.values():
            cb.setChecked(True)

    def deselect_all(self):
        for cb in self.scenario_checks.values():
            cb.setChecked(False)

    def get_selected_scenarios(self):
        return [k for k in SCENARIO_KEYS if self.scenario_checks[k].isChecked()]

    # ==================== 开始前校验（独立方法便于测试） ====================
    def validate(self) -> str:
        """开始测试前校验，返回错误消息（空串 = 通过）"""
        main = self._main()
        # 1. 设备连接（没连接上绝对不跑）
        if main:
            cp = main.connect_page
            if not (cp.adb_ok and cp.ssh_ok):
                return ("设备未就绪: ADB {} | SSH(QNX) {}\n"
                        "请到「连接设备」页:\n"
                        "  1) 点「自动连接」；失败则点「复制手动隧道命令」，\n"
                        "     粘贴到 CMD 执行并保持窗口打开，再点「手动检测」\n"
                        "  2) 两项都显示已连接后回到本页开始").format(
                    "已连接" if cp.adb_ok else "未连接",
                    "已连接" if cp.ssh_ok else "未连接")
        # 2. 版本号
        short_version = self.short_version_edit.text().strip()
        if not short_version:
            return "请填写版本号（如 NT3.0-160-daily），用于产物命名"
        if any(c in short_version for c in _BAD_CHARS):
            return f"版本号含文件名非法字符 ({_BAD_CHARS})"
        # 3. 场景
        scenarios = self.get_selected_scenarios()
        if not scenarios:
            return "请至少选择一个测试场景"
        # 4. PID
        nomi_pid = self.nomi_pid_edit.text().strip()
        if ("idle" in scenarios or "idle_after" in scenarios) and not nomi_pid:
            return ("静置 / 交互后静置场景需要 NOMI PID（showmap 采集），\n"
                    "请填写或点「查询」选择")
        speech_pid = self.speech_pid_edit.text().strip()
        # B 测试全局跳过 top2，无需 speech PID
        if (self.top2_cb.isChecked() and not self.ab_test_cb.isChecked()
                and not speech_pid):
            return ("已勾选 QNX top2 采集，需要 speech-service PID，\n"
                    "请填写或点「查询」选择；\n"
                    "若本轮是 B 测试（跳过 top2），请勾选「B 测试」")
        # 5. 总文件夹名
        session_name = self.session_name_edit.text().strip()
        if session_name and any(c in session_name for c in _BAD_CHARS):
            return f"总文件夹名含非法字符 ({_BAD_CHARS})"
        # 6. MEM 脚本
        if self.mem_cb.isChecked():
            script = os.path.join(self.get_output_root(), "mem_command_nomi.sh")
            if not os.path.exists(script):
                return ("已勾选 MEM 脚本采集，但未上传 mem_command_nomi.sh，\n"
                        "请到「TTS 配置」页上传")
            if not LocalExecutor.find_bash():
                return ("MEM 脚本需要 bash 执行，未检测到 bash，\n"
                        "请安装 Git for Windows 后重试")
        return ""

    # ==================== 开始/停止 ====================
    def start_test(self):
        error = self.validate()
        if error:
            QMessageBox.warning(self, "无法开始测试", error)
            return

        short_version = self.short_version_edit.text().strip()
        scenarios = self.get_selected_scenarios()
        nomi_pid = self.nomi_pid_edit.text().strip()
        speech_pid = self.speech_pid_edit.text().strip()
        output_root = self.get_output_root()

        # 交互场景需要唤醒词音频：缺失时询问用户是否现场用 Edge TTS 生成
        if any(k in INTERACTIVE_SCENARIOS for k in scenarios):
            if not self.ensure_wakeup_audio():
                return

        session_name = self.session_name_edit.text().strip()
        if not session_name:
            session_name = f"{short_version}_{datetime.now().strftime('%Y%m%d_%H%M')}"
            self.session_name_edit.setText(session_name)
        session_dir = os.path.join(output_root, session_name)
        os.makedirs(session_dir, exist_ok=True)
        self.session_dir = session_dir

        ssh_cfg = self.get_ssh_config()
        config = TestConfig(
            car=self.car_combo.currentText(),
            wakeup_word=self._effective_wakeup(),
            short_version=short_version,
            long_version=self.long_version_edit.text().strip(),
            nomi_pid=nomi_pid,
            speech_pid=speech_pid,
            collect_mem=self.mem_cb.isChecked(),
            collect_cpu=self.cpu_cb.isChecked(),
            collect_top2=self.top2_cb.isChecked(),
            is_b_test=self.ab_test_cb.isChecked(),
            scenarios=scenarios,
            output_root=output_root,
            session_dir=session_dir,
            queries=self.get_queries(),
            ssh_host=ssh_cfg["ssh_host"],
            ssh_user=ssh_cfg["ssh_user"],
            ssh_password=ssh_cfg["ssh_password"],
            top2_path=self.top2_path_edit.text().strip(),
        )

        # 锁定 UI
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.open_folder_btn.setEnabled(False)
        self.progress.setMaximum(len(scenarios))
        self.progress.setValue(0)
        self.log_pane.clear()
        self.append_log(f"开始测试 | {len(scenarios)} 个场景 | 产物目录: {session_dir}")
        if self.ab_test_cb.isChecked():
            self.append_log("B 测试模式: 本轮全局跳过 QNX top2 采集")
        self.append_log("预检中（SSH/ADB/top2/音频），预检不通过不会开始采集...")

        self.engine = TestEngine(config)
        self.engine.log_signal.connect(self.append_log)
        self.engine.progress_signal.connect(self.update_progress)
        self.engine.finished_signal.connect(self.on_finished)
        # 把连接设备页最近一次连接/检测记录带入本轮测试日志（界面 + 日志文件）
        try:
            from ui.connect_page import conn_log_snapshot
            snap = conn_log_snapshot()
            if snap:
                self.append_log("---- 最近连接/检测记录（连接设备页） ----")
                self.engine._log(
                    "连接/检测记录（来自连接设备页）:\n"
                    + "\n".join("  " + ln for ln in snap))
        except Exception:
            pass
        self.engine.start()

    # ==================== 唤醒词音频现场生成 ====================
    def ensure_wakeup_audio(self) -> bool:
        """唤醒词音频缺失时询问用户是否用 Edge TTS 现场生成。

        返回 True = 音频已就绪（或已生成成功），可以继续；
        返回 False = 用户拒绝/生成失败，中止本次启动。
        """
        wakeup = self._effective_wakeup()
        if not wakeup:
            return True
        audio_dir = os.path.join(self.get_output_root(), DIR_AUDIO)
        if find_audio_file(audio_dir, wakeup) is not None:
            return True  # 已存在可播放音频

        ret = QMessageBox.question(
            self, "唤醒词音频缺失",
            f"未找到唤醒词音频:\n  audio/{wakeup}.wav/.mp3\n\n"
            f"是否现在用 Edge TTS 生成唤醒词「{wakeup}」的音频?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if ret != QMessageBox.Yes:
            QMessageBox.information(
                self, "已取消",
                "未生成唤醒词音频，本次测试不启动。\n"
                "也可以到「TTS 配置」页点击「生成所有音频」。")
            return False
        if not tts_available():
            QMessageBox.warning(self, "缺少 edge-tts",
                                "未检测到 edge-tts 命令，请先安装:\n"
                                "  pip install edge-tts")
            return False

        os.makedirs(audio_dir, exist_ok=True)
        target = os.path.join(audio_dir, f"{wakeup}.wav")
        self.append_log(f"正在生成唤醒词音频 [{wakeup}] ...")
        QApplication.processEvents()  # 先把日志刷出来
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            ok, err = synth_one(wakeup, target)
        finally:
            QApplication.restoreOverrideCursor()
        if not ok:
            QMessageBox.warning(self, "生成失败",
                                f"唤醒词音频生成失败: {err}")
            return False
        self.append_log(f"唤醒词音频已生成: {target}")
        return True

    def stop_test(self):
        if self.engine and self.engine.isRunning():
            self.engine.stop()
            self.append_log("已请求停止，等待当前采集收尾...")

    def on_finished(self, success, message):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.open_folder_btn.setEnabled(True)
        self.append_log(f"测试结束: {message}")
        if success:
            QMessageBox.information(self, "完成", message)
        else:
            QMessageBox.warning(self, "结束", message)

    def open_session_folder(self):
        if self.session_dir and os.path.exists(self.session_dir):
            LocalExecutor.open_folder(self.session_dir)

    # ==================== 日志/进度 ====================
    def append_log(self, text):
        self.log_pane.append(text)

    def update_progress(self, current, total):
        self.progress.setMaximum(total)
        self.progress.setValue(current)

    def closeEvent(self, event):
        if self.engine and self.engine.isRunning():
            self.engine.stop()
            self.engine.wait(5000)
            # 超时仍未退出：保留全局引用，避免运行中的 QThread 被回收闪退
            if self.engine.isRunning():
                _KEEP_ALIVE.append(self.engine)
        event.accept()
