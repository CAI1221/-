# ui/config_page.py
# TTS 配置页：输出根目录 + 车型选择 + Query 编辑 + 音频生成(生成后逐个校验) + MEM 脚本上传
import json
import os
import re
import shutil
import time

from PyQt5.QtCore import QThread, QTimer, pyqtSignal
from PyQt5.QtWidgets import (QComboBox, QFileDialog, QFrame,
                             QGroupBox, QHBoxLayout, QLabel,
                             QLineEdit, QListWidget, QMessageBox,
                             QPlainTextEdit, QPushButton, QScrollArea,
                             QTextEdit, QVBoxLayout, QWidget)

from core import app_log
from core.constants import CAR_WAKEUP_WORDS
from core.tts import (DEFAULT_VOICE, DEFAULT_VOICE_TYPE, NIO_TTS_HINT,
                      VOICE_GROUPS, style_items, styles_of, synth_one,
                      tts_available, voices_of_type)
from ui.log_utils import trim_text_edit_max_blocks

DEFAULT_QUERIES = {
    "车控": ["打开车窗", "关闭车窗", "空调调至25度", "打开空调"],
    "媒体": ["播放周杰伦的歌", "下一曲", "音量调大"],
    "导航": ["导航到人民广场", "附近加油站"],
    "电话": ["打电话给张三", "拨打10086"],
    "天气": ["今天天气怎么样", "明天会下雨吗"],
    "笑话": ["讲个笑话"],
    "GPT": ["介绍一下秦始皇"],
}

AUDIO_EXTS = (".wav", ".mp3")

# 校准音文件名（不带下划线前缀，避免被“识别本地音频”误当作 场景_Query 解析）
CAL_TONE_NAME = "校准音1kHz.wav"


def split_query_text(text: str):
    """把编辑框内容解析为 Query 列表：换行或中/英文逗号都可作分隔。
    例: "打开车窗，关闭车窗\n打开氛围灯" -> ["打开车窗","关闭车窗","打开氛围灯"]
    """
    out = []
    for line in str(text or "").splitlines():
        for part in re.split(r"[，,]", line):
            p = part.strip()
            if p:
                out.append(p)
    return out


def find_audio_file(audio_dir: str, base_name: str):
    """查找音频文件（.wav/.mp3，非空），返回路径或 None"""
    for ext in AUDIO_EXTS:
        p = os.path.join(audio_dir, base_name + ext)
        try:
            if os.path.exists(p) and os.path.getsize(p) > 0:
                return p
        except OSError:
            continue
    return None


def parse_audio_scene_query(filename: str):
    """按命名规范解析本地 TTS 音频文件名 -> (场景, Query)

    命名规范与生成时一致: {场景}_{Query}.wav/.mp3
    例: "天气_今天紫外线强度.wav" -> ("天气", "今天紫外线强度")
    不符合规范（如无下划线前缀的唤醒词文件）返回 None。
    """
    base = os.path.splitext(os.path.basename(str(filename)))[0].strip()
    if "_" not in base:
        return None
    scene, _, query = base.partition("_")
    scene, query = scene.strip(), query.strip()
    if not scene or not query:
        return None
    return scene, query


class WakeSynthWorker(QThread):
    """v1.6.8: 仅合成单个唤醒词音频的后台线程。

    旧实现直接在主线程调用 synth_one（含网络等待），点击按钮后整个界面
    冻结数秒到数十秒。改用后台线程后 UI 始终可点、可打字。
    """
    done = pyqtSignal(bool, str, str)   # (成功, 错误或文件路径, 音频目录)

    def __init__(self, text, target, voice, style):
        super().__init__()
        self.text = text
        self.target = target
        self.voice = voice
        self.style = style

    def run(self):
        from core.tts import synth_one
        ok, err = synth_one(self.text, self.target,
                            voice=self.voice, style=self.style)
        self.done.emit(ok, err if not ok else self.target,
                       os.path.dirname(self.target))


class TtsWorker(QThread):
    """批量合成 TTS 音频（唤醒词 + 挂断音 + 各场景 Query）
    每条合成后立即校验文件存在且非空，失败自动重试一次，最终汇总。
    """
    log_signal = pyqtSignal(str)
    # (成功数, 失败列表, 音频目录)
    finished_signal = pyqtSignal(int, list, str)

    def __init__(self, output_root, data, wakeup_word,
                 voice: str = "", style: str = "默认"):
        super().__init__()
        self.output_root = output_root
        self.data = data
        self.wakeup_word = wakeup_word
        self.voice = voice or DEFAULT_VOICE
        self.style = style if style and style != "默认" else "默认"
        self._stopped = False

    def stop(self):
        self._stopped = True

    def _emit(self, msg):
        if not self._stopped:
            self.log_signal.emit(msg)

    def _synth_one(self, text, filepath):
        """合成单个音频并校验，返回 (成功, 错误信息)；使用界面选择的音色/情感"""
        return synth_one(text, filepath, voice=self.voice, style=self.style)

    def _synth(self, text, filename, audio_dir, failed):
        """合成（带跳过 + 重试 + 校验），失败记入 failed。
        注: edge-tts 输出实为 MP3 数据，播放器已按文件内容识别格式加载，
        .wav 扩展名仅作文件名约定（历史文件与播放逻辑均兼容）。"""
        filepath = os.path.join(audio_dir, filename)
        if find_audio_file(audio_dir, os.path.splitext(filename)[0]):
            self._emit(f"跳过已存在: {filename}")
            return
        self._emit(f"合成中: {filename}")
        ok, err = self._synth_one(text, filepath)
        if not ok:
            # 失败自动重试一次（网络抖动常见）
            self._emit(f"  失败({err})，重试一次...")
            try:
                if os.path.exists(filepath):
                    os.remove(filepath)
            except OSError:
                pass
            ok, err = self._synth_one(text, filepath)
        if ok:
            self._emit(f"完成: {filename}")
        else:
            self._emit(f"[失败] {filename}: {err}")
            failed.append(f"{filename} ({err})")

    def run(self):
        audio_dir = os.path.join(self.output_root, "audio")
        os.makedirs(audio_dir, exist_ok=True)
        failed = []
        ok_count = 0

        # 统计本次应合成的总量（用于汇总）
        tasks = []
        # 唤醒词音频（文件名 = 唤醒词）
        if self.wakeup_word:
            tasks.append((self.wakeup_word, f"{self.wakeup_word}.wav"))
        # 电话挂断音
        tasks.append(("挂断", "电话_挂断.wav"))
        # 各场景 Query 音频（文件名 = 场景_Query）
        for scenario, queries in self.data.items():
            for query in queries:
                if not query.strip():
                    continue
                safe = query.strip().replace("/", "_").replace("\\", "_")
                tasks.append((query.strip(), f"{scenario}_{safe}.wav"))

        for text, filename in tasks:
            if self._stopped:
                self._emit("已取消合成")
                break
            before = len(failed)
            self._synth(text, filename, audio_dir, failed)
            if len(failed) == before:
                ok_count += 1
            # v1.6.8: 条目间小幅节流（0.3s），降低被 Edge 服务端限流的概率；
            # 之前连续快速请求大批量时易出现 “No audio was received”
            if not self._stopped:
                for _ in range(3):
                    if self._stopped:
                        break
                    time.sleep(0.1)

        self.finished_signal.emit(ok_count, failed, audio_dir)


class ConfigPage(QWidget):
    """TTS 配置页"""

    def __init__(self):
        super().__init__()
        self.output_root = os.path.join(os.path.expanduser("~"), "NOMI_Test_Data")
        self.config_file = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "config.json")
        self.worker = None
        self.wake_worker = None
        # Query 数据模型: 场景 -> Query 列表（编辑区内存态，保存时才写 config.json）
        self._scenario_order = list(DEFAULT_QUERIES.keys())
        self._query_data = {k: list(v) for k, v in DEFAULT_QUERIES.items()}
        self._current = self._scenario_order[0] if self._scenario_order else ""
        # 编辑区未管理的场景键（如 config 里多余的「唤醒」）原样保留，防保存时丢失
        self._extra_queries: dict = {}
        # 自动保存（防抖 700ms）：改动 Query/唤醒词后自动写入 config.json，实现记忆
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(700)
        self._save_timer.timeout.connect(self._auto_save_config)
        # v1.6.8: 状态提示防抖（打字时不再每键解析整段文本/刷新样式）
        self._hint_timer = QTimer(self)
        self._hint_timer.setSingleShot(True)
        self._hint_timer.setInterval(180)
        self._hint_timer.timeout.connect(self._refresh_query_count)
        self.init_ui()
        self.load_config()

    # ==================== UI ====================
    def init_ui(self):
        # 内容较多，整体放进滚动区，避免小窗口/低分辨率下按钮被挤出视口
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        outer.addWidget(scroll)
        container = QWidget()
        scroll.setWidget(container)
        layout = QVBoxLayout(container)
        layout.setSpacing(8)
        layout.setContentsMargins(10, 10, 10, 10)

        title = QLabel("TTS 配置")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #e8eaee;")
        layout.addWidget(title)

        # ---- 输出根目录 ----
        dir_group = QGroupBox("输出根目录（音频、MEM 脚本、各轮测试总文件夹都放在这里）")
        dir_layout = QHBoxLayout(dir_group)
        self.dir_edit = QLineEdit(self.output_root)
        self.dir_edit.setStyleSheet("background-color: #0d1016; padding: 4px;")
        dir_layout.addWidget(self.dir_edit, 1)
        dir_btn = QPushButton("浏览...")
        dir_btn.clicked.connect(self.select_output_root)
        dir_layout.addWidget(dir_btn)
        layout.addWidget(dir_group)

        # ---- 车型选择 ----
        car_group = QGroupBox("车型（决定唤醒词音频）")
        car_layout = QHBoxLayout(car_group)
        self.car_combo = QComboBox()
        self.car_combo.addItems(list(CAR_WAKEUP_WORDS.keys()))
        self.car_combo.currentTextChanged.connect(self.on_car_changed)
        car_layout.addWidget(self.car_combo)
        self.wakeup_label = QLabel()
        self.wakeup_label.setStyleSheet("font-weight: bold; color: #3b82f6;")
        car_layout.addWidget(self.wakeup_label)
        car_layout.addStretch()
        layout.addWidget(car_group)

        # ---- 唤醒词音频 (TTS) ----
        wake_group = QGroupBox("唤醒词音频 (TTS，外放触发 NOMI 用)")
        wake_v = QVBoxLayout(wake_group)
        wake_v.setSpacing(4)
        wake_row = QHBoxLayout()
        wake_row.addWidget(QLabel("唤醒词文本:"))
        self.wakeup_edit = QLineEdit()
        self.wakeup_edit.setPlaceholderText("随车型自动带出，可自行修改（决定音频文件名）")
        self.wakeup_edit.textChanged.connect(self._update_wake_status)
        self.wakeup_edit.textChanged.connect(self._schedule_save)
        wake_row.addWidget(self.wakeup_edit, 1)
        self.gen_wake_btn = QPushButton("仅生成唤醒词音频")
        self.gen_wake_btn.setStyleSheet(
            "background-color: #22c55e; color: white; padding: 5px 14px;"
            " border-radius: 4px; font-weight: bold;")
        self.gen_wake_btn.clicked.connect(self.generate_wake_audio)
        wake_row.addWidget(self.gen_wake_btn)
        wake_v.addLayout(wake_row)
        self.wake_file_label = QLabel()
        self.wake_file_label.setStyleSheet(
            "font-family: Consolas, 'Microsoft YaHei', monospace;"
            " font-size: 11px; color: #9aa3b2;")
        wake_v.addWidget(self.wake_file_label)
        layout.addWidget(wake_group)

        # ---- TTS 合成音色设置（女声/男声/童声 + 情感语气） ----
        voice_group = QGroupBox("TTS 合成音色（女声/男声/童声 + 情感语气）")
        vg = QVBoxLayout(voice_group)
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("合成来源:"))
        self.voice_provider_combo = QComboBox()
        self.voice_provider_combo.addItems(
            ["Edge-TTS（在线）", "NIO 内部 TTS（预留）"])
        self.voice_provider_combo.currentTextChanged.connect(
            self._on_voice_provider_changed)
        row1.addWidget(self.voice_provider_combo)
        row1.addWidget(QLabel("音色类型:"))
        self.voice_type_combo = QComboBox()
        self.voice_type_combo.addItems(list(VOICE_GROUPS.keys()))
        self.voice_type_combo.currentTextChanged.connect(
            self._populate_voice_list)
        row1.addWidget(self.voice_type_combo)
        row1.addWidget(QLabel("音色:"))
        self.voice_combo = QComboBox()
        self.voice_combo.setMinimumWidth(240)
        self.voice_combo.currentIndexChanged.connect(self._on_voice_changed)
        row1.addWidget(self.voice_combo, 1)
        row1.addWidget(QLabel("情感/语气:"))
        self.style_combo = QComboBox()
        self.style_combo.setMinimumWidth(140)
        row1.addWidget(self.style_combo)
        vg.addLayout(row1)
        self.voice_hint = QLabel(
            "说明：语音内容/播放逻辑不变；重新点「生成所有音频」会用所选音色覆盖已有音频。")
        self.voice_hint.setStyleSheet("color: #9aa3b2; font-size: 11px;")
        vg.addWidget(self.voice_hint)
        self.nio_hint_label = QLabel(NIO_TTS_HINT)
        self.nio_hint_label.setWordWrap(True)
        self.nio_hint_label.setStyleSheet("color: #f59e0b; font-size: 11px;")
        self.nio_hint_label.hide()
        vg.addWidget(self.nio_hint_label)
        layout.addWidget(voice_group)

        # ---- MEM 脚本上传 ----
        script_group = QGroupBox("MEM 脚本 (mem_command_nomi.sh)")
        script_layout = QHBoxLayout(script_group)
        self.script_path_label = QLabel("未上传")
        self.script_path_label.setStyleSheet(
            "font-family: Consolas; font-size: 11px; color: #f59e0b;")
        script_layout.addWidget(self.script_path_label, 1)
        upload_btn = QPushButton("上传 .sh 脚本")
        upload_btn.clicked.connect(self.upload_mem_script)
        script_layout.addWidget(upload_btn)
        layout.addWidget(script_group)

        # ---- Query 编辑区（场景列表 + 大编辑框，支持逗号/换行分隔） ----
        query_group = QGroupBox("场景 Query（可上下滚动；每个 Query 生成 1 条 TTS）")
        q_layout = QHBoxLayout(query_group)
        q_layout.setSpacing(8)
        self.scenario_list = QListWidget()
        self.scenario_list.setFixedWidth(150)
        self.scenario_list.itemSelectionChanged.connect(self._on_scenario_changed)
        q_layout.addWidget(self.scenario_list)
        self.query_edit = QPlainTextEdit()
        self.query_edit.setPlaceholderText(
            "每个 Query 占一行，也可以用中/英文逗号隔开，例如：\n"
            "打开车窗，关闭车窗，打开氛围灯\n"
            "→ 将解析为 3 个 Query，分别生成 3 条 TTS")
        self.query_edit.setStyleSheet(
            "QPlainTextEdit { font-family: Consolas,'Microsoft YaHei',monospace;"
            " font-size: 13px; background-color: #0d1016;"
            " border: 1px solid #262b36; border-radius: 4px; padding: 6px; }")
        self.query_edit.setMinimumHeight(120)
        self.query_edit.setMaximumHeight(260)
        self.query_edit.textChanged.connect(self._on_query_edited)
        q_layout.addWidget(self.query_edit, 1)
        layout.addWidget(query_group)
        self._query_hint = QLabel()
        self._query_hint.setStyleSheet("color: #9aa3b2; font-size: 11px;")
        layout.addWidget(self._query_hint)

        # 用当前配置数据填充场景列表与编辑框
        self._fill_query_editor()

        # ---- 按钮 ----
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("保存配置")
        save_btn.setStyleSheet(
            "background-color: #3b82f6; color: white; padding: 6px 18px;"
            " border-radius: 4px; font-weight: bold;")
        save_btn.clicked.connect(self.save_config)
        btn_layout.addWidget(save_btn)

        self.gen_btn = QPushButton("生成所有音频 (Edge TTS)")
        self.gen_btn.setStyleSheet(
            "background-color: #22c55e; color: white; padding: 6px 18px;"
            " border-radius: 4px; font-weight: bold;")
        self.gen_btn.clicked.connect(self.generate_audio)
        btn_layout.addWidget(self.gen_btn)

        self.identify_btn = QPushButton("识别本地音频")
        self.identify_btn.setToolTip(
            "扫描当前输出目录 audio/ 下已有的 TTS 音频并核对完整性。\n"
            "若之前已生成过，识别后就绪即可跳过重新生成。")
        self.identify_btn.clicked.connect(self.identify_local_audio)
        btn_layout.addWidget(self.identify_btn)

        self.verify_btn = QPushButton("校验音频完整性")
        self.verify_btn.clicked.connect(self.verify_audio)
        btn_layout.addWidget(self.verify_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        # ---- 日志 ----
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(110)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #0d1016; border: 1px solid #262b36; border-radius: 4px;
                font-family: Consolas, 'Microsoft YaHei', monospace; font-size: 11px;
            }
        """)
        layout.addWidget(self.log_text)

        self.on_car_changed(self.car_combo.currentText())
        self.update_script_path()
        # 默认女声晓晓（与历史默认最接近），随 config 载入再覆盖
        self._populate_voice_list(DEFAULT_VOICE_TYPE)

    # ==================== 目录/脚本 ====================
    # v1.6.6: 每类文件选择记住上次目录（config.json ui_last_dirs，与时延页共用）
    def _ui_last_dir(self, kind: str, fallback: str = "") -> str:
        try:
            with open(self.config_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            d = (data.get("ui_last_dirs") or {}).get(kind, "")
            if d and os.path.isdir(d):
                return d
        except Exception:
            pass
        return fallback if (fallback and os.path.isdir(fallback)) else ""

    def _remember_dir(self, kind: str, path: str):
        if not path:
            return
        try:
            with open(self.config_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
        dirs = dict(data.get("ui_last_dirs") or {})
        dirs[kind] = os.path.dirname(path) or path
        data["ui_last_dirs"] = dirs
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def select_output_root(self):
        start = self._ui_last_dir("output", self.output_root)
        d = QFileDialog.getExistingDirectory(self, "选择输出根目录", start)
        if d:
            self.output_root = d
            self.dir_edit.setText(d)
            self.update_script_path()
            self.save_config()
            self._remember_dir("output", os.path.join(d, "."))

    def update_script_path(self):
        script = os.path.join(self.output_root, "mem_command_nomi.sh")
        if os.path.exists(script):
            self.script_path_label.setText(script)
            self.script_path_label.setStyleSheet(
                "font-family: Consolas; font-size: 11px; color: #22c55e;")
        else:
            self.script_path_label.setText("未上传 (点击「上传 .sh 脚本」)")
            self.script_path_label.setStyleSheet(
                "font-family: Consolas; font-size: 11px; color: #f59e0b;")

    def upload_mem_script(self):
        start = self._ui_last_dir("mem_script")
        path, _ = QFileDialog.getOpenFileName(
            self, "选择 MEM 脚本", start, "Shell 脚本 (*.sh);;所有文件 (*.*)")
        if path:
            os.makedirs(self.output_root, exist_ok=True)
            target = os.path.join(self.output_root, "mem_command_nomi.sh")
            shutil.copy2(path, target)
            self.update_script_path()
            self._remember_dir("mem_script", path)
            QMessageBox.information(self, "上传成功", f"脚本已保存到:\n{target}")

    # ==================== TTS 音色 ====================
    def _populate_voice_list(self, vtype=None):
        """按音色类型刷新音色下拉；尽量保留当前已选音色"""
        vtype = vtype or self.voice_type_combo.currentText()
        keep = self._current_voice()
        self.voice_combo.blockSignals(True)
        self.voice_combo.clear()
        for vid, label in voices_of_type(vtype):
            self.voice_combo.addItem(label, vid)
        idx = 0
        if keep:
            for i in range(self.voice_combo.count()):
                if self.voice_combo.itemData(i) == keep:
                    idx = i
                    break
        self.voice_combo.setCurrentIndex(idx)
        self.voice_combo.blockSignals(False)
        self._on_voice_changed()

    def _on_voice_changed(self):
        """音色变化 -> 刷新可用情感语气（中文名显示，英文 token 存储）"""
        voice = self._current_voice()
        keep = ""
        if hasattr(self, "style_combo"):
            keep = self.style_combo.currentData() or self.style_combo.currentText()
        self.style_combo.blockSignals(True)
        self.style_combo.clear()
        for zh, tok in style_items(voice):
            self.style_combo.addItem(zh, tok)
        if keep:
            ix = self.style_combo.findData(keep)
            if ix >= 0:
                self.style_combo.setCurrentIndex(ix)
        self.style_combo.blockSignals(False)

    def _on_voice_provider_changed(self, text):
        is_nio = "NIO" in text
        for w in (self.voice_type_combo, self.voice_combo, self.style_combo):
            w.setEnabled(not is_nio)
        self.nio_hint_label.setVisible(is_nio)
        self.voice_hint.setVisible(not is_nio)

    def _check_provider(self) -> bool:
        """NIO 内部 TTS 尚未配置时给出提示并阻止继续"""
        if self._current_provider().startswith("NIO"):
            QMessageBox.information(self, "NIO TTS 预留", NIO_TTS_HINT)
            return False
        return True

    def _current_provider(self) -> str:
        return (self.voice_provider_combo.currentText()
                if hasattr(self, "voice_provider_combo") else "Edge-TTS（在线）")

    def _current_voice(self) -> str:
        if hasattr(self, "voice_combo"):
            v = self.voice_combo.currentData()
            if v:
                return str(v)
        return DEFAULT_VOICE

    def _current_style(self) -> str:
        if hasattr(self, "style_combo"):
            v = self.style_combo.currentData()
            if v:
                return str(v)
            return self.style_combo.currentText()   # 兼容旧逻辑
        return "默认"

    def _current_voice_type(self) -> str:
        if hasattr(self, "voice_type_combo"):
            return self.voice_type_combo.currentText()
        return DEFAULT_VOICE_TYPE

    def _set_voice_by_id(self, voice_id: str, style: str = "默认"):
        """按音色ID回填类型/音色/语气（载入配置用，style 为存储 token）"""
        vtype = DEFAULT_VOICE_TYPE
        for t, items in VOICE_GROUPS.items():
            for vid, _ in items:
                if vid == voice_id:
                    vtype = t
                    break
        if self.voice_type_combo.currentText() != vtype:
            self.voice_type_combo.blockSignals(True)
            self.voice_type_combo.setCurrentText(vtype)
            self.voice_type_combo.blockSignals(False)
        self._populate_voice_list(vtype)
        if style not in styles_of(voice_id):
            style = "默认"
        if hasattr(self, "style_combo"):
            ix = self.style_combo.findData(style)
            if ix >= 0:
                self.style_combo.setCurrentIndex(ix)

    # ==================== 车型 ====================
    def on_car_changed(self, car):
        word = CAR_WAKEUP_WORDS.get(car, "")
        self.wakeup_label.setText(f"唤醒词: {word}")
        # 切换车型时把编辑框联动为车型默认唤醒词（用户可再自行修改）
        self.wakeup_edit.setText(word)

    def get_wakeup_word(self):
        return self.wakeup_edit.text().strip()

    # ==================== Query 编辑区 ====================
    def _fill_query_editor(self):
        """按场景列表填充列表项与当前场景的编辑框"""
        self.scenario_list.clear()
        self._current = ""
        for key in self._scenario_order:
            self.scenario_list.addItem(key)
        if self._scenario_order:
            self._current = self._scenario_order[0]
            # 先写入编辑框再选中，避免 itemSelectionChanged 用空文本覆盖默认数据
            self._set_editor_text(self._query_data.get(self._current, []))
            self.scenario_list.blockSignals(True)
            self.scenario_list.setCurrentRow(0)
            self.scenario_list.blockSignals(False)

    def _set_editor_text(self, queries):
        """写入编辑框（触发文本变化不联动 commit，仅刷新计数）"""
        self.query_edit.blockSignals(True)
        self.query_edit.setPlainText("\n".join(queries))
        self.query_edit.blockSignals(False)
        self._refresh_query_count()

    def _commit_editor(self):
        """把编辑框当前内容解析后写回当前场景的 Query 列表"""
        if not getattr(self, "_current", "") or not hasattr(self, "query_edit"):
            return
        self._query_data[self._current] = split_query_text(
            self.query_edit.toPlainText())

    def _on_scenario_changed(self):
        """切换场景: 先保存上一场景编辑内容，再加载新场景"""
        if not getattr(self, "_current", ""):
            return
        self._commit_editor()
        items = self.scenario_list.selectedItems()
        if not items:
            return
        self._current = items[0].text()
        self._set_editor_text(self._query_data.get(self._current, []))

    def _refresh_query_count(self):
        if not hasattr(self, "_query_hint"):
            return
        # 打字时只做轻量统计：不把整段文字 commit 回数据模型（避免每次按键
        # 都解析全量文本导致卡顿）；当前场景数量直接从编辑框文本实时算。
        cur = self._current
        others = 0
        for key, qs in self._query_data.items():
            if key != cur:
                others += len(qs)
        for qs in self._extra_queries.values():
            others += len(qs)
        n = 0
        try:
            if hasattr(self, "query_edit"):
                n = len(split_query_text(self.query_edit.toPlainText()))
        except Exception:
            n = 0
        total = others + n
        self._query_hint.setText(
            f"当前场景 [{cur}]：{n} 条 Query；全部场景共 {total} 条，"
            "点「生成所有音频」将按条生成对应 TTS")

    def _on_query_edited(self):
        """Query 编辑框内容变化：防抖刷新统计，安排自动保存

        v1.6.8: 逐键实时刷新会反复整段解析+重排文本导致输入卡顿，
        改为 180ms 防抖（打字停顿后再更新计数与提示文案）。
        """
        if hasattr(self, "_hint_timer") and not self._hint_timer.isActive():
            self._hint_timer.start()
        self._schedule_save()

    def _schedule_save(self):
        """防抖自动保存（仅页面可见时触发，避免离屏初始化/测试误写配置）"""
        if not self.isVisible():
            return
        if hasattr(self, "_save_timer") and not self._save_timer.isActive():
            self._save_timer.start()

    def _auto_save_config(self):
        """定时器触发的静默自动保存（改动 Query/唤醒词后记住到 config.json）"""
        self._commit_editor()
        self._write_config(quiet=True)

    # ==================== 唤醒词音频状态/生成 ====================
    def _update_wake_status(self):
        """刷新唤醒词音频就绪状态（文件存在 -> 绿色，缺失 -> 提示）"""
        word = self.get_wakeup_word()
        if not word:
            self.wake_file_label.setText("请填写唤醒词文本后点击「仅生成唤醒词音频」")
            self.wake_file_label.setStyleSheet(
                "font-family: Consolas, 'Microsoft YaHei', monospace;"
                " font-size: 11px; color: #ef4444;")
            return
        rel = os.path.join("audio", f"{word}.wav/.mp3")
        path = os.path.join(self.output_root, "audio", f"{word}.wav")
        existing = find_audio_file(os.path.join(self.output_root, "audio"), word)
        if existing:
            self.wake_file_label.setText(
                f"音频就绪: audio/{os.path.basename(existing)}"
                "（点「仅生成唤醒词音频」可重新生成覆盖）")
            self.wake_file_label.setStyleSheet(
                "font-family: Consolas, 'Microsoft YaHei', monospace;"
                " font-size: 11px; color: #22c55e;")
        else:
            self.wake_file_label.setText(
                f"尚未生成: {rel}（点击「仅生成唤醒词音频」，"
                "或随「生成所有音频」一起生成）")
            self.wake_file_label.setStyleSheet(
                "font-family: Consolas, 'Microsoft YaHei', monospace;"
                " font-size: 11px; color: #f59e0b;")
        self.wake_file_label.setToolTip(path)

    def generate_wake_audio(self):
        """仅生成/覆盖唤醒词音频（异步任务进行中时拒绝重复点击）"""
        if self.worker and self.worker.isRunning():
            QMessageBox.warning(self, "任务进行中", "请等待当前合成任务完成")
            return
        if self.wake_worker and self.wake_worker.isRunning():
            QMessageBox.warning(self, "任务进行中", "唤醒词音频正在合成，请稍候")
            return
        word = self.get_wakeup_word()
        if not word:
            QMessageBox.warning(self, "唤醒词为空", "请先填写唤醒词文本")
            return
        if any(c in word for c in '\\/:*?"<>|'):
            QMessageBox.warning(
                self, "非法字符",
                "唤醒词不能包含文件路径非法字符: \\ / : * ? \" < > |")
            return
        if not self._check_provider():
            return
        if not tts_available():
            QMessageBox.warning(
                self, "缺少 edge-tts",
                "未检测到 edge-tts，请先安装:\n  pip install edge-tts")
            return
        audio_dir = os.path.join(self.output_root, "audio")
        os.makedirs(audio_dir, exist_ok=True)
        self.ensure_cal_tone(audio_dir)
        # 与批量生成一致: 音频命名 .wav（edge-tts 输出是 MP3 数据，
        # 播放器已按文件内容识别格式加载，扩展名不影响播放）
        target = os.path.join(audio_dir, f"{word}.wav")
        if os.path.exists(target):
            ret = QMessageBox.question(
                self, "文件已存在",
                f"{target}\n\n已存在，是否重新生成并覆盖？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ret != QMessageBox.Yes:
                self.append_log("已取消覆盖，保留原文件")
                return
        self.gen_wake_btn.setEnabled(False)
        voice = self._current_voice()
        style = self._current_style()
        self.append_log(f"生成唤醒词音频 [{word}] (音色 {voice}"
                        f"{' / ' + style if style and style != '默认' else ''}) ...")
        self.wake_worker = WakeSynthWorker(word, target, voice, style)
        self.wake_worker.done.connect(self._on_wake_done)
        self.wake_worker.start()

    def _on_wake_done(self, ok, result, audio_dir):
        self.gen_wake_btn.setEnabled(True)
        self.wake_worker = None
        if ok:
            self.append_log(f"唤醒词音频已生成: {result}")
        else:
            self.append_log(f"[失败] 唤醒词音频生成失败: {result}")
            QMessageBox.warning(self, "生成失败",
                                f"唤醒词音频生成失败:\n{result}")
        self._update_wake_status()

    # ==================== 配置读写 ====================
    def get_table_data(self):
        """返回 {场景: [Query,...]}（先提交当前编辑区内容再汇总）"""
        self._commit_editor()
        return {k: list(v) for k, v in self._query_data.items()}

    def load_config(self):
        if not os.path.exists(self.config_file):
            return
        try:
            with open(self.config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
            if config.get("work_dir"):
                self.output_root = config["work_dir"]
                self.dir_edit.setText(self.output_root)
                self.update_script_path()
            if config.get("car"):
                self.car_combo.setCurrentText(config["car"])
            if config.get("wakeup_word"):
                # 自定义唤醒词（与车型默认不同时），车型联动已把默认词写入编辑框，
                # 这里再用保存的自定义词覆盖（无自定义时保留车型默认）
                self.wakeup_edit.setText(config["wakeup_word"])
            # TTS 音色/来源（兼容旧 config 无这些键的情况）
            provider = config.get("voice_provider")
            if isinstance(provider, str) and provider:
                idx = self.voice_provider_combo.findText(provider)
                if idx >= 0:
                    self.voice_provider_combo.setCurrentIndex(idx)
                    self._on_voice_provider_changed(provider)
            v = config.get("voice")
            if isinstance(v, str) and v:
                self._set_voice_by_id(v, config.get("tts_style", "默认"))
            if config.get("queries"):
                data = config["queries"]
                extra = {}
                for key, qs in data.items():
                    qs = qs if isinstance(qs, list) else []
                    if key in self._scenario_order:
                        self._query_data[key] = [
                            q for q in qs if str(q).strip()]
                    else:
                        # 编辑区未管理的场景（如「唤醒」）原样保留
                        extra[key] = list(qs)
                self._extra_queries = extra
                if self._scenario_order and hasattr(self, "query_edit"):
                    self._current = self._scenario_order[0]
                    self._set_editor_text(
                        self._query_data.get(self._current, []))
        except Exception as e:
            self.append_log(f"[警告] 读取 config.json 失败: {e}")

    def save_config(self):
        """手动保存（按钮）：提交当前编辑内容并写入 config.json"""
        self._commit_editor()
        self._write_config(quiet=False)

    def _write_config(self, quiet: bool):
        """把当前配置写入 config.json（quiet=True 时静默自动保存）"""
        self.output_root = self.dir_edit.text().strip() or self.output_root
        queries = self.get_table_data()
        for k, v in (self._extra_queries or {}).items():
            queries.setdefault(k, list(v))   # 保留编辑区之外的场景语料
        data = {
            "work_dir": self.output_root,
            "car": self.car_combo.currentText(),
            "wakeup_word": self.get_wakeup_word(),
            "voice_provider": self._current_provider(),
            "voice": self._current_voice(),
            "tts_style": self._current_style(),
            "queries": queries,
        }
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            if not quiet:
                self.append_log("配置已保存到 config.json")
            self._mirror_config_to_audio(data, quiet)
        except Exception as e:
            if quiet:
                self.append_log(f"[警告] 自动保存失败: {e}")
            else:
                QMessageBox.critical(self, "保存失败", str(e))

    # ==================== audio 配置镜像 ====================
    # v1.6.6: 配置与 TTS 音频同路径 —— 保存配置时把副本写到
    # <work_dir>/audio/config.json，便于整车拷贝/携带/跨机恢复。
    def _mirror_config_to_audio(self, data: dict, quiet: bool = False):
        try:
            wd = str(data.get("work_dir") or "").strip()
            if not wd:
                return
            audio = os.path.join(wd, "audio")
            os.makedirs(audio, exist_ok=True)
            with open(os.path.join(audio, "config.json"), "w",
                      encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            if not quiet:
                self.append_log(f"已同步配置到: {os.path.join(audio, 'config.json')}")
        except Exception as e:
            if not quiet:
                self.append_log(f"[警告] 同步配置到 audio 失败: {e}")

    # ==================== 日志 ====================
    def append_log(self, text):
        self.log_text.append(text)
        cursor = self.log_text.textCursor()
        cursor.movePosition(cursor.End)
        self.log_text.setTextCursor(cursor)
        # 长日志裁剪，防止 TTS 页日志框越用越卡
        trim_text_edit_max_blocks(self.log_text)
        # v1.6.8: 镜像到会话运行日志文件（NOMI_性能测试脚本_log.txt），
        # 与执行测试/连接页一致；未初始化日志时为安全空操作。
        app_log.ui(text)

    # ==================== 校准音 ====================
    def ensure_cal_tone(self, audio_dir: str):
        """把 1s 1kHz 校准音写入 audio 目录（本地即时生成，无网络依赖）

        用途: 真人录制端到端响应耗时的录像时，在开头先播放该校准音，
        分析页自动检测其到达时间并扣除空气传播固定偏置(约3-10ms)。
        """
        from core.latency_audio import gen_cal_tone, write_wav_mono
        os.makedirs(audio_dir, exist_ok=True)
        p = os.path.join(audio_dir, CAL_TONE_NAME)
        try:
            write_wav_mono(p, 44100, gen_cal_tone())
        except Exception as e:      # noqa: BLE001
            self.append_log(f"[提示] 校准音生成失败（不影响 TTS 合成）: {e}")
            return False
        self.append_log(f"校准音已写入: {CAL_TONE_NAME}（"
                        "真人录像前先播放约 1 秒，供耗时分析扣除延迟）")
        return True

    # ==================== 音频生成 ====================
    def generate_audio(self):
        if self.worker and self.worker.isRunning():
            QMessageBox.warning(self, "任务进行中", "请等待当前合成任务完成")
            return
        if not self._check_provider():
            return
        if not tts_available():
            QMessageBox.warning(
                self, "缺少 edge-tts",
                "未检测到 edge-tts，请先安装:\n  pip install edge-tts")
            return
        data = self.get_table_data()
        total = sum(len(qs) for qs in data.values())
        if total == 0 and not self.get_wakeup_word():
            QMessageBox.warning(self, "无内容", "请先输入 Query 内容")
            return
        # 生成前先落盘 config.json：测试引擎按文件读取语料，保证“填了就记住”
        self._write_config(quiet=True)

        self.gen_btn.setEnabled(False)
        self.identify_btn.setEnabled(False)
        self.verify_btn.setEnabled(False)
        self.log_text.clear()
        audio_dir = os.path.join(self.output_root, "audio")
        self.ensure_cal_tone(audio_dir)
        voice = self._current_voice()
        style = self._current_style()
        self.append_log(f"输出根目录: {self.output_root}")
        self.append_log(f"唤醒词: {self.get_wakeup_word()} "
                        f"(+ 挂断音 + {total} 条 Query)")
        self.append_log(f"音色: {voice}"
                        f"{' / ' + style if style and style != '默认' else ''}")

        self.worker = TtsWorker(self.output_root, data, self.get_wakeup_word(),
                                voice=voice, style=style)
        self.worker.log_signal.connect(self.append_log)
        self.worker.finished_signal.connect(self.on_audio_finished)
        self.worker.start()

    def on_audio_finished(self, ok_count, failed, audio_dir):
        self.gen_btn.setEnabled(True)
        self.identify_btn.setEnabled(True)
        self.verify_btn.setEnabled(True)
        self._update_wake_status()
        # 生成后立即做一次完整性校验（以文件实际状态为准）
        missing, total = self._collect_missing()
        self.append_log(f"合成结束: 成功 {ok_count} 个，失败 {len(failed)} 个")
        if failed:
            self.append_log("[失败明细]\n  " + "\n  ".join(failed))
        if missing:
            msg = (f"音频生成完成，但有 {len(missing)}/{total} 个文件缺失:\n\n"
                   + "\n".join(missing[:15])
                   + ("\n..." if len(missing) > 15 else "")
                   + "\n\n可再次点击「生成所有音频」重试失败的条目，"
                     "缺失的音频会导致测试预检不通过。")
            QMessageBox.warning(self, "音频不完整", msg)
        else:
            QMessageBox.information(
                self, "完成",
                f"全部 {total} 个音频文件校验通过!\n目录: {audio_dir}")

    def shutdown(self):
        """退出前停止后台合成线程（主窗口关闭时调用）"""
        for w in (self.worker, self.wake_worker):
            if w is not None and w.isRunning():
                try:
                    w.stop()
                except Exception:
                    pass
        for w in (self.worker, self.wake_worker):
            if w is not None and w.isRunning():
                try:
                    w.wait(3000)
                except Exception:
                    pass

    # ==================== 音频校验 ====================
    def _collect_missing(self):
        """按当前配置扫描 audio 目录，返回 (缺失列表, 应有总数)"""
        audio_dir = os.path.join(self.output_root, "audio")
        missing = []
        total = 0
        # 唤醒词
        wake = self.get_wakeup_word()
        if wake:
            total += 1
            if find_audio_file(audio_dir, wake) is None:
                missing.append(f"{wake}.wav/.mp3 (唤醒词)")
        # 挂断音
        total += 1
        if find_audio_file(audio_dir, "电话_挂断") is None:
            missing.append("电话_挂断.wav/.mp3")
        # 各场景 Query
        for scenario, queries in self.get_table_data().items():
            for q in queries:
                total += 1
                safe = q.strip().replace("/", "_").replace("\\", "_")
                if find_audio_file(audio_dir, f"{scenario}_{safe}") is None:
                    missing.append(f"{scenario}_{safe}.wav/.mp3")
        return missing, total

    # ==================== 识别本地音频 ====================
    def identify_local_audio(self):
        """扫描输出目录 audio/，把识别到的音频补进对应场景 Query 列表

        - 命名规范: {场景}_{Query}.wav/.mp3（与生成规则一致）
        - 已存在于模块中的 Query 不重复添加
        - 新增后立即刷新场景右侧编辑区显示，并同步保存到 config.json
        适用: 之前已用本工具生成过一批 TTS 音频的目录，切换输出根目录后
        点本按钮直接识别复用，无需重新生成。
        """
        self.output_root = self.dir_edit.text().strip() or self.output_root
        audio_dir = os.path.join(self.output_root, "audio")
        if not os.path.isdir(audio_dir):
            self.append_log(f"[识别] audio 目录不存在，无可识别音频: {audio_dir}")
            QMessageBox.information(
                self, "无本地音频",
                f"audio 目录不存在：\n{audio_dir}\n\n"
                "说明该目录下还没有生成过 TTS 音频，请点击「生成所有音频」。")
            return
        try:
            files = sorted(f for f in os.listdir(audio_dir)
                           if f.lower().endswith(AUDIO_EXTS))
        except OSError as e:
            self.append_log(f"[识别] 读取 audio 目录失败: {e}")
            QMessageBox.warning(self, "读取失败", str(e))
            return

        added_ui = []      # (场景, Query) 补进右侧可见模块
        added_other = []   # (场景, Query) 界面未列出的场景
        for f in files:
            parsed = parse_audio_scene_query(f)
            if parsed is None:
                continue          # 唤醒词等无场景前缀文件不参与补 Query
            scene, query = parsed
            if scene == "电话" and query == "挂断":
                continue          # 专用挂断音由引擎自动播放，不当作普通 Query
            if scene in self._scenario_order:
                qs = self._query_data.setdefault(scene, [])
                if query not in qs:
                    qs.append(query)
                    added_ui.append((scene, query))
            else:
                qs = self._extra_queries.setdefault(scene, [])
                if query not in qs:
                    qs.append(query)
                    added_other.append((scene, query))

        # 新增后重算完整性（缺失 = 配置里有但 audio 里没有的文件）
        missing, total = self._collect_missing()
        present = total - len(missing)

        summary = [f"[识别] audio 目录: {audio_dir}",
                   f"        共 {len(files)} 个音频; 匹配模块配置 {present}/{total} 条;"
                   f" 新增 {len(added_ui)} 条(可见模块) + {len(added_other)} 条(其他)"]
        if added_ui:
            summary.append("        已补入 UI 场景:")
            summary += [f"          {s}: {q}" for s, q in added_ui]
        if added_other:
            summary.append("        已补入其他场景(右侧未列):")
            summary += [f"          {s}: {q}" for s, q in added_other]
        self.append_log("\n".join(summary))

        if added_ui or added_other:
            # 立即让用户在右侧看到新增内容：跳到第一个新增的可见模块
            if added_ui:
                target = added_ui[0][0]
                if target in self._scenario_order:
                    self._current = target
                    row = self._scenario_order.index(target)
                    self.scenario_list.blockSignals(True)
                    self.scenario_list.setCurrentRow(row)
                    self.scenario_list.blockSignals(False)
                    self._set_editor_text(self._query_data.get(target, []))
            # 落盘到 config.json（覆盖/合并自上次保存的内容）
            self._write_config(quiet=True)
            self._update_wake_status()
            n_new = len(added_ui) + len(added_other)
            self.append_log(f"[识别] 新增 {n_new} 条 Query，已同步保存 config.json")
            msg = f"本地识别完成：audio 目录共 {len(files)} 个音频。\n\n"
            if added_ui:
                msg += (f"已把 {len(added_ui)} 条补进右侧对应场景模块：\n"
                        + "\n".join(f"  {s}: {q}" for s, q in added_ui[:12])
                        + ("\n  ..." if len(added_ui) > 12 else "") + "\n\n")
            if added_other:
                msg += (f"另有 {len(added_other)} 条属于界面未列出的场景，已一并保存：\n"
                        + "\n".join(f"  {s}: {q}" for s, q in added_other[:12])
                        + ("\n  ..." if len(added_other) > 12 else "") + "\n\n")
            msg += "新增 Query 已显示在场景右侧编辑区并保存，这些音频无需重新生成。"
            QMessageBox.information(self, "识别完成", msg)
            return

        # 没有任何新增（本地音频与当前模块配置完全一致）
        if missing:
            msg = (f"本地音频均已对应到当前模块（未新增），但仍有 "
                   f"{len(missing)}/{total} 条 Query 缺音频文件:\n\n"
                   + "\n".join(missing[:15])
                   + ("\n..." if len(missing) > 15 else "")
                   + "\n\n可点击「生成所有音频」补齐缺失的音频。")
            self.append_log("[识别] 缺失条目:\n  " + "\n  ".join(missing[:30]))
            QMessageBox.warning(self, "音频不完整", msg)
        else:
            QMessageBox.information(
                self, "识别完成",
                f"audio 目录下共 {len(files)} 个音频文件。\n\n"
                f"已与当前模块配置完全对应（{total} 条），无新增、无缺失，"
                "可以直接使用。")

    def verify_audio(self):
        missing, total = self._collect_missing()
        if missing:
            msg = (f"缺失 {len(missing)}/{total} 个音频文件:\n\n"
                   + "\n".join(missing[:15])
                   + ("\n..." if len(missing) > 15 else "")
                   + "\n\n请点击「生成所有音频」补齐。")
            self.append_log(f"[校验] 缺失 {len(missing)}/{total} 个音频")
            QMessageBox.warning(self, "音频不完整", msg)
        else:
            self.append_log(f"[校验] 全部 {total} 个音频文件就绪")
            QMessageBox.information(self, "校验通过",
                                    f"全部 {total} 个音频文件就绪")
