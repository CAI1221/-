# ui/log_utils.py
# QTextEdit 长日志性能工具: 超过上限后从顶部裁剪最旧行。
# 长日志若不加限制，QTextEdit 内部文档会越来越庞大，导致逐行 append
# + 自动滚动的成本线性上升，界面越用越卡。裁剪到 keep 行即可稳定性能。
from PyQt5.QtGui import QTextCursor

LOG_KEEP_LINES = 1500   # 保留行数（到上限后裁到 keep/2，避免频繁裁剪）


def trim_text_edit_max_blocks(edit, keep: int = LOG_KEEP_LINES):
    """如果 edit(QTextEdit) 行数超过 keep，裁剪最旧的 keep/2 行。"""
    try:
        doc = edit.document()
        total = doc.blockCount()
        if total <= keep:
            return
        cut = total - keep // 2
        cursor = edit.textCursor()
        cursor.beginEditBlock()
        try:
            cursor.movePosition(QTextCursor.Start)
            for _ in range(cut):
                cursor.movePosition(QTextCursor.NextBlock,
                                    QTextCursor.KeepAnchor)
            cursor.removeSelectedText()
            cursor.deleteChar()
        finally:
            cursor.endEditBlock()
    except RuntimeError:
        pass   # 控件已销毁等场景静默跳过
