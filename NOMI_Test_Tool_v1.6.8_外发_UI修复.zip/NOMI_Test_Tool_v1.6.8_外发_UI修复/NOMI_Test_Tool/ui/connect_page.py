# ui/connect_page.py
# 阶段0：连接设备 - 自动建隧道(纯 paramiko) + ADB/SSH 状态检测 + 手动隧道命令
# 隧道连接方式与 legacy_conn_tool 一致（用户实车验证的手动命令）:
#   NT3.0/ALPS 跳板: root @ 192.0.2.1:22 / CHANGE_ME
#   NT3.5 跳板:      shell @ 192.0.2.1:22 / CHANGE_ME
#   转发: 本地 192.0.2.2:22/7777 -> 车内 192.0.2.4:22(QNX/shell) / 192.0.2.14:7777(ADB)
#   QNX SSH: root / CHANGE_ME（经 192.0.2.2:22 登录）
# 隧道凭据可在界面「编辑隧道配置」中修改并保存到 tunnel_config.json
import copy
import json
import os
import subprocess
import threading
import time

from PyQt5.QtCore import QThread, QTimer, pyqtSignal
from PyQt5.QtWidgets import (QApplication, QComboBox, QDialog, QDialogButtonBox,
                             QFileDialog, QFormLayout, QFrame, QGroupBox,
                             QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                             QPushButton, QTextEdit, QVBoxLayout, QWidget)

from core import app_log
from core.log_manager import (clear_android_logs, clear_qnx_slog, pull_logd,
                              pull_slog)
from core.ssh_executor import SSHClientWrapper
from core.tunnel_manager import check_port_open, shared_manager
from ui.log_utils import trim_text_edit_max_blocks

try:
    import paramiko
except ImportError:
    paramiko = None

# 运行中的后台线程兜底引用：防止页面销毁时 QThread 被回收导致进程闪退
_KEEP_ALIVE = []

# 用户自定义隧道配置持久化文件（与工具同目录）
_TUNNEL_CONFIG_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "tunnel_config.json")

# ==================== 平台配置 ====================
PLATFORM_CONFIG = {
    "NT2.0 - NT2.2": {
        "need_tunnel": False,
        "adb_host": "192.0.2.11",
        "adb_port": "7777",
        "qnx_host": "192.0.2.11",
        "qnx_user": "root",
        "qnx_password": "CHANGE_ME",
    },
    "NT2.5": {
        "need_tunnel": False,
        "adb_host": "192.0.2.16",
        "adb_port": "7777",
        "qnx_host": "192.0.2.16",
        "qnx_user": "root",
        "qnx_password": "CHANGE_ME",
    },
    "FY": {
        "need_tunnel": False,
        "adb_host": "198.18.1.18",
        "adb_port": "7777",
        "qnx_host": "198.18.1.11",
        "qnx_user": "root",
        "qnx_password": "CHANGE_ME",
    },
    "NT3.0-NIO / ALPS": {
        "need_tunnel": True,
        "adb_host": "192.0.2.2",
        "adb_port": "7777",
        "qnx_host": "192.0.2.2",
        "qnx_user": "root",
        "qnx_password": "CHANGE_ME",
        # 跳板凭据 = 用户实车验证: root @ 192.0.2.1 / CHANGE_ME
        "tunnel_host": "192.0.2.1",
        "tunnel_port": 22,
        "tunnel_user": "root",
        "tunnel_password": "CHANGE_ME",
        # 隧道映射: 本地 192.0.2.2:22 -> 远程 192.0.2.4:22 (QNX SSH)
        #          本地 192.0.2.2:7777 -> 远程 192.0.2.14:7777 (Android ADB)
        "tunnels": [
            {"local": ("192.0.2.2", 22), "remote": ("192.0.2.4", 22)},
            {"local": ("192.0.2.2", 7777), "remote": ("192.0.2.14", 7777)},
        ],
    },
    "NT3.5-NIO": {
        # NT3.5 无独立 QNX 子系统，22 口登录为 shell（非 QNX top2/slog 采集源）；
        # 目标 IP 暂与 NT3.0 相同，待实车确认后可在此单独调整
        "need_tunnel": True,
        "adb_host": "192.0.2.2",
        "adb_port": "7777",
        "qnx_host": "192.0.2.2",
        "qnx_user": "root",
        "qnx_password": "CHANGE_ME",
        "tunnel_host": "192.0.2.1",
        "tunnel_port": 22,
        "tunnel_user": "shell",
        "tunnel_password": "CHANGE_ME",
        "tunnels": [
            {"local": ("192.0.2.2", 22), "remote": ("192.0.2.4", 22)},
            {"local": ("192.0.2.2", 7777), "remote": ("192.0.2.14", 7777)},
        ],
    },
}

# 出厂默认平台配置（在 load_tunnel_config 覆盖前固化，供「恢复默认」使用）
_DEFAULT_PLATFORM_CONFIG = copy.deepcopy(PLATFORM_CONFIG)


def load_tunnel_config():
    """加载用户自定义隧道配置（tunnel_config.json），覆盖内置 PLATFORM_CONFIG
    格式: {"平台名": {"tunnel_host": ..., "tunnel_port": ...,
                      "tunnel_user": ..., "tunnel_password": ...,
                      "qnx_user": ..., "qnx_password": ...}}"""
    if not os.path.exists(_TUNNEL_CONFIG_FILE):
        return
    try:
        with open(_TUNNEL_CONFIG_FILE, "r", encoding="utf-8") as f:
            user_cfg = json.load(f)
        for platform, overrides in user_cfg.items():
            if platform in PLATFORM_CONFIG and isinstance(overrides, dict):
                for key in ("tunnel_host", "tunnel_port", "tunnel_user",
                            "tunnel_password", "qnx_user", "qnx_password"):
                    if key in overrides and overrides[key]:
                        PLATFORM_CONFIG[platform][key] = overrides[key]
    except Exception:
        # 配置文件损坏时不阻断启动，沿用内置配置
        pass


# 启动时加载一次用户自定义隧道配置
load_tunnel_config()


def save_tunnel_config(platform, overrides):
    """保存某平台的自定义隧道配置到 tunnel_config.json"""
    data = {}
    if os.path.exists(_TUNNEL_CONFIG_FILE):
        try:
            with open(_TUNNEL_CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
    data[platform] = overrides
    with open(_TUNNEL_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ==================== 连接/检测日志收集 ====================
# 目标: 连接设备页的每一步（跳板校验/SSH/绑定/转发/adb）都同时进
# 1) 界面日志  2) connection.log 文件  3) 最近一次会话缓存(带入执行测试日志)
# 性能: connection.log 的磁盘写入放后台线程批量落盘，避免 UI 线程被文件 I/O 卡住。
_CONN_RING = []
_CONN_LOCK = threading.Lock()
_CONN_FILE = os.path.join(os.path.dirname(_TUNNEL_CONFIG_FILE),
                          "connection.log")
_CONN_FILE_QUEUE = []
_CONN_FILE_WRITER = None
_CONN_FILE_STOP = threading.Event()
_CONN_FILE_MAX_LINES = 8000   # 内存队列上限，防极端日志爆内存


def _conn_file_flush():
    """把 connection.log 队列一次写入磁盘（后台线程调用）"""
    global _CONN_FILE_QUEUE
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        with _CONN_LOCK:
            _CONN_FILE_QUEUE.clear()
        return
    with _CONN_LOCK:
        if not _CONN_FILE_QUEUE:
            return
        lines, _CONN_FILE_QUEUE = _CONN_FILE_QUEUE, []
    try:
        if os.path.exists(_CONN_FILE) and os.path.getsize(_CONN_FILE) > 800 * 1024:
            os.replace(_CONN_FILE, _CONN_FILE + ".old")
        with open(_CONN_FILE, "a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass


def _conn_file_writer_loop():
    while not _CONN_FILE_STOP.wait(0.5):
        _conn_file_flush()
    _conn_file_flush()


def _ensure_conn_writer():
    global _CONN_FILE_WRITER
    if _CONN_FILE_WRITER is None or not _CONN_FILE_WRITER.is_alive():
        _CONN_FILE_STOP.clear()
        _CONN_FILE_WRITER = threading.Thread(
            target=_conn_file_writer_loop, daemon=True,
            name="conn-log-writer")
        _CONN_FILE_WRITER.start()


def begin_conn_log():
    """开始一次新的连接/检测会话，清空最近会话缓存"""
    global _CONN_RING
    with _CONN_LOCK:
        _CONN_RING = []


def conn_log_push(line: str):
    """追加一行到最近会话缓存（供测试日志引用）"""
    with _CONN_LOCK:
        _CONN_RING.append(line)
        if len(_CONN_RING) > 1000:
            del _CONN_RING[:-1000]


def conn_log_snapshot(max_lines: int = 300):
    """返回最近一次连接/检测会话的日志副本"""
    with _CONN_LOCK:
        return list(_CONN_RING[-max_lines:])


def conn_log_file_append(line: str):
    """持久化到 connection.log（仅入队，后台线程批量写；带轮转防无限增长）"""
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        return   # 离屏测试/自检环境不落盘，避免污染
    with _CONN_LOCK:
        _CONN_FILE_QUEUE.append(line)
        if len(_CONN_FILE_QUEUE) > _CONN_FILE_MAX_LINES:
            del _CONN_FILE_QUEUE[:-_CONN_FILE_MAX_LINES]
    _ensure_conn_writer()


def check_ssh_with_paramiko(host, user, password, timeout=5):
    """用 paramiko 完整验证 SSH 可登录并执行命令"""
    if paramiko is None:
        return False, "paramiko 未安装"
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=host, username=user, password=password,
                       timeout=timeout, allow_agent=False, look_for_keys=False)
        _, stdout, _ = client.exec_command("echo ok", timeout=timeout)
        output = stdout.read().decode(errors="replace").strip()
        client.close()
        return "ok" in output, ""
    except Exception as e:
        try:
            client.close()
        except Exception:
            pass
        return False, str(e)


def build_manual_tunnel_cmd(cfg) -> str:
    """生成 Windows CMD 可直接执行的手动隧道命令（含所有端口映射）"""
    if not cfg.get("need_tunnel"):
        return ""
    parts = [f'ssh -N -o StrictHostKeyChecking=no']
    for t in cfg["tunnels"]:
        (lh, lp), (rh, rp) = t["local"], t["remote"]
        parts.append(f"-L {lh}:{lp}:{rh}:{rp}")
    parts.append(f'{cfg["tunnel_user"]}@{cfg["tunnel_host"]} -p {cfg["tunnel_port"]}')
    return " ".join(parts)


class TunnelConfigDialog(QDialog):
    """编辑当前平台的隧道/QNX 凭据，保存到 tunnel_config.json"""

    def __init__(self, platform_name, cfg, parent=None):
        super().__init__(parent)
        self.platform_name = platform_name
        self.cfg = cfg
        self.default = _DEFAULT_PLATFORM_CONFIG.get(platform_name, {})
        self.setWindowTitle(f"编辑隧道配置 - {platform_name}")
        self.setMinimumWidth(420)
        layout = QVBoxLayout(self)

        form = QFormLayout()
        self.host_edit = QLineEdit(str(cfg.get("tunnel_host", "")))
        self.port_edit = QLineEdit(str(cfg.get("tunnel_port", 22)))
        self.user_edit = QLineEdit(str(cfg.get("tunnel_user", "")))
        self.pwd_edit = QLineEdit(str(cfg.get("tunnel_password", "")))
        self.pwd_edit.setEchoMode(QLineEdit.Password)
        self.qnx_user_edit = QLineEdit(str(cfg.get("qnx_user", "root")))
        self.qnx_pwd_edit = QLineEdit(str(cfg.get("qnx_password", "")))
        self.qnx_pwd_edit.setEchoMode(QLineEdit.Password)
        form.addRow("跳板机地址:", self.host_edit)
        form.addRow("跳板机端口:", self.port_edit)
        form.addRow("跳板机账号:", self.user_edit)
        form.addRow("跳板机密码:", self.pwd_edit)
        form.addRow("登录账号:", self.qnx_user_edit)
        form.addRow("登录密码:", self.qnx_pwd_edit)
        layout.addLayout(form)

        tip = QLabel(
            f"保存后立即生效（写入 tunnel_config.json）\n"
            f"当前平台出厂默认跳板: {self.default.get('tunnel_user', '-')}"
            f" @ {self.default.get('tunnel_host', '-')}，"
            f"可点「恢复默认」还原")
        tip.setStyleSheet("color: #9aa3b2; font-size: 11px;")
        tip.setWordWrap(True)
        layout.addWidget(tip)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("保存")
        buttons.button(QDialogButtonBox.Cancel).setText("取消")
        self.reset_btn = QPushButton("恢复默认")
        buttons.addButton(self.reset_btn, QDialogButtonBox.ResetRole)
        self.reset_btn.clicked.connect(self.reset_fields)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def reset_fields(self):
        """把当前平台的出厂默认凭据回填到表单"""
        d = self.default
        if not d:
            return
        self.host_edit.setText(str(d.get("tunnel_host", "")))
        self.port_edit.setText(str(d.get("tunnel_port", 22)))
        self.user_edit.setText(str(d.get("tunnel_user", "")))
        self.pwd_edit.setText(str(d.get("tunnel_password", "")))
        self.qnx_user_edit.setText(str(d.get("qnx_user", "root")))
        self.qnx_pwd_edit.setText(str(d.get("qnx_password", "")))

    def differs_from_default(self, overrides) -> bool:
        d = self.default
        if not d:
            return False
        return (overrides.get("tunnel_host") != d.get("tunnel_host")
                or str(overrides.get("tunnel_port", 22)) != str(d.get("tunnel_port", 22))
                or overrides.get("tunnel_user") != d.get("tunnel_user")
                or overrides.get("tunnel_password") != d.get("tunnel_password")
                or overrides.get("qnx_user") != d.get("qnx_user", "root")
                or overrides.get("qnx_password") != d.get("qnx_password"))

    def get_overrides(self):
        try:
            port = int(self.port_edit.text().strip() or "22")
        except ValueError:
            port = 22
        return {
            "tunnel_host": self.host_edit.text().strip(),
            "tunnel_port": port,
            "tunnel_user": self.user_edit.text().strip(),
            "tunnel_password": self.pwd_edit.text(),
            "qnx_user": self.qnx_user_edit.text().strip(),
            "qnx_password": self.qnx_pwd_edit.text(),
        }


# ==================== 自动连接工作线程 ====================
class AutoConnectWorker(QThread):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool, bool)  # ssh_ok, adb_ok

    def __init__(self, platform_name):
        super().__init__()
        self.platform_name = platform_name
        self.cfg = PLATFORM_CONFIG[platform_name]
        self._stopped = False

    def _emit(self, msg):
        if not self._stopped:
            self.log_signal.emit(msg)

    def run(self):
        adb_ok = False
        ssh_ok = False
        cfg = self.cfg

        # 1. 需要隧道则先自动建立（纯 paramiko，不依赖 sshtunnel）
        if cfg.get("need_tunnel", False):
            ports = [(t["local"][0], t["local"][1]) for t in cfg["tunnels"]]
            if all(check_port_open(h, p, 1.0) for h, p in ports):
                self._emit("隧道端口已在监听，跳过建立")
            else:
                self._emit("开始自动建立 SSH 隧道...")
                mgr = shared_manager()
                all_ok = True
                for t in cfg["tunnels"]:
                    (lh, lp), (rh, rp) = t["local"], t["remote"]
                    self._emit(f"建立隧道: {lh}:{lp} -> {rh}:{rp}")
                    ok, msg = mgr.create_tunnel(
                        ssh_host=cfg["tunnel_host"],
                        ssh_port=cfg["tunnel_port"],
                        ssh_user=cfg["tunnel_user"],
                        ssh_password=cfg["tunnel_password"],
                        local_host=lh, local_port=lp,
                        remote_host=rh, remote_port=rp,
                    )
                    self._emit(f"  {'OK' if ok else 'FAIL'}: {msg}")
                    if not ok:
                        all_ok = False
                        break
                if not all_ok:
                    self._emit("")
                    self._emit("自动建隧道失败! 请手动建立，步骤如下:")
                    self._emit("  1) 点击下方「复制手动隧道命令」按钮")
                    self._emit("  2) 打开 CMD 粘贴执行，输入密码后保持窗口不关闭")
                    self._emit(f"     隧道密码: {cfg['tunnel_password']}")
                    self._emit("  3) 回到本页点击「手动检测」")
                    self._emit("  4) 两个隧道都显示「已监听」后再开始测试")
                    self.finished_signal.emit(False, False)
                    return
                self._emit("所有隧道已建立，等待稳定...")
                time.sleep(2)

        # 2/3. 连接并检测 ADB
        # 若失败（常见本机 adb 守护进程卡死 -> device offline），自动重启一次
        # 本地 adb server 再重试；正常连通时不会执行重启，不影响已连状态。
        adb_addr = f"{cfg['adb_host']}:{cfg['adb_port']}"
        for attempt in (1, 2):
            if self._stopped:
                self.finished_signal.emit(False, False)
                return
            if attempt == 2:
                self._emit("首次 ADB 连接失败，重启本机 adb server 后重试一次...")
                try:
                    subprocess.run("adb kill-server", shell=True,
                                   capture_output=True, timeout=15)
                    time.sleep(1)
                    subprocess.run("adb start-server", shell=True,
                                   capture_output=True, timeout=15)
                    time.sleep(2)
                except Exception as e:
                    self._emit(f"adb server 重启异常: {e}")

            self._emit(f"adb connect {adb_addr}")
            try:
                subprocess.run(f"adb connect {adb_addr}", shell=True,
                               capture_output=True, timeout=6)
                if self._stopped:
                    self.finished_signal.emit(False, False)
                    return
                self._emit("adb root")
                subprocess.run("adb root", shell=True,
                               capture_output=True, timeout=6)
                time.sleep(1)
            except Exception as e:
                self._emit(f"adb 命令异常: {e}")

            # 检测 ADB
            try:
                result = subprocess.run("adb shell echo ok", shell=True,
                                        capture_output=True, timeout=5,
                                        text=True)
                if "ok" in (result.stdout or ""):
                    adb_ok = True
                    self._emit(f"ADB 连接正常 ({adb_addr})")
                    break
                detail = (result.stderr or "").strip() or "无输出"
                self._emit(f"ADB 连接失败: {detail}")
            except Exception as e:
                self._emit(f"ADB 异常: {e}")
        if self._stopped:
            self.finished_signal.emit(False, False)
            return

        # 4. 检测 SSH
        qnx_host = cfg["qnx_host"]
        self._emit(f"检测 SSH: {qnx_host}:22 ...")
        if check_port_open(qnx_host, 22, timeout=2):
            ok, err = check_ssh_with_paramiko(
                qnx_host, cfg["qnx_user"], cfg["qnx_password"], timeout=5)
            if ok:
                ssh_ok = True
                self._emit("SSH 认证成功")
            else:
                self._emit(f"SSH 认证失败: {err}")
        else:
            self._emit(f"端口 22 不可达（隧道未建立或 QNX 未就绪）")

        self.finished_signal.emit(ssh_ok, adb_ok)

    def stop(self):
        self._stopped = True


# ==================== 手动检测工作线程 ====================
class CheckWorker(QThread):
    log_signal = pyqtSignal(str)
    status_signal = pyqtSignal(bool, bool)

    def __init__(self, platform_name):
        super().__init__()
        self.platform_name = platform_name
        self.cfg = PLATFORM_CONFIG[platform_name]
        self._stopped = False

    def _emit(self, msg):
        if not self._stopped:
            self.log_signal.emit(msg)

    def run(self):
        adb_ok = False
        ssh_ok = False
        cfg = self.cfg

        # ADB
        self._emit("检测 ADB...")
        try:
            result = subprocess.run("adb shell echo ok", shell=True,
                                    capture_output=True, timeout=5, text=True)
            if "ok" in (result.stdout or ""):
                adb_ok = True
                self._emit("ADB 连接正常")
            else:
                self._emit(f"ADB 未连接: {(result.stderr or '').strip()}")
        except Exception as e:
            self._emit(f"ADB 异常: {e}")
        if self._stopped:
            self.status_signal.emit(False, False)
            return

        # SSH
        self._emit(f"检测 SSH: {cfg['qnx_host']}:22 ...")
        if check_port_open(cfg["qnx_host"], 22, timeout=2):
            ok, err = check_ssh_with_paramiko(
                cfg["qnx_host"], cfg["qnx_user"], cfg["qnx_password"], timeout=5)
            if ok:
                ssh_ok = True
                self._emit("SSH 认证成功")
            else:
                self._emit(f"SSH 认证失败: {err}")
        else:
            self._emit("端口 22 不可达（隧道未建立或 QNX 未就绪）")

        self.status_signal.emit(adb_ok, ssh_ok)

    def stop(self):
        self._stopped = True


# ==================== 日志管理后台线程 ====================
class LogOpWorker(QThread):
    """车机日志操作（拉取 logd / 拉取 slog / 清空日志），避免阻塞 UI"""
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool, str)   # 成功, 结果说明(路径或错误)

    def __init__(self, op: str, target_dir: str = "", ssh_cfg: dict = None):
        super().__init__()
        self.op = op                # pull_logd / pull_slog / pull_both / clear
        self.target_dir = target_dir
        self.ssh_cfg = ssh_cfg or {}

    def _log(self, msg):
        try:
            self.log_signal.emit(msg)
        except Exception:
            pass

    def _open_ssh(self):
        """按当前平台配置连接 QNX SSH，返回 wrapper（失败抛异常）"""
        ssh = SSHClientWrapper()
        ssh.configure(self.ssh_cfg.get("ssh_host", ""),
                      self.ssh_cfg.get("ssh_user", "root"),
                      self.ssh_cfg.get("ssh_password", ""))
        ssh.connect(timeout=10)
        return ssh

    def run(self):
        try:
            if self.op == "pull_logd":
                ok, msg = pull_logd(self.target_dir, log_cb=self._log)
                self.finished_signal.emit(ok, msg)
                return

            if self.op == "pull_slog":
                if not self.ssh_cfg.get("ssh_host"):
                    self.finished_signal.emit(False, "当前平台无 QNX SSH 配置")
                    return
                ssh = self._open_ssh()
                try:
                    ok, msg = pull_slog(ssh, self.target_dir,
                                        log_cb=self._log)
                finally:
                    try:
                        ssh.close()
                    except Exception:
                        pass
                self.finished_signal.emit(ok, msg)
                return

            if self.op == "pull_both":
                # slog + logd 一起拉（本地各自落 slog/ 与 logd/ 子目录）
                parts = []
                all_ok = True
                self._log("== [1/2] 拉取安卓 logd ==")
                ok, msg = pull_logd(self.target_dir, log_cb=self._log)
                if ok:
                    parts.append(f"logd -> {msg}")
                else:
                    all_ok = False
                    parts.append(f"logd: {msg[:120]}")
                self._log("== [2/2] 拉取 QNX slog（整目录） ==")
                if not self.ssh_cfg.get("ssh_host"):
                    all_ok = False
                    parts.append("slog: 当前平台无 QNX SSH 配置，跳过")
                else:
                    ssh = None
                    try:
                        ssh = self._open_ssh()
                        ok, msg = pull_slog(ssh, self.target_dir,
                                            log_cb=self._log)
                        if ok:
                            parts.append(f"slog -> {msg}")
                        else:
                            all_ok = False
                            parts.append(f"slog: {msg[:120]}")
                    except Exception as e:
                        all_ok = False
                        parts.append(f"slog: SSH 连接失败: {e}")
                    finally:
                        if ssh:
                            try:
                                ssh.close()
                            except Exception:
                                pass
                self.finished_signal.emit(all_ok, "\n".join(parts))
                return

            if self.op == "clear":
                # 安卓侧（logcat + logd 旧文件）与 QNX slog 各自清理，失败不互相阻断
                problems = []
                ok, msg = clear_android_logs(log_cb=self._log)
                if not ok:
                    problems.append(f"安卓: {msg}")
                ssh_ok_msg = ""
                if self.ssh_cfg.get("ssh_host"):
                    try:
                        ssh = self._open_ssh()
                        try:
                            ok, msg = clear_qnx_slog(ssh, log_cb=self._log)
                            if not ok:
                                problems.append(f"QNX: {msg}")
                            else:
                                ssh_ok_msg = msg
                        finally:
                            ssh.close()
                    except Exception as e:
                        problems.append(f"QNX SSH 连接失败: {e}")
                else:
                    self._log("当前平台无 QNX SSH 配置，跳过 slog 清空")
                if problems:
                    self.finished_signal.emit(False, "; ".join(problems))
                else:
                    self.finished_signal.emit(True, "安卓 + QNX 车机日志已清空"
                                              + (f"（{ssh_ok_msg}）" if ssh_ok_msg else ""))
                return

            self.finished_signal.emit(False, f"未知操作: {self.op}")
        except Exception as e:
            self.finished_signal.emit(False, f"日志操作异常: {e}")


# ==================== UI 页面 ====================
class ConnectPage(QWidget):
    status_changed = pyqtSignal(bool, bool)  # adb_ok, ssh_ok

    def __init__(self):
        super().__init__()
        self.worker = None
        self.auto_worker = None
        self.log_worker = None
        self.adb_ok = False
        self.ssh_ok = False
        self.current_platform = "NT3.0-NIO / ALPS"
        self.init_ui()

    # ==================== UI ====================
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(10, 10, 10, 10)

        title = QLabel("连接设备")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #e8eaee;")
        layout.addWidget(title)

        # 平台选择 + 手动命令按钮
        top_h = QHBoxLayout()
        top_h.addWidget(QLabel("平台:"))
        self.platform_combo = QComboBox()
        self.platform_combo.addItems(list(PLATFORM_CONFIG.keys()))
        self.platform_combo.setCurrentText(self.current_platform)
        self.platform_combo.currentTextChanged.connect(self.on_platform_changed)
        top_h.addWidget(self.platform_combo)

        self.copy_cmd_btn = QPushButton("复制手动隧道命令")
        self.copy_cmd_btn.setToolTip(
            "自动建隧道失败时，复制此命令到 CMD 手动执行\n"
            "（执行后输入隧道密码，窗口保持打开）")
        self.copy_cmd_btn.clicked.connect(self.copy_manual_cmd)
        top_h.addWidget(self.copy_cmd_btn)

        self.edit_tunnel_btn = QPushButton("编辑隧道配置")
        self.edit_tunnel_btn.setToolTip(
            "修改跳板机/QNX 的账号密码（保存到 tunnel_config.json），\n"
            "默认凭据与 legacy_conn_tool 一致")
        self.edit_tunnel_btn.clicked.connect(self.edit_tunnel_config)
        top_h.addWidget(self.edit_tunnel_btn)
        top_h.addStretch()
        layout.addLayout(top_h)

        # 信息提示
        self.info_label = QLabel()
        self.info_label.setStyleSheet(
            "color: #9aa3b2; padding: 6px; background-color: #0d1016;"
            " border-radius: 4px;")
        self.info_label.setWordWrap(True)
        self.update_info_label(self.current_platform)
        layout.addWidget(self.info_label)

        # 隧道状态
        tunnel_frame = QFrame()
        tunnel_frame.setStyleSheet(
            "QFrame { background-color: #16233f; border-radius: 4px; }")
        tunnel_layout = QHBoxLayout(tunnel_frame)
        tunnel_layout.setContentsMargins(8, 6, 8, 6)
        self.tunnel_qnx_label = QLabel("QNX隧道: 未监听")
        self.tunnel_qnx_label.setStyleSheet("font-weight: bold; color: #ef4444;")
        tunnel_layout.addWidget(self.tunnel_qnx_label)
        self.tunnel_adb_label = QLabel("ADB隧道: 未监听")
        self.tunnel_adb_label.setStyleSheet("font-weight: bold; color: #ef4444;")
        tunnel_layout.addWidget(self.tunnel_adb_label)
        tunnel_layout.addStretch()
        layout.addWidget(tunnel_frame)

        self.tunnel_timer = QTimer(self)
        self.tunnel_timer.timeout.connect(self.update_tunnel_status)
        self.tunnel_timer.start(3000)

        # 状态指示 + 操作按钮
        status_frame = QFrame()
        status_frame.setStyleSheet(
            "QFrame { background-color: #181b22; border: 1px solid #262b36;"
            " border-radius: 4px; }")
        status_layout = QHBoxLayout(status_frame)
        status_layout.setContentsMargins(10, 8, 10, 8)

        self.adb_indicator = QLabel("ADB (Android): 未连接")
        self.adb_indicator.setStyleSheet(
            "font-weight: bold; color: #ef4444;")
        status_layout.addWidget(self.adb_indicator)
        self.ssh_indicator = QLabel("SSH (QNX): 未连接")
        self.ssh_indicator.setStyleSheet(
            "font-weight: bold; color: #ef4444;")
        status_layout.addWidget(self.ssh_indicator)
        status_layout.addStretch()

        self.auto_btn = QPushButton("自动连接")
        self.auto_btn.setFixedWidth(110)
        self.auto_btn.setStyleSheet("""
            QPushButton { background-color: #22c55e; color: white;
                padding: 7px 14px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #2fd06b; }
            QPushButton:disabled { background-color: #1e3b28; }
        """)
        self.auto_btn.clicked.connect(self.start_auto_connect)
        status_layout.addWidget(self.auto_btn)

        self.check_btn = QPushButton("手动检测")
        self.check_btn.setFixedWidth(110)
        self.check_btn.setStyleSheet("""
            QPushButton { background-color: #3b82f6; color: white;
                padding: 7px 14px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #4d94ff; }
            QPushButton:disabled { background-color: #20395a; }
        """)
        self.check_btn.clicked.connect(self.start_check)
        status_layout.addWidget(self.check_btn)
        layout.addWidget(status_frame)

        # ---- 日志管理（手动拉取 / 清空车机日志） ----
        # 配色约定: 「获取全量日志」绿色; 单项拉取(logd/slog)黄色; 「清空车机日志」红色
        log_group = QGroupBox("日志管理（拉取车机安卓 logd / QNX slog，或测试前清空旧日志）")
        lg = QHBoxLayout(log_group)
        green_ss = ("QPushButton { background-color: #22c55e; color: white;"
                    " font-weight: bold; padding: 5px 14px; border-radius: 4px; }"
                    " QPushButton:hover { background-color: #2fd06b; }"
                    " QPushButton:disabled { background-color: #1e3b28; }")
        yellow_ss = ("QPushButton { background-color: #f59e0b; color: #241a02;"
                     " font-weight: bold; padding: 5px 14px; border-radius: 4px; }"
                     " QPushButton:hover { background-color: #d97706; }"
                     " QPushButton:disabled { background-color: #4a3a12; }")
        red_ss = ("QPushButton { background-color: #dc2626; color: white;"
                  " font-weight: bold; padding: 5px 14px; border-radius: 4px; }"
                  " QPushButton:hover { background-color: #b91c1c; }"
                  " QPushButton:disabled { background-color: #4a242a; }")

        self.pull_both_btn = QPushButton("获取全量日志")
        self.pull_both_btn.setToolTip(
            "一次性拉取 QNX slog 整目录(/blackbox/cdclogs/qnx/slog) "
            "与安卓 logd(/data/misc/nio/logd)\n"
            "在所选目录下分别生成 slog/ 与 logd/ 子目录（等同 scp -r / adb pull）")
        self.pull_both_btn.setStyleSheet(green_ss)
        self.pull_both_btn.clicked.connect(self.on_pull_both_logs)
        lg.addWidget(self.pull_both_btn)

        self.pull_logd_btn = QPushButton("拉取安卓 logd")
        self.pull_logd_btn.setToolTip(
            "拉取车机 /data/misc/nio/logd 整个目录到本机\n"
            "（全量测试结束后也可用，A/B 测试后各自拉取一份）")
        self.pull_logd_btn.setStyleSheet(yellow_ss)
        self.pull_logd_btn.clicked.connect(self.on_pull_logd)
        lg.addWidget(self.pull_logd_btn)

        self.pull_slog_btn = QPushButton("拉取 QNX slog")
        self.pull_slog_btn.setToolTip(
            "拉取 QNX /blackbox/cdclogs/qnx/slog 整个目录（等同 scp -r）")
        self.pull_slog_btn.setStyleSheet(yellow_ss)
        self.pull_slog_btn.clicked.connect(self.on_pull_slog)
        lg.addWidget(self.pull_slog_btn)

        self.clear_logs_btn = QPushButton("清空车机日志")
        self.clear_logs_btn.setToolTip(
            "清空安卓 logcat 缓冲 + /data/misc/nio/logd 旧文件 + QNX slog 缓冲\n"
            "（日志测试开始前建议先清空，保证拉到的都是本轮日志）")
        self.clear_logs_btn.setStyleSheet(red_ss)
        self.clear_logs_btn.clicked.connect(self.on_clear_logs)
        lg.addWidget(self.clear_logs_btn)
        lg.addStretch()
        layout.addWidget(log_group)

        # 日志
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #0a0d12; color: #c9d4e3;
                font-family: Consolas, monospace; font-size: 11px;
                border-radius: 4px;
            }
        """)
        layout.addWidget(self.log_text, 1)

        # 初始检测（父对象挂载：页面销毁时定时器一并销毁，避免悬空回调）
        self.init_check_timer = QTimer(self)
        self.init_check_timer.setSingleShot(True)
        self.init_check_timer.timeout.connect(self.start_check)
        self.init_check_timer.start(500)

    # ==================== 平台配置 ====================
    def get_platform_config(self):
        return PLATFORM_CONFIG.get(self.current_platform, {})

    def update_info_label(self, platform_name):
        cfg = PLATFORM_CONFIG[platform_name]
        if cfg.get("need_tunnel", False):
            info = (f"平台 {platform_name} 需要 SSH 隧道 | "
                    f"隧道服务器 {cfg['tunnel_host']} (用户 {cfg['tunnel_user']}) | "
                    f"ADB {cfg['adb_host']}:{cfg['adb_port']} | "
                    f"QNX SSH {cfg['qnx_host']}")
        else:
            info = (f"平台 {platform_name} 直连 | "
                    f"ADB {cfg['adb_host']}:{cfg['adb_port']} | "
                    f"QNX SSH {cfg['qnx_host']}")
        self.info_label.setText(info)
        # 手动命令按钮只在需要隧道的平台可用
        self.copy_cmd_btn.setEnabled(cfg.get("need_tunnel", False))

    def on_platform_changed(self, platform_name):
        """切换平台：只刷新界面状态，不自动拉起后台检测线程
        （自动检测由启动时的延时定时器和用户点击「手动检测」触发，
          避免线程堆积与页面销毁时线程仍在运行导致的闪退）"""
        self.current_platform = platform_name
        self.update_info_label(platform_name)
        self.update_tunnel_status()

    # ==================== 隧道状态 ====================
    def update_tunnel_status(self):
        cfg = PLATFORM_CONFIG.get(self.current_platform, {})
        if not cfg.get("need_tunnel", False):
            for lbl in (self.tunnel_qnx_label, self.tunnel_adb_label):
                lbl.setText(lbl.text().split(":")[0] + ": 不需要")
                lbl.setStyleSheet("font-weight: bold; color: #9aa3b2;")
            return
        tunnels = cfg.get("tunnels", [])
        pairs = [(self.tunnel_qnx_label, tunnels[0] if tunnels else None),
                 (self.tunnel_adb_label, tunnels[1] if len(tunnels) > 1 else None)]
        for lbl, t in pairs:
            if not t:
                continue
            # 0.5s 超时：本地静态 IP 正常情况立刻返回，避免 UI 卡顿
            listening = check_port_open(t["local"][0], t["local"][1], 0.5)
            color = "#22c55e" if listening else "#ef4444"
            text = "已监听" if listening else "未监听"
            lbl.setText(lbl.text().split(":")[0] + f": {text}")
            lbl.setStyleSheet(f"font-weight: bold; color: {color};")

    # ==================== 手动命令 ====================
    def copy_manual_cmd(self):
        cfg = self.get_platform_config()
        cmd = build_manual_tunnel_cmd(cfg)
        if not cmd:
            return
        clipboard = QApplication.clipboard()
        clipboard.setText(cmd)
        self.append_log("手动隧道命令已复制，请粘贴到 CMD 执行:")
        self.append_log(f"  {cmd}")
        self.append_log(f"  密码: {cfg['tunnel_password']} (输入时不显示，属正常)")
        self.append_log("  执行后保持 CMD 窗口不关闭，然后点「手动检测」")

    # ==================== 隧道配置编辑 ====================
    def edit_tunnel_config(self):
        """编辑当前平台的隧道/QNX 凭据并保存"""
        cfg = self.get_platform_config()
        if not cfg.get("need_tunnel"):
            QMessageBox.information(
                self, "无需配置",
                f"平台 [{self.current_platform}] 为直连模式，无需隧道配置。")
            return
        dialog = TunnelConfigDialog(self.current_platform, cfg, self)
        if dialog.exec_() == QDialog.Accepted:
            overrides = dialog.get_overrides()
            if not overrides["tunnel_host"] or not overrides["tunnel_user"]:
                QMessageBox.warning(self, "配置无效",
                                    "跳板机地址和账号不能为空，未保存")
                return
            if dialog.differs_from_default(overrides):
                ret = QMessageBox.question(
                    self, "自定义凭据确认",
                    "你填写的凭据与出厂默认不同，确认保存吗？\n\n"
                    f"跳板: {overrides['tunnel_user']}"
                    f"@{overrides['tunnel_host']}:{overrides['tunnel_port']}\n"
                    f"登录: {overrides['qnx_user']}@{cfg.get('qnx_host', '')}\n\n"
                    "若不确定，请点「取消」后回到窗口点「恢复默认」。",
                    QMessageBox.Yes | QMessageBox.No)
                if ret != QMessageBox.Yes:
                    return
            try:
                # 1. 更新内存中的配置
                cfg.update(overrides)
                # 2. 持久化到 tunnel_config.json
                save_tunnel_config(self.current_platform, overrides)
            except Exception as e:
                QMessageBox.critical(self, "保存失败", str(e))
                return
            self.append_log(f"隧道配置已保存: 跳板 {cfg['tunnel_user']}@"
                            f"{cfg['tunnel_host']}:{cfg['tunnel_port']} "
                            f"(平台 {self.current_platform})")
            self.update_info_label(self.current_platform)

    # ==================== 状态刷新 ====================
    def update_indicators(self, adb_ok, ssh_ok):
        self.adb_ok = adb_ok
        self.ssh_ok = ssh_ok
        if adb_ok:
            self.adb_indicator.setText("ADB (Android): 已连接")
            self.adb_indicator.setStyleSheet("font-weight: bold; color: #22c55e;")
        else:
            self.adb_indicator.setText("ADB (Android): 未连接")
            self.adb_indicator.setStyleSheet("font-weight: bold; color: #ef4444;")
        if ssh_ok:
            self.ssh_indicator.setText("SSH (QNX): 已连接")
            self.ssh_indicator.setStyleSheet("font-weight: bold; color: #22c55e;")
        else:
            self.ssh_indicator.setText("SSH (QNX): 未连接")
            self.ssh_indicator.setStyleSheet("font-weight: bold; color: #ef4444;")
        self.status_changed.emit(adb_ok, ssh_ok)

    def append_log(self, text):
        self.log_text.append(text)
        cursor = self.log_text.textCursor()
        cursor.movePosition(cursor.End)
        self.log_text.setTextCursor(cursor)
        # 长日志裁剪，防止界面越用越卡
        trim_text_edit_max_blocks(self.log_text)
        # 同步收集: 供 connection.log 与「执行测试」日志引用
        conn_log_push(text)
        conn_log_file_append(text)
        # 镜像到会话运行日志文件（未初始化时为安全空操作）
        app_log.ui(text)

    # ==================== 检测/连接 ====================
    def start_check(self):
        if self.worker and self.worker.isRunning():
            return
        begin_conn_log()
        self.check_btn.setEnabled(False)
        self.auto_btn.setEnabled(False)
        self.append_log(f"检测平台 [{self.current_platform}] ...")
        self.worker = CheckWorker(self.current_platform)
        self.worker.log_signal.connect(self.append_log)
        self.worker.status_signal.connect(self.on_check_finished)
        self.worker.start()

    def on_check_finished(self, adb_ok, ssh_ok):
        self.update_indicators(adb_ok, ssh_ok)
        self.check_btn.setEnabled(True)
        self.auto_btn.setEnabled(True)
        if not (adb_ok and ssh_ok):
            cfg = self.get_platform_config()
            if cfg.get("need_tunnel"):
                self.append_log("未就绪! 可点击「自动连接」，或复制手动命令在 CMD 建隧道")
        self.append_log("检测完成")

    def start_auto_connect(self):
        if self.auto_worker and self.auto_worker.isRunning():
            self.append_log("正在连接中，请稍候...")
            return
        begin_conn_log()
        self.auto_btn.setEnabled(False)
        self.check_btn.setEnabled(False)
        self.log_text.clear()
        self.append_log(f"启动自动连接 (平台: {self.current_platform}) ...")
        self.auto_worker = AutoConnectWorker(self.current_platform)
        self.auto_worker.log_signal.connect(self.append_log)
        self.auto_worker.finished_signal.connect(self.on_auto_connect_finished)
        self.auto_worker.start()

    def on_auto_connect_finished(self, ssh_ok, adb_ok):
        self.update_indicators(adb_ok, ssh_ok)
        self.auto_btn.setEnabled(True)
        self.check_btn.setEnabled(True)
        if ssh_ok and adb_ok:
            self.append_log("自动连接成功! 所有通道就绪，可到「执行测试」页开始。")
        elif not (ssh_ok or adb_ok):
            self.append_log("自动连接失败，请按上方日志提示手动建立隧道后「手动检测」。")
        else:
            self.append_log("部分通道未就绪，请检查日志（adb root / 隧道状态）。")

    # ==================== 日志管理 ====================
    def _default_log_dir(self) -> str:
        """日志保存默认目录: 优先取「TTS 配置」页的输出根目录"""
        try:
            main = self.window()
            if main and hasattr(main, "config_page"):
                return main.config_page.output_root
        except Exception:
            pass
        return os.path.join(os.path.expanduser("~"), "NOMI_Test_Data")

    def _get_ssh_cfg(self) -> dict:
        cfg = self.get_platform_config()
        return {
            "ssh_host": cfg.get("qnx_host", ""),
            "ssh_user": cfg.get("qnx_user", "root"),
            "ssh_password": cfg.get("qnx_password", ""),
        }

    def _set_log_btns(self, enabled: bool):
        for btn in (self.pull_both_btn, self.pull_logd_btn,
                    self.pull_slog_btn, self.clear_logs_btn):
            btn.setEnabled(enabled)

    def _run_log_op(self, op: str, target_dir: str = ""):
        """启动后台日志操作线程"""
        if self.log_worker and self.log_worker.isRunning():
            QMessageBox.warning(self, "任务进行中", "请等待当前日志操作完成")
            return
        self._set_log_btns(False)
        self.log_worker = LogOpWorker(op, target_dir, self._get_ssh_cfg())
        self.log_worker.log_signal.connect(self.append_log)
        self.log_worker.finished_signal.connect(self.on_log_op_finished)
        self.log_worker.start()

    def on_log_op_finished(self, ok: bool, msg: str):
        self._set_log_btns(True)
        if ok:
            self.append_log(f"[日志管理] 完成: {msg}")
            QMessageBox.information(self, "完成", msg)
        else:
            self.append_log(f"[日志管理] 失败: {msg}")
            QMessageBox.warning(self, "失败", msg)

    def on_pull_logd(self):
        """拉取车机安卓 logd（选目标目录 -> 后台 adb pull 整目录）"""
        if not self.adb_ok:
            QMessageBox.warning(self, "ADB 未连接",
                                "ADB 未连接，请先连接设备再拉取 logd")
            return
        d = QFileDialog.getExistingDirectory(
            self, "选择 logd 保存位置（将在该目录下创建 logd 子目录）",
            self._default_log_dir())
        if not d:
            return
        self.append_log(f"开始拉取安卓 logd -> {d}")
        self._run_log_op("pull_logd", d)

    def on_pull_both_logs(self):
        """一次性拉取 slog + logd（各落一个子目录）"""
        if not (self.adb_ok or self.ssh_ok):
            QMessageBox.warning(self, "未连接",
                                "ADB 与 SSH(QNX) 均未连接，请先连接设备")
            return
        d = QFileDialog.getExistingDirectory(
            self, "选择 slog/logd 保存位置（将创建 slog/ 与 logd/ 子目录）",
            self._default_log_dir())
        if not d:
            return
        self.append_log(f"开始拉取 QNX slog + 安卓 logd -> {d}")
        self._run_log_op("pull_both", d)

    def on_pull_slog(self):
        """拉取 QNX slog（scp -r 整目录 /blackbox/cdclogs/qnx/slog）"""
        if not self.ssh_ok:
            QMessageBox.warning(self, "SSH 未连接",
                                "SSH(QNX) 未连接，请先连接设备再拉取 slog")
            return
        d = QFileDialog.getExistingDirectory(
            self, "选择 slog 保存位置（将在该目录下创建 slog 子目录）",
            self._default_log_dir())
        if not d:
            return
        self.append_log(f"开始拉取 QNX slog（整目录）-> {d}")
        self._run_log_op("pull_slog", d)

    def on_clear_logs(self):
        """清空车机日志（安卓 logcat/logd + QNX slog），需二次确认"""
        if not (self.adb_ok or self.ssh_ok):
            QMessageBox.warning(self, "设备未连接",
                                "ADB / SSH 均未连接，无法清空车机日志")
            return
        ret = QMessageBox.question(
            self, "确认清空",
            "将清空:\n"
            "  安卓: logcat 缓冲 + /data/misc/nio/logd 旧文件\n"
            "  QNX:  slog2 实时缓冲\n\n"
            "清空后无法恢复，确认继续?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if ret != QMessageBox.Yes:
            return
        self.append_log("开始清空车机日志（安卓 + QNX）...")
        self._run_log_op("clear")

    def closeEvent(self, event):
        self.shutdown()
        event.accept()

    def shutdown(self):
        """停止后台线程并等待退出（防止 QThread 运行中被销毁导致闪退）"""
        # 先停掉待触发的定时器，防止 shutdown/销毁过程中再拉起检测线程
        for timer_attr in ("init_check_timer", "tunnel_timer"):
            t = getattr(self, timer_attr, None)
            if t is not None:
                try:
                    t.stop()
                except Exception:
                    pass
        for attr in ("worker", "auto_worker", "log_worker"):
            w = getattr(self, attr, None)
            if w is not None:
                try:
                    w.stop()
                    if w.isRunning():
                        w.wait(8000)
                except Exception:
                    pass
                # 若超时仍未退出，保留全局引用避免运行中的 QThread 被回收崩溃
                if w.isRunning():
                    _KEEP_ALIVE.append(w)
