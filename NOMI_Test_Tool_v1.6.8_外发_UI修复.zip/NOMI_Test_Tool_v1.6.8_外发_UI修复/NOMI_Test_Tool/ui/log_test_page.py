# ui/log_test_page.py
# 日志测试页：平台/模块选择 + 语音音频生成 + 试跑 + 一键执行（录屏/控屏/语音）
# 布局: QSplitter 上下分区，上半配置(可滚动) / 下半进度+倒计时+日志(可拖动调高度)
import json
import os
import shutil
from datetime import datetime

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QGridLayout,
                             QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMenu,
                             QMessageBox, QProgressBar, QPushButton,
                             QScrollArea, QSpinBox, QSplitter, QVBoxLayout,
                             QWidget)

from core.constants import (
    CAR_WAKEUP_WORDS, DIR_AUDIO, LOG_MODULE_SECONDS, LOG_TEST_AUDIO_PREFIX,
    LOG_TEST_PLATFORMS, LOG_TEST_PLATFORM_TIPS, NOMI_LOG_TEST_QUERIES,
    SCRCPY_CANDIDATES,
)
from core.log_test_engine import (LogTestConfig, LogTestEngine,
                                  find_audio_file, load_module_config)
from core.tts import synth_one, tts_available
from ui.log_widget import LogPane

_BAD_CHARS = '\\/:*?"<>|'
_KEEP_ALIVE = []   # 运行中引擎线程兜底引用，防页面销毁闪退

# 日志测试平台 -> 「连接设备」页平台名（取 SSH/隧道配置）
PLATFORM_TO_CONNECT = {
    "NT3.0-NIO": "NT3.0-NIO / ALPS",
    "NT2.5-NIO": "NT2.5",
    "NT3.0-ALPS": "NT3.0-NIO / ALPS",
}

_TOOL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# v1.6.2: scrcpy 探测结果缓存（shutil.which 对超长 PATH 每次全量扫描极慢，
# 是切 Tab 卡顿的主要来源之一；改为会话内探测一次，手动选择文件可覆盖）
_scrcpy_cache = {"done": False, "path": ""}


def _detect_scrcpy_impl() -> str:
    for cand in SCRCPY_CANDIDATES:
        try:
            if cand == "scrcpy" or not os.path.isabs(cand):
                found = shutil.which("scrcpy") or shutil.which("scrcpy.exe")
                if found:
                    return found
                continue
            if os.path.exists(cand):
                return cand
        except Exception:
            continue
    return ""


def detect_scrcpy(force: bool = False) -> str:
    """探测 scrcpy 可执行文件（候选路径 + PATH），返回路径或空串。

    force=False 时使用会话内缓存，避免每次切页都做昂贵的 PATH 扫描。
    """
    cache = _scrcpy_cache
    if cache["done"] and not force:
        return cache["path"]
    path = _detect_scrcpy_impl()
    cache["done"] = True
    cache["path"] = path
    return path


def safe_filename(name: str) -> str:
    return "".join(c for c in name if c not in _BAD_CHARS).strip()


# ==================== 语音音频生成线程 ====================
class VoiceGenWorker(QThread):
    """生成日志测试语音: 唤醒词 + 全部语音模块 Query（跳过已存在，失败重试一次）"""
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(int, int, list)   # 成功数, 总数, 失败列表

    def __init__(self, audio_dir: str, wakeup: str, queries: list):
        super().__init__()
        self.audio_dir = audio_dir
        self.wakeup = wakeup
        self.queries = queries
        self._stopped = False

    def stop(self):
        self._stopped = True

    def _emit(self, msg):
        if not self._stopped:
            self.log_signal.emit(msg)

    def run(self):
        os.makedirs(self.audio_dir, exist_ok=True)
        # 任务: (文本, 文件名)，去重
        tasks = []
        if self.wakeup:
            tasks.append((self.wakeup, f"{safe_filename(self.wakeup)}.wav"))
        seen = set()
        for q in self.queries:
            q = str(q).strip()
            if not q or q in seen:
                continue
            seen.add(q)
            tasks.append((q, f"{LOG_TEST_AUDIO_PREFIX}{safe_filename(q)}.wav"))

        ok_count, failed = 0, []
        for text, filename in tasks:
            if self._stopped:
                self._emit("已取消生成")
                break
            base = os.path.splitext(filename)[0]
            if find_audio_file(self.audio_dir, base):
                self._emit(f"跳过已存在: {filename}")
                ok_count += 1
                continue
            self._emit(f"合成中: {filename}")
            path = os.path.join(self.audio_dir, filename)
            ok, err = synth_one(text, path)
            if not ok:
                self._emit(f"  失败({err})，重试一次...")
                try:
                    if os.path.exists(path):
                        os.remove(path)
                except OSError:
                    pass
                ok, err = synth_one(text, path)
            if ok:
                ok_count += 1
                self._emit(f"完成: {filename}")
            else:
                failed.append(f"{filename} ({err})")
                self._emit(f"[失败] {filename}: {err}")
        self.finished_signal.emit(ok_count, len(tasks), failed)


# ==================== 页面 ====================
class LogTestPage(QWidget):
    """日志测试页"""

    def __init__(self):
        super().__init__()
        self.engine = None
        self.voice_worker = None
        self.session_dir = None
        self.splitter = None
        self.log_pane = None
        self.platform_cfg = None       # 当前平台模块配置 dict
        self._scrcpy = ""              # 探测到的 scrcpy 路径
        self.init_ui()
        self.on_platform_changed(self.platform_combo.currentText())

    # ==================== 主窗口引用 ====================
    def _main(self):
        w = self.window()
        return w if hasattr(w, "connect_page") else None

    def get_output_root(self):
        main = self._main()
        if main and hasattr(main, "config_page"):
            return main.config_page.output_root
        return os.path.join(os.path.expanduser("~"), "NOMI_Test_Data")

    def get_ssh_config(self):
        """按日志测试平台映射回「连接设备」页的平台配置取 SSH 参数"""
        main = self._main()
        connect_name = PLATFORM_TO_CONNECT.get(
            self.platform_combo.currentText(), "NT3.0-NIO / ALPS")
        if main and hasattr(main, "connect_page"):
            cfg = main.connect_page.get_platform_config()
            if cfg:
                return {
                    "ssh_host": cfg.get("qnx_host", ""),
                    "ssh_user": cfg.get("qnx_user", "root"),
                    "ssh_password": cfg.get("qnx_password", ""),
                }
        # 兜底: 直接读连接页内置配置
        try:
            from ui.connect_page import PLATFORM_CONFIG
            cfg = PLATFORM_CONFIG.get(connect_name, {})
            return {
                "ssh_host": cfg.get("qnx_host", ""),
                "ssh_user": cfg.get("qnx_user", "root"),
                "ssh_password": cfg.get("qnx_password", ""),
            }
        except Exception:
            return {"ssh_host": "", "ssh_user": "root", "ssh_password": ""}

    # ==================== UI ====================
    def init_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        splitter = QSplitter()
        splitter.setOrientation(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        self.splitter = splitter

        # ---------- 上半: 配置区(可滚动) ----------
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: #0f1115; }")

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setSpacing(6)
        layout.setContentsMargins(8, 8, 8, 8)

        # ---- 基本信息 ----
        info_group = QGroupBox("基本信息")
        g = QGridLayout(info_group)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("平台:"), 0, 0)
        self.platform_combo = QComboBox()
        self.platform_combo.addItems(list(LOG_TEST_PLATFORMS.keys()))
        self.platform_combo.currentTextChanged.connect(self.on_platform_changed)
        g.addWidget(self.platform_combo, 0, 1)
        self.platform_tip_label = QLabel()
        self.platform_tip_label.setStyleSheet("font-size: 11px; color: #9aa3b2;")
        g.addWidget(self.platform_tip_label, 0, 2, 1, 2)

        g.addWidget(QLabel("唤醒词:"), 1, 0)
        self.wakeup_label = QLabel()
        self.wakeup_label.setStyleSheet("font-weight: bold; color: #3b82f6;")
        g.addWidget(self.wakeup_label, 1, 1)
        g.addWidget(QLabel("每模块时长(秒):"), 1, 2)
        self.seconds_spin = QSpinBox()
        self.seconds_spin.setRange(30, 600)
        self.seconds_spin.setValue(LOG_MODULE_SECONDS)
        self.seconds_spin.setToolTip("统一覆盖所有选中模块的采集时长")
        g.addWidget(self.seconds_spin, 1, 3)

        g.addWidget(QLabel("版本号:"), 2, 0)
        self.version_edit = QLineEdit()
        self.version_edit.setPlaceholderText("选填，如 NT3.0-160-daily，用于产物命名")
        g.addWidget(self.version_edit, 2, 1)
        g.addWidget(QLabel("总文件夹名:"), 2, 2)
        self.session_edit = QLineEdit()
        self.session_edit.setPlaceholderText("留空自动生成: 日志测试_版本_平台_时间")
        g.addWidget(self.session_edit, 2, 3)
        layout.addWidget(info_group)

        # ---- 模块清单 ----
        mod_group = QGroupBox("模块清单（来自 modules/平台.json，可编辑；[人工]=暂停等你操作，[语音]=电脑外放）")
        mv = QVBoxLayout(mod_group)
        btn_h = QHBoxLayout()
        select_all = QPushButton("全选")
        select_all.setFixedWidth(56)
        select_all.clicked.connect(lambda: self.set_all_checked(True))
        deselect = QPushButton("全不选")
        deselect.setFixedWidth(64)
        deselect.clicked.connect(lambda: self.set_all_checked(False))
        edit_btn = QPushButton("编辑模块配置")
        edit_btn.setToolTip("用系统默认程序打开当前平台的模块 JSON，改完点「刷新」重新加载")
        edit_btn.clicked.connect(self.edit_module_config)
        refresh_btn = QPushButton("刷新")
        refresh_btn.setFixedWidth(52)
        refresh_btn.clicked.connect(
            lambda: self.on_platform_changed(self.platform_combo.currentText()))
        btn_h.addWidget(select_all)
        btn_h.addWidget(deselect)
        btn_h.addWidget(edit_btn)
        btn_h.addWidget(refresh_btn)
        btn_h.addStretch()
        mv.addLayout(btn_h)

        self.module_list = QListView_compat()
        self.module_list.setToolTip("右键可试跑单个模块（10 秒，不采集日志）")
        mv.addWidget(self.module_list, 1)
        layout.addWidget(mod_group, 1)

        # ---- 采集选项 ----
        opt_group = QGroupBox("采集选项")
        ov = QGridLayout(opt_group)
        self.record_cb = QCheckBox("ICS 录屏 (scrcpy)")
        self.record_cb.setChecked(True)
        self.record_cb.stateChanged.connect(self.on_record_toggled)
        self.clear_cb = QCheckBox("开始前清空车机日志(删远端 logd/slog)")
        self.clear_cb.setChecked(True)   # 日志测试默认隔离；不需要时请取消勾选
        self.logd_cb = QCheckBox("结束后拉取安卓 logd")
        self.logd_cb.setToolTip(
            "拉取车机 /data/misc/nio/logd 整目录到会话目录 logd/（只拉不删）")
        self.logd_cb.setChecked(True)
        self.slog_cb = QCheckBox("结束后拉取 QNX slog")
        self.slog_cb.setToolTip(
            "拉取 QNX /blackbox/cdclogs/qnx/slog 整目录到会话目录 slog/"
            "（等同 scp -r，只拉不删）")
        self.slog_cb.setChecked(True)
        self.voice_cb = QCheckBox("语音模块 TTS 外放")
        self.voice_cb.setChecked(True)
        ov.addWidget(self.record_cb, 0, 0)
        ov.addWidget(self.clear_cb, 0, 1)
        ov.addWidget(self.logd_cb, 0, 2)
        ov.addWidget(self.slog_cb, 1, 0)
        ov.addWidget(self.voice_cb, 1, 1)

        scrcpy_h = QHBoxLayout()
        self.scrcpy_label = QLabel("scrcpy: 检测中...")
        self.scrcpy_label.setStyleSheet("font-size: 11px;")
        scrcpy_h.addWidget(self.scrcpy_label, 1)
        self.scrcpy_btn = QPushButton("选择 scrcpy.exe")
        self.scrcpy_btn.clicked.connect(self.select_scrcpy)
        scrcpy_h.addWidget(self.scrcpy_btn)
        ov.addLayout(scrcpy_h, 2, 0, 1, 3)
        layout.addWidget(opt_group)

        # ---- 语音音频 ----
        audio_group = QGroupBox("语音音频（语音模块 = 唤醒词 + Query 循环外放）")
        av = QHBoxLayout(audio_group)
        self.gen_voice_btn = QPushButton("生成测试语音 (Edge TTS)")
        self.gen_voice_btn.setStyleSheet(
            "background-color: #22c55e; color: white; padding: 5px 14px;"
            " border-radius: 4px; font-weight: bold;")
        self.gen_voice_btn.clicked.connect(self.generate_voice)
        av.addWidget(self.gen_voice_btn)
        self.voice_status_label = QLabel("未生成")
        self.voice_status_label.setStyleSheet("font-size: 11px; color: #9aa3b2;")
        av.addWidget(self.voice_status_label, 1)
        layout.addWidget(audio_group)

        # ---- 控制按钮 ----
        run_h = QHBoxLayout()
        self.start_btn = QPushButton("开始测试")
        self.start_btn.setStyleSheet(
            "background-color: #22c55e; color: white; padding: 7px 22px;"
            " border-radius: 4px; font-weight: bold; font-size: 13px;")
        self.start_btn.clicked.connect(self.start_test)
        run_h.addWidget(self.start_btn)
        self.trial_btn = QPushButton("试跑选中模块 (10s)")
        self.trial_btn.setToolTip("按选中模块快速走一遍流程（每模块 10 秒，\n"
                                  "不清日志/不录屏/不拉日志），验证控屏步骤是否正确")
        self.trial_btn.clicked.connect(self.start_trial)
        run_h.addWidget(self.trial_btn)
        self.stop_btn = QPushButton("停止")
        self.stop_btn.setStyleSheet(
            "background-color: #ef4444; color: white; padding: 7px 22px;"
            " border-radius: 4px; font-weight: bold; font-size: 13px;")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_test)
        run_h.addWidget(self.stop_btn)
        self.continue_btn = QPushButton("继续下一模块")
        self.continue_btn.setStyleSheet(
            "background-color: #3b82f6; color: white; padding: 7px 22px;"
            " border-radius: 4px; font-weight: bold; font-size: 13px;")
        self.continue_btn.setEnabled(False)
        self.continue_btn.setToolTip("人工模块操作完成后点击，继续后续流程")
        self.continue_btn.clicked.connect(self.resume_test)
        run_h.addWidget(self.continue_btn)
        self.open_folder_btn = QPushButton("打开产物文件夹")
        self.open_folder_btn.setEnabled(False)
        self.open_folder_btn.clicked.connect(self.open_session_folder)
        run_h.addWidget(self.open_folder_btn)
        run_h.addStretch()
        layout.addLayout(run_h)

        scroll.setWidget(content)
        splitter.addWidget(scroll)

        # ---------- 下半: 进度 + 倒计时 + 日志 ----------
        bottom = QWidget()
        bv = QVBoxLayout(bottom)
        bv.setContentsMargins(8, 4, 8, 8)
        bv.setSpacing(4)
        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.progress.setFormat("%v / %m 模块")
        self.progress.setMaximumHeight(16)
        bv.addWidget(self.progress)
        status_h = QHBoxLayout()
        self.module_label = QLabel("当前模块: -")
        self.module_label.setStyleSheet("font-weight: bold; color: #3b82f6;")
        status_h.addWidget(self.module_label)
        status_h.addStretch()
        self.countdown_label = QLabel("")
        self.countdown_label.setStyleSheet("font-weight: bold; color: #22c55e;")
        status_h.addWidget(self.countdown_label)
        bv.addLayout(status_h)
        self.log_pane = LogPane(
            title="日志测试日志", tip="右键调节字体，Ctrl+滚轮快速缩放")
        bv.addWidget(self.log_pane, 1)
        splitter.addWidget(bottom)

        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([430, 300])
        outer.addWidget(splitter)

    # ==================== 平台 / 模块加载 ====================
    def on_platform_changed(self, platform: str):
        self.platform_tip_label.setText(
            LOG_TEST_PLATFORM_TIPS.get(platform, ""))
        self.platform_cfg = load_module_config(_TOOL_DIR, platform)
        if self.platform_cfg is None:
            self.wakeup_label.setText("(配置缺失)")
            self.module_list.clear()
            self.append_log(f"[错误] 模块配置加载失败: modules/{platform}.json "
                            "不存在或格式错误")
            return
        wakeup = self.platform_cfg.get("wakeup_word", "")
        if not wakeup:
            wakeup = CAR_WAKEUP_WORDS.get("NIO", "")
        self.wakeup_label.setText(wakeup)
        self._reload_modules()

    def _reload_modules(self):
        """把平台 JSON 的模块列表刷到界面"""
        self.module_list.clear()
        if not self.platform_cfg:
            return
        for mod in self.platform_cfg.get("modules", []):
            name = str(mod.get("name", "?"))
            secs = int(mod.get("seconds", LOG_MODULE_SECONDS) or LOG_MODULE_SECONDS)
            tags = []
            if mod.get("manual"):
                tags.append("人工")
            if mod.get("voice"):
                tags.append("语音")
            tag_txt = f"  [{'|'.join(tags)}]" if tags else ""
            text = f"{name} ({secs}s){tag_txt}"
            self.module_list.add_check_item(text, mod)
        self.set_all_checked(True)

    def edit_module_config(self):
        """用系统默认程序打开当前平台模块 JSON"""
        platform = self.platform_combo.currentText()
        path = os.path.join(_TOOL_DIR, "modules", f"{platform}.json")
        if not os.path.exists(path):
            QMessageBox.warning(self, "文件不存在", f"未找到:\n{path}")
            return
        try:
            os.startfile(path)   # noqa: Windows 默认关联程序打开
        except Exception as e:
            QMessageBox.warning(self, "打开失败", f"无法打开文件:\n{e}\n\n路径: {path}")

    def set_all_checked(self, checked: bool):
        for i in range(self.module_list.count()):
            item = self.module_list.item(i)
            item.setCheckState(Qt.Checked if checked else Qt.Unchecked)

    def get_selected_modules(self) -> list:
        result = []
        for i in range(self.module_list.count()):
            item = self.module_list.item(i)
            if item.checkState() == Qt.Checked:
                mod = item.data(Qt.UserRole)
                if mod:
                    result.append(mod)
        return result

    # ==================== scrcpy ====================
    def refresh_status(self):
        """切到本页时刷新: scrcpy 探测 + 语音状态"""
        self._scrcpy = detect_scrcpy()
        self._update_scrcpy_label()
        self._update_voice_status()

    def _update_scrcpy_label(self):
        if self._scrcpy:
            self.scrcpy_label.setText(f"scrcpy: {self._scrcpy}")
            self.scrcpy_label.setStyleSheet("font-size: 11px; color: #22c55e;")
        else:
            self.scrcpy_label.setText(
                "scrcpy: 未找到（点右侧按钮选择 scrcpy.exe，或安装后点「刷新」）")
            self.scrcpy_label.setStyleSheet("font-size: 11px; color: #ef4444;")

    def on_record_toggled(self):
        enabled = self.record_cb.isChecked()
        self.scrcpy_btn.setEnabled(enabled)

    def select_scrcpy(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择 scrcpy.exe", "", "scrcpy (scrcpy.exe);;所有文件 (*.*)")
        if path:
            self._scrcpy = path
            self._update_scrcpy_label()

    # ==================== 语音音频 ====================
    def _collect_queries(self) -> list:
        """当前平台所有语音模块的 Query（模块未定义则用默认样例）"""
        queries = []
        if not self.platform_cfg:
            return queries
        for mod in self.platform_cfg.get("modules", []):
            if not mod.get("voice"):
                continue
            qs = mod.get("queries")
            if isinstance(qs, list) and qs:
                queries.extend(str(q) for q in qs)
            else:
                queries.extend(NOMI_LOG_TEST_QUERIES)
        seen, uniq = set(), []
        for q in queries:
            if q not in seen:
                seen.add(q)
                uniq.append(q)
        return uniq

    def _update_voice_status(self):
        audio_dir = os.path.join(self.get_output_root(), DIR_AUDIO)
        wakeup = self.wakeup_label.text()
        queries = self._collect_queries()
        total = (1 if wakeup else 0) + len(queries)
        if total == 0:
            self.voice_status_label.setText("当前平台无语音模块")
            return
        missing = 0
        if wakeup and find_audio_file(audio_dir, wakeup) is None:
            missing += 1
        for q in queries:
            if find_audio_file(audio_dir, f"{LOG_TEST_AUDIO_PREFIX}{q}") is None:
                missing += 1
        if missing == 0:
            self.voice_status_label.setText(f"语音音频就绪 ({total}/{total})")
            self.voice_status_label.setStyleSheet("font-size: 11px; color: #22c55e;")
        else:
            self.voice_status_label.setText(
                f"缺失 {missing}/{total} 个音频，请点击「生成测试语音」")
            self.voice_status_label.setStyleSheet("font-size: 11px; color: #ef4444;")

    def generate_voice(self):
        """生成当前平台全部语音音频（唤醒词 + Query，跳过已存在）"""
        if self.voice_worker and self.voice_worker.isRunning():
            QMessageBox.warning(self, "任务进行中", "请等待当前语音生成完成")
            return
        if not tts_available():
            QMessageBox.warning(
                self, "缺少 edge-tts",
                "未检测到 edge-tts 命令，请先安装:\n  pip install edge-tts")
            return
        wakeup = self.wakeup_label.text()
        queries = self._collect_queries()
        if not wakeup and not queries:
            QMessageBox.information(self, "无内容", "当前平台没有语音模块，无需生成")
            return
        audio_dir = os.path.join(self.get_output_root(), DIR_AUDIO)
        self.gen_voice_btn.setEnabled(False)
        self.append_log(f"生成测试语音: 唤醒词 [{wakeup}] + {len(queries)} 条 Query")
        self.voice_worker = VoiceGenWorker(audio_dir, wakeup, queries)
        self.voice_worker.log_signal.connect(self.append_log)
        self.voice_worker.finished_signal.connect(self.on_voice_finished)
        self.voice_worker.start()

    def on_voice_finished(self, ok_count, total, failed):
        self.gen_voice_btn.setEnabled(True)
        self._update_voice_status()
        self.append_log(f"语音生成结束: 成功 {ok_count}/{total}"
                        + (f"，失败 {len(failed)} 个" if failed else ""))
        if failed:
            self.append_log("[失败明细] " + "; ".join(failed[:10]))
            QMessageBox.warning(
                self, "语音不完整",
                f"成功 {ok_count}/{total}，失败:\n"
                + "\n".join(failed[:10])
                + "\n\n可再次点击「生成测试语音」重试失败条目。")
        else:
            QMessageBox.information(
                self, "完成", f"全部 {total} 个语音音频就绪!\n目录: "
                f"{os.path.join(self.get_output_root(), DIR_AUDIO)}")

    # ==================== 开始前校验 ====================
    def validate(self, trial: bool) -> str:
        """开始前校验，返回错误消息（空串 = 通过）"""
        main = self._main()
        if main:
            cp = main.connect_page
            if not cp.adb_ok:
                return ("ADB 未连接（控屏/录屏/logd 都依赖 ADB），\n"
                        "请先到「连接设备」页连接设备")
        modules = self.get_selected_modules()
        if not modules:
            return "请至少勾选一个测试模块"
        if not trial:
            if self.record_cb.isChecked() and not self._scrcpy:
                return ("已勾选 ICS 录屏，但未找到 scrcpy，\n"
                        "请安装 scrcpy 或点击「选择 scrcpy.exe」指定路径")
            # 语音音频检查（缺失时提示先生成，不自动拦截试跑）
            if self.voice_cb.isChecked():
                voice_mods = [m for m in modules if m.get("voice")]
                if voice_mods:
                    audio_dir = os.path.join(self.get_output_root(), DIR_AUDIO)
                    wakeup = self.wakeup_label.text()
                    missing = []
                    if wakeup and find_audio_file(audio_dir, wakeup) is None:
                        missing.append(f"{wakeup}.wav/.mp3 (唤醒词)")
                    for mod in voice_mods:
                        from core.log_test_engine import LogTestEngine
                        for q in LogTestEngine._module_queries(mod):
                            if find_audio_file(
                                    audio_dir,
                                    f"{LOG_TEST_AUDIO_PREFIX}{q}") is None:
                                missing.append(f"{LOG_TEST_AUDIO_PREFIX}{q}.wav/.mp3")
                    if missing:
                        return ("语音音频缺失 "
                                f"{len(missing)} 个（前 5: {'; '.join(missing[:5])}），\n"
                                "请点击「生成测试语音 (Edge TTS)」补齐，\n"
                                "或取消勾选「语音模块 TTS 外放」")
            session_name = self.session_edit.text().strip()
            if session_name and any(c in session_name for c in _BAD_CHARS):
                return f"总文件夹名含文件名非法字符 ({_BAD_CHARS})"
            version = self.version_edit.text().strip()
            if version and any(c in version for c in _BAD_CHARS):
                return f"版本号含文件名非法字符 ({_BAD_CHARS})"
        return ""

    # ==================== 开始/试跑/停止/继续 ====================
    def _build_config(self, trial: bool) -> LogTestConfig:
        platform = self.platform_combo.currentText()
        modules = self.get_selected_modules()
        seconds = self.seconds_spin.value()
        # 复制模块并统一时长（试跑时长由引擎内部固定 10s）
        mods = []
        for m in modules:
            m2 = dict(m)
            if not trial:
                m2["seconds"] = seconds
            mods.append(m2)

        version = self.version_edit.text().strip()
        session_name = self.session_edit.text().strip()
        if not session_name:
            ts = datetime.now().strftime("%Y%m%d_%H%M")
            base = "日志测试" + (f"_{version}" if version else "") + f"_{platform}_{ts}"
            session_name = base
            self.session_edit.setText(session_name)
        session_dir = os.path.join(self.get_output_root(), session_name)
        os.makedirs(session_dir, exist_ok=True)
        self.session_dir = session_dir

        ssh_cfg = self.get_ssh_config()
        config = LogTestConfig(
            platform=platform,
            wakeup_word=self.wakeup_label.text(),
            modules=mods,
            output_root=self.get_output_root(),
            session_dir=session_dir,
            record_video=self.record_cb.isChecked() and not trial,
            scrcpy_path=self._scrcpy,
            clear_logs_before=self.clear_cb.isChecked() and not trial,
            pull_logd_after=self.logd_cb.isChecked() and not trial,
            pull_slog_after=self.slog_cb.isChecked() and not trial,
            voice_enabled=self.voice_cb.isChecked(),
            trial_run=trial,
            ssh_host=ssh_cfg["ssh_host"],
            ssh_user=ssh_cfg["ssh_user"],
            ssh_password=ssh_cfg["ssh_password"],
        )
        return config

    def _start_engine(self, trial: bool):
        config = self._build_config(trial)
        self._launch(config, trial)

    def _launch(self, config: LogTestConfig, trial: bool):
        """启动引擎并锁定 UI（正式 / 试跑共用）"""
        self.engine = LogTestEngine(config)
        if self.platform_cfg:
            self.engine.set_apps(self.platform_cfg.get("apps", {}))
        self.engine.log_signal.connect(self.append_log)
        self.engine.progress_signal.connect(self.update_progress)
        self.engine.countdown_signal.connect(self.update_countdown)
        self.engine.module_signal.connect(self.update_module)
        self.engine.pause_signal.connect(self.on_manual_pause)
        self.engine.finished_signal.connect(
            lambda ok, msg: self.on_finished(ok, msg, trial))
        # 锁定 UI
        self.start_btn.setEnabled(False)
        self.trial_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.continue_btn.setEnabled(False)
        self.open_folder_btn.setEnabled(False)
        self.progress.setMaximum(len(config.modules))
        self.progress.setValue(0)
        self.log_pane.clear()
        mode = "试跑（每模块 10 秒，不采集日志）" if trial else "正式测试"
        self.append_log(f"开始{mode} | {len(config.modules)} 个模块 | "
                        f"产物目录: {config.session_dir}")
        self.engine.start()

    def start_test(self):
        if self.engine and self.engine.isRunning():
            return
        error = self.validate(trial=False)
        if error:
            QMessageBox.warning(self, "无法开始测试", error)
            return
        self._start_engine(trial=False)

    def trial_single_module(self, mod: dict):
        """右键试跑单个模块（10 秒，不采集日志）"""
        if self.engine and self.engine.isRunning():
            QMessageBox.warning(self, "任务进行中", "请等待当前测试完成")
            return
        if not mod:
            return
        main = self._main()
        if main and not main.connect_page.adb_ok:
            QMessageBox.warning(self, "ADB 未连接",
                                "ADB 未连接，请先到「连接设备」页连接设备")
            return
        platform = self.platform_combo.currentText()
        session_dir = os.path.join(
            self.get_output_root(),
            f"试跑_{platform}_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        os.makedirs(session_dir, exist_ok=True)
        self.session_dir = session_dir
        ssh_cfg = self.get_ssh_config()
        config = LogTestConfig(
            platform=platform,
            wakeup_word=self.wakeup_label.text(),
            modules=[dict(mod)],
            output_root=self.get_output_root(),
            session_dir=session_dir,
            record_video=False,
            scrcpy_path="",
            clear_logs_before=False,
            pull_logd_after=False,
            pull_slog_after=False,
            voice_enabled=self.voice_cb.isChecked(),
            trial_run=True,
            ssh_host=ssh_cfg["ssh_host"],
            ssh_user=ssh_cfg["ssh_user"],
            ssh_password=ssh_cfg["ssh_password"],
        )
        self._launch(config, True)

    def start_trial(self):
        """试跑选中模块（10s/模块，不清/不录/不拉）"""
        if self.engine and self.engine.isRunning():
            return
        modules = self.get_selected_modules()
        if not modules:
            QMessageBox.warning(self, "未选择模块", "请先勾选要试跑的模块")
            return
        ret = QMessageBox.question(
            self, "确认试跑",
            f"将试跑 {len(modules)} 个选中模块（每模块 10 秒）:\n"
            "  - 不清空车机日志 / 不录屏 / 不拉取日志\n"
            "  - 控屏步骤照常执行，验证配置是否正确\n\n确认开始?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if ret != QMessageBox.Yes:
            return
        self._start_engine(trial=True)

    def stop_test(self):
        if self.engine and self.engine.isRunning():
            self.engine.stop()
            self.append_log("已请求停止，等待当前模块收尾...")
            self.continue_btn.setEnabled(False)

    def resume_test(self):
        """人工模块完成，继续"""
        if self.engine and self.engine.isRunning():
            self.engine.resume()
            self.continue_btn.setEnabled(False)

    def on_manual_pause(self, module_name: str):
        """引擎在人工模块处暂停"""
        self.append_log(f"[等待人工] 模块 [{module_name}] 请在车机上手动操作，"
                        "完成后点击「继续下一模块」")
        self.continue_btn.setEnabled(True)
        self.countdown_label.setText("等待人工操作...")

    def on_finished(self, success, message, trial):
        self.start_btn.setEnabled(True)
        self.trial_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.continue_btn.setEnabled(False)
        self.open_folder_btn.setEnabled(not trial)
        self.countdown_label.setText("")
        self.append_log(("试跑结束: " if trial else "测试结束: ") + message)
        if trial:
            QMessageBox.information(self, "试跑结束", message)
        elif success:
            QMessageBox.information(self, "完成", message)
        else:
            QMessageBox.warning(self, "结束", message)

    def open_session_folder(self):
        if self.session_dir and os.path.exists(self.session_dir):
            try:
                os.startfile(self.session_dir)
            except Exception:
                pass

    # ==================== 日志/进度 ====================
    def append_log(self, text):
        self.log_pane.append(text)

    def update_progress(self, current, total):
        self.progress.setMaximum(total)
        self.progress.setValue(current)

    def update_countdown(self, remaining: int):
        if remaining > 0:
            self.countdown_label.setText(f"剩余 {remaining} 秒")
        else:
            self.countdown_label.setText("")

    def update_module(self, name: str):
        self.module_label.setText(f"当前模块: {name}" if name else "当前模块: -")

    def closeEvent(self, event):
        for th in (self.engine, self.voice_worker):
            if th and th.isRunning():
                th.stop()
                th.wait(5000)
                if th.isRunning():
                    _KEEP_ALIVE.append(th)
        event.accept()


# ==================== 可勾选列表（带右键菜单） ====================
from PyQt5.QtWidgets import QListWidget, QListWidgetItem   # noqa: E402


class QListView_compat(QListWidget):
    """带复选框的模块列表 + 右键菜单（试跑单模块）"""

    def __init__(self):
        super().__init__()
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._menu)

    def add_check_item(self, text: str, data):
        item = QListWidgetItem(text)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
        item.setCheckState(Qt.Checked)
        item.setData(Qt.UserRole, data)
        self.addItem(item)

    def _menu(self, pos):
        item = self.itemAt(pos)
        menu = QMenu(self)
        if item is not None:
            act_trial = menu.addAction(f"试跑「{item.text().split(' (')[0]}」(10s)")
        act_all = menu.addAction("全选")
        act_none = menu.addAction("全不选")
        act = menu.exec_(self.mapToGlobal(pos))
        if act is None:
            return
        if item is not None and act == act_trial:
            page = self._page()
            if page:
                page.trial_single_module(item.data(Qt.UserRole))
        elif act == act_all:
            page = self._page()
            if page:
                page.set_all_checked(True)
        elif act == act_none:
            page = self._page()
            if page:
                page.set_all_checked(False)

    def _page(self):
        p = self.parentWidget()
        while p is not None and not isinstance(p, LogTestPage):
            p = p.parentWidget()
        return p
