# ui/cal_train_page.py
# v1.6.8 校准训练页：把「录像 + 人工确认完成表」样本批量重跑自动分析，
# 与人工 A唤醒/B端到端 逐行比对，输出命中率与偏差，支撑参数校准。
import os
import json

from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QGroupBox,
                             QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                             QMessageBox, QPushButton, QSpinBox,
                             QTableWidget, QTableWidgetItem, QTextEdit,
                             QVBoxLayout, QWidget)

from core import app_log
from core.asr_align import (MODEL_CHOICES, MODEL_LABELS)

_CFG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")


def _load_cfg():
    try:
        with open(_CFG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _default_dataset_dir():
    from core.calibration import default_dataset_dir
    return default_dataset_dir(_load_cfg().get("work_dir") or "")


class CalTrainWorker(QThread):
    """后台: 逐样本跑自动分析 + 与人工值比对（分析在子进程，GUI 进程不加载 ASR）"""

    progress = pyqtSignal(str)
    row = pyqtSignal(dict)          # 每个样本一个汇总行
    finished_ok = pyqtSignal(list, dict)   # (样本评估列表, 汇总)
    failed = pyqtSignal(str)

    def __init__(self, dataset_dir, model, language, gap_ms,
                 tol_a, tol_b, parent=None):
        super().__init__(parent)
        self.dataset_dir = dataset_dir
        self.model = model
        self.language = language
        self.gap_ms = gap_ms
        self.tol_a = tol_a
        self.tol_b = tol_b

    def run(self):
        from core.calibration import (scan_samples, evaluate_sample,
                                      summarize)
        try:
            samples = scan_samples(self.dataset_dir)
        except Exception as e:               # noqa: BLE001
            self.failed.emit(f"扫描样本失败: {e}")
            return
        if not samples:
            self.failed.emit(
                f"未发现有效样本：{self.dataset_dir}\n"
                "每个子目录需同时含 1 段录像/录音 + 1 份已完成 Excel。")
            return
        self.progress.emit(f"扫描到 {len(samples)} 个样本，开始评估…")
        evals = []
        for i, s in enumerate(samples, 1):
            self.progress.emit(f"--- 样本 {i}/{len(samples)}: {s['name']}")
            try:
                e = evaluate_sample(s, model=self.model, language=self.language,
                                    gap_ms=self.gap_ms, tol_a_ms=self.tol_a,
                                    tol_b_ms=self.tol_b,
                                    emit=self.progress.emit)
                evals.append(e)
                self.row.emit(e)
            except Exception as ex:          # noqa: BLE001
                self.progress.emit(f"[样本失败] {s['name']}: {ex}")
        self.finished_ok.emit(evals, summarize(evals, self.tol_a, self.tol_b))


class CalTrainPage(QWidget):
    """校准训练 Tab"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker = None
        self.dataset_dir = _default_dataset_dir()
        self.samples = []
        self._scanned = False   # v1.6.8: 默认不扫描，用户启用后才扫描
        self._build()
        self._bind()
        self._apply_enable_state()   # 默认关闭：不扫描样本、不加载任何模型/进程

    # ==================== UI ====================
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # v1.6.8: 顶部启用开关（默认关闭）——程序启动时不扫描样本/不加载模型，
        # 与「端到端耗时」开关一致；用户本次会话需要训练时才勾选开启。
        self.enable_cb = QCheckBox("启用 校准训练功能")
        self.enable_cb.setChecked(False)
        self.enable_cb.setToolTip(
            "程序启动时校准训练默认关闭：不扫描训练数据集目录、不加载 ASR、\n"
            "不启动任何校准进程，界面最流畅。需要做校准评估时再勾选开启。")
        root.addWidget(self.enable_cb)

        # 数据集目录
        box1 = QGroupBox("训练数据集目录")
        v1 = QHBoxLayout(box1)
        self.dir_edit = QLineEdit()
        self.dir_edit.setReadOnly(True)
        self.dir_edit.setText(self.dataset_dir or "（未设置 work_dir）")
        v1.addWidget(self.dir_edit, 1)
        self.choose_btn = QPushButton("选择目录…")
        self.create_btn = QPushButton("创建默认目录")
        self.open_btn = QPushButton("打开目录")
        v1.addWidget(self.choose_btn)
        v1.addWidget(self.create_btn)
        v1.addWidget(self.open_btn)
        root.addWidget(box1)

        hint = QLabel(
            "样本规范：每个子目录 = 一次完整录制，内含「录像/录音 + 已完成 Excel」。\n"
            "Excel 沿用 Nomi4-响应延时模板（人工确认后的 A唤醒/B端到端 保留在表内），"
            "文件名建议以「完成_」开头；录制文件名带遍次(如 第2遍/2.mp4)时自动按该遍比对。")
        hint.setWordWrap(True)
        root.addWidget(hint)

        # 评估参数
        box2 = QGroupBox("评估参数")
        v2 = QHBoxLayout(box2)
        v2.addWidget(QLabel("ASR 模型"))
        self.model_combo = QComboBox()
        for _c in MODEL_CHOICES:
            self.model_combo.addItem(MODEL_LABELS.get(_c, _c), _c)
        ix = self.model_combo.findData("tiny")
        if ix >= 0:
            self.model_combo.setCurrentIndex(ix)
        v2.addWidget(self.model_combo)
        v2.addWidget(QLabel("唤醒容差(ms)"))
        self.tol_a_spin = QSpinBox()
        self.tol_a_spin.setRange(20, 500)
        self.tol_a_spin.setValue(80)
        self.tol_a_spin.setSuffix(" ms")
        v2.addWidget(self.tol_a_spin)
        v2.addWidget(QLabel("端到端容差(ms)"))
        self.tol_b_spin = QSpinBox()
        self.tol_b_spin.setRange(20, 1000)
        self.tol_b_spin.setValue(120)
        self.tol_b_spin.setSuffix(" ms")
        v2.addWidget(self.tol_b_spin)
        self.refresh_btn = QPushButton("重新扫描")
        v2.addWidget(self.refresh_btn)
        self.start_btn = QPushButton("开始校准评估")
        v2.addWidget(self.start_btn)
        root.addWidget(box2)

        # 结果表: 每行一个样本
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["样本", "Query 行", "唤醒: 人工可比对", "唤醒命中",
             "端到端: 人工可比对", "端到端命中"])
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Stretch)
        for c in range(1, 6):
            self.table.horizontalHeader().setSectionResizeMode(
                c, QHeaderView.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        root.addWidget(self.table, 1)

        # 日志
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(180)
        root.addWidget(self.log_text)

    def _bind(self):
        self.enable_cb.toggled.connect(self._apply_enable_state)
        self.choose_btn.clicked.connect(self._choose_dir)
        self.create_btn.clicked.connect(self._create_default)
        self.open_btn.clicked.connect(self._open_dir)
        self.refresh_btn.clicked.connect(self.refresh_samples)
        self.start_btn.clicked.connect(self._start)

    # ==================== 启用 / 停用校准训练 ====================
    def _apply_enable_state(self, *_):
        """v1.6.8: 校准训练默认停用；勾选启用后才扫描样本并开放操作。

        程序启动/切到本页时不会扫描数据集目录，也不会启动任何校准进程
        （校准评估的 ASR 分析子进程只在点「开始校准评估」后才会拉起）。
        """
        on = self.enable_cb.isChecked()
        if (not on and self.worker is not None and self.worker.isRunning()):
            QMessageBox.information(
                self, "评估进行中",
                "校准评估正在运行，请等待完成后再停用校准训练。")
            self.enable_cb.setChecked(True)
            return
        for w in (self.choose_btn, self.create_btn, self.open_btn,
                  self.model_combo, self.tol_a_spin, self.tol_b_spin,
                  self.refresh_btn, self.start_btn):
            if w is not None:
                w.setEnabled(on)
        if on and not getattr(self, "_scanned", False):
            self._scanned = True
            self.refresh_samples()

    # ==================== 操作 ====================
    def _append_log(self, text):
        self.log_text.append(text)
        app_log.ui(text)
        c = self.log_text.textCursor()
        c.movePosition(c.End)
        self.log_text.setTextCursor(c)
        # 控制日志框体积，避免越用越卡
        from ui.log_utils import trim_text_edit_max_blocks
        trim_text_edit_max_blocks(self.log_text)

    def _set_dir(self, d):
        if not d:
            return
        self.dataset_dir = d
        self.dir_edit.setText(d)
        self.refresh_samples()

    def _choose_dir(self):
        d = QFileDialog.getExistingDirectory(self, "选择训练数据集目录",
                                             self.dataset_dir or "")
        if d:
            self._set_dir(d)

    def _create_default(self):
        d = _default_dataset_dir()
        try:
            os.makedirs(d, exist_ok=True)
        except Exception as e:               # noqa: BLE001
            QMessageBox.warning(self, "创建失败", str(e))
            return
        self._append_log(f"已创建默认目录: {d}")
        self._set_dir(d)

    def _open_dir(self):
        if not self.dataset_dir:
            return
        try:
            os.makedirs(self.dataset_dir, exist_ok=True)
            os.startfile(self.dataset_dir)   # noqa: S606 Windows 打开资源管理器
        except Exception as e:               # noqa: BLE001
            QMessageBox.warning(self, "无法打开", str(e))

    def refresh_samples(self):
        from core.calibration import scan_samples
        try:
            self.samples = scan_samples(self.dataset_dir or "")
        except Exception:
            self.samples = []
        self.table.setRowCount(0)
        self._append_log(f"扫描目录: {self.dataset_dir or '（未设置）'} -> "
                         f"样本 {len(self.samples)} 个"
                         if self.samples else
                         f"扫描目录: {self.dataset_dir or '（未设置）'} -> "
                         "0 个样本（先创建目录并放入录像+完成表）")
        for i, s in enumerate(self.samples):
            self._append_log(
                f"  {i + 1}. {s['name']}  [录像] {os.path.basename(s['media'])}  "
                f"[真值表] {os.path.basename(s['excel'])}  第{s['pass_no']}遍")

    def _start(self):
        if not self.dataset_dir:
            QMessageBox.information(self, "未选择目录", "请先选择训练数据集目录")
            return
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "评估中", "校准评估正在运行，请稍候")
            return
        self.start_btn.setEnabled(False)
        self._append_log("===== 开始校准评估 =====")
        self.worker = CalTrainWorker(
            self.dataset_dir,
            model=self.model_combo.currentData() or "tiny",
            language="zh",
            gap_ms=150,
            tol_a=self.tol_a_spin.value(),
            tol_b=self.tol_b_spin.value())
        self.worker.progress.connect(self._append_log)
        self.worker.row.connect(self._on_sample_row)
        self.worker.finished_ok.connect(self._on_finished)
        self.worker.failed.connect(self._on_failed)
        self.worker.start()

    def _on_sample_row(self, e):
        r = self.table.rowCount()
        self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(e["name"]))
        self.table.setItem(r, 1, QTableWidgetItem(str(e["n"])))
        self.table.setItem(r, 2, QTableWidgetItem(str(e["n_a"])))
        self.table.setItem(r, 3, QTableWidgetItem(
            f"{e['a_ok']}/{e['n_a'] or 0}"))
        self.table.setItem(r, 4, QTableWidgetItem(str(e["n_b"])))
        self.table.setItem(r, 5, QTableWidgetItem(
            f"{e['b_ok']}/{e['n_b'] or 0}"))

    def _on_finished(self, evals, summary):
        self.start_btn.setEnabled(True)
        if summary["n_a"] or summary["n_b"]:
            ar = ("-" if summary["a_rate"] is None
                  else f"{summary['a_rate'] * 100:.1f}%")
            br = ("-" if summary["b_rate"] is None
                  else f"{summary['b_rate'] * 100:.1f}%")
            self._append_log(
                f"===== 校准评估汇总（{summary['samples']} 个样本） =====\n"
                f"唤醒 A: {summary['a_ok']}/{summary['n_a']} 命中 "
                f"(±{summary['tol_a_ms']}ms) -> {ar}\n"
                f"端到端 B: {summary['b_ok']}/{summary['n_b']} 命中 "
                f"(±{summary['tol_b_ms']}ms) -> {br}")
        else:
            self._append_log("无可比对的真值行（完成表里没有数值？）")
        self._append_log("===== 校准评估结束 =====")

    def _on_failed(self, msg):
        self.start_btn.setEnabled(True)
        self._append_log(f"[失败] {msg}")
        QMessageBox.warning(self, "校准评估失败", msg)

    def shutdown(self):
        if self.worker is not None and self.worker.isRunning():
            self.worker.wait(3000)
