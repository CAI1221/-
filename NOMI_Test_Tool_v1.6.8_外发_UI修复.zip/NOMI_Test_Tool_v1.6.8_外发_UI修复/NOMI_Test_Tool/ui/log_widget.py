# ui/log_widget.py
# 共享日志面板：QPlainTextEdit + 攒批刷新 + 自动限行 + 字号右键菜单 + 镜像独立窗口
#
# 设计要点（修复历史两类问题）:
# 1) 闪退(RuntimeError: wrapped C/C++ object deleted):
#    - 独立窗口不再挪动页面内控件（reparent），而是"镜像"——独立窗口自带只读
#      QPlainTextEdit，通过信号同步新行，两边互不干扰，关谁都安全；
#    - 所有日志控件访问都带 RuntimeError 保护，C++ 对象已销毁时静默跳过。
# 2) 卡顿（拖分割条/切窗口时日志逐行刷新导致）:
#    - append() 只进内存队列，200ms 定时器攒批一次性刷入；
#    - QPlainTextEdit + maximumBlockCount 自动截断最老的行（比 QTextEdit 快一个量级）。
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (QHBoxLayout, QLabel, QMainWindow, QMenu,
                             QPlainTextEdit, QPushButton, QVBoxLayout, QWidget)

from core import app_log

BATCH_MS = 200      # 攒批刷新间隔（毫秒）
MAX_LINES = 4000    # 最大保留行数（超出自动截断最老的行）
FONT_MIN, FONT_MAX, FONT_DEFAULT = 8, 24, 11

_LOG_QSS = """
QPlainTextEdit {
    background-color: #0a0d12; color: #c9d4e3;
    font-family: Consolas, monospace;
    border-radius: 4px;
}
"""


class MirrorLogWindow(QMainWindow):
    """镜像日志窗口：内容通过信号同步，与页面内日志框完全独立互不影响"""

    closed = pyqtSignal()          # 用户关闭窗口时通知 LogPane
    new_lines = pyqtSignal(list)   # LogPane -> 窗口（信号分发，线程安全）

    def __init__(self, title="日志", font_size=FONT_DEFAULT):
        super().__init__()
        self.setWindowTitle(title)
        self.resize(880, 540)
        self.font_size = font_size
        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setMaximumBlockCount(MAX_LINES)
        self.text.setStyleSheet(_LOG_QSS)
        self._apply_font(font_size)
        self.setCentralWidget(self.text)

    def _apply_font(self, size):
        self.font_size = max(FONT_MIN, min(FONT_MAX, size))
        font = QFont("Consolas")
        font.setStyleHint(QFont.Monospace)
        font.setPointSize(self.font_size)
        try:
            self.text.setFont(font)
        except RuntimeError:
            pass

    def set_initial(self, content: str):
        """打开时灌入页面日志框的现有内容"""
        try:
            self.text.setPlainText(content)
        except RuntimeError:
            pass

    def append_lines(self, lines):
        """追加新行（信号槽触发，主线程执行）"""
        try:
            for ln in lines:
                self.text.appendPlainText(ln)
        except RuntimeError:
            pass

    def wheelEvent(self, event):
        """Ctrl+滚轮 快速调字号"""
        if event.modifiers() & Qt.ControlModifier:
            self._apply_font(self.font_size + (1 if event.angleDelta().y() > 0 else -1))
            event.accept()
            return
        super().wheelEvent(event)


class LogPane(QWidget):
    """页面内嵌日志面板：标题行 + 按钮行 + QPlainTextEdit

    用法:
        pane = LogPane(title="执行日志")
        pane.append("一行日志")     # 只进队列，200ms 内攒批刷入
        pane.clear()
    """
    # 镜像窗口打开/关闭通知（外部可据此调整布局）
    mirrored = pyqtSignal(bool)

    def __init__(self, title="执行日志", tip="右键调节字体", font_size=FONT_DEFAULT,
                 parent=None):
        super().__init__(parent)
        self.font_size = font_size
        self._queue = []            # 待刷入的行
        self.mirror = None          # 镜像窗口引用（None = 未打开）

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(4)

        head = QHBoxLayout()
        self.title_label = QLabel(title if not tip else f"{title}（{tip}）")
        self.title_label.setStyleSheet("font-weight: bold;")
        head.addWidget(self.title_label)
        head.addStretch()

        self.pop_btn = QPushButton("独立窗口")
        self.pop_btn.setFixedWidth(72)
        self.pop_btn.setToolTip("弹出镜像日志窗口（内容实时同步，互不影响）")
        self.pop_btn.clicked.connect(self.toggle_mirror)
        head.addWidget(self.pop_btn)

        self.clear_btn = QPushButton("清空")
        self.clear_btn.setFixedWidth(48)
        self.clear_btn.clicked.connect(self.clear)
        head.addWidget(self.clear_btn)
        root.addLayout(head)

        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setMaximumBlockCount(MAX_LINES)   # 自动截断最老的行
        self.text.setContextMenuPolicy(Qt.CustomContextMenu)
        self.text.customContextMenuRequested.connect(self.show_menu)
        self.text.setStyleSheet(_LOG_QSS)
        self._apply_font(font_size)
        root.addWidget(self.text, 1)

        # 攒批刷新定时器（父对象挂载，随面板销毁自动停止）
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._flush)
        self._timer.start(BATCH_MS)

    # ==================== 对外接口 ====================
    def append(self, text: str):
        """追加一行（或含换号的多行）日志，仅入队"""
        if not text:
            return
        for ln in str(text).splitlines():
            self._queue.append(ln)
            # 镜像到会话运行日志文件（未初始化时为安全空操作）
            app_log.ui(ln)

    def extend(self, lines):
        """追加多行日志"""
        for ln in lines:
            self.append(ln)

    def clear(self):
        """清空日志（队列 + 页面框 + 镜像窗口）"""
        self._queue.clear()
        try:
            self.text.clear()
        except RuntimeError:
            pass
        if self.mirror is not None:
            try:
                self.mirror.text.clear()
            except RuntimeError:
                pass

    def flush(self):
        """立即刷入队列（定时器外可手动调用）"""
        self._flush()

    # ==================== 内部 ====================
    def _flush(self):
        if not self._queue:
            return
        lines, self._queue = self._queue, []
        try:
            for ln in lines:
                self.text.appendPlainText(ln)
        except RuntimeError:
            pass
        if self.mirror is not None:
            self.mirror.new_lines.emit(lines)

    def _apply_font(self, size):
        self.font_size = max(FONT_MIN, min(FONT_MAX, size))
        font = QFont("Consolas")
        font.setStyleHint(QFont.Monospace)
        font.setPointSize(self.font_size)
        try:
            self.text.setFont(font)
        except RuntimeError:
            pass

    def show_menu(self, pos):
        """右键菜单: 放大/缩小/重置字号"""
        try:
            menu = QMenu(self)
            act_up = menu.addAction(f"字体放大 (当前 {self.font_size}pt)")
            act_down = menu.addAction(f"字体缩小 (当前 {self.font_size}pt)")
            act_reset = menu.addAction(f"重置为 {FONT_DEFAULT}pt")
            act = menu.exec_(self.text.mapToGlobal(pos))
            if act == act_up:
                self._apply_font(self.font_size + 1)
            elif act == act_down:
                self._apply_font(self.font_size - 1)
            elif act == act_reset:
                self._apply_font(FONT_DEFAULT)
        except RuntimeError:
            pass

    def wheelEvent(self, event):
        """Ctrl+滚轮 快速调字号"""
        if event.modifiers() & Qt.ControlModifier:
            self._apply_font(self.font_size + (1 if event.angleDelta().y() > 0 else -1))
            event.accept()
            return
        super().wheelEvent(event)

    # ==================== 镜像独立窗口 ====================
    def toggle_mirror(self):
        """打开/聚焦镜像日志窗口"""
        if self.mirror is not None:
            try:
                self.mirror.show()
                self.mirror.raise_()
                self.mirror.activateWindow()
            except RuntimeError:
                self.mirror = None
            return
        self.flush()  # 先把队列刷干净再镜像现有内容
        try:
            content = self.text.toPlainText()
        except RuntimeError:
            content = ""
        win = MirrorLogWindow(title=self.title_label.text(), font_size=self.font_size)
        win.set_initial(content)
        win.closed.connect(self._on_mirror_closed)
        win.new_lines.connect(win.append_lines)  # 信号自环：线程安全分发到窗口
        self.mirror = win
        win.show()
        self.mirrored.emit(True)

    def _on_mirror_closed(self):
        """镜像窗口被用户关闭"""
        if self.mirror is not None:
            try:
                self.mirror.new_lines.disconnect()
            except (TypeError, RuntimeError):
                pass
        self.mirror = None
        self.mirrored.emit(False)
