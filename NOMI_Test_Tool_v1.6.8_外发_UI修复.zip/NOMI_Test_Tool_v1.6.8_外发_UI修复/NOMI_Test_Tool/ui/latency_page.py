# ui/latency_page.py
# v1.6.2 端到端耗时分析页（精简为“结果 + 一键写入”）；v1.6.8 页面/开关更名并默认停用
#
# 自动流程（后台 Worker，避免阻塞 UI）:
#   解码 -> 校准音互相关检测(可选扣除) -> VAD 语音段 -> 逐段 ASR 文本标注
#   -> 唤醒词模板互相关(可选) -> 模板 Query 语义对齐 -> 逐行 A/B + 三色状态
#
# 结果按模板 Query 行展示: A唤醒(ms) / B端到端(ms) / 状态
#   绿=已确认   橙=待确认(下拉选择正确 VAD 段即可修正)   红=未匹配(手动定位补填)
# 顶部按钮: 全部正常时「一键写入 Excel」，存在异常时提示修正 N 处。
import json
import os

import numpy as np

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox,
                             QDialog, QFileDialog, QGroupBox, QHBoxLayout,
                             QHeaderView, QLabel, QLineEdit, QMessageBox,
                             QPushButton, QSplitter, QTableWidget,
                             QTableWidgetItem, QVBoxLayout, QWidget)

try:
    import pyqtgraph as pg
except Exception:                      # noqa: 无 pyqtgraph 时降级（页面仍可用）
    pg = None

# v1.6.8: 波形渲染性能调优（对应“本地 UI 不够流畅”优化项）
# - 默认关闭抗锯齿：滚动/拖动波形时大幅降低 CPU 绘制量（线条细时观感差异很小）
# - OpenGL 后端默认不开：部分机器(远程桌面/虚拟机)强制 OpenGL 会白屏，
#   需要时可在启动前设置环境变量 NOMI_OPENGL=1 开启（见 main.py）
if pg is not None:
    try:
        pg.setConfigOptions(antialias=False)
    except Exception:
        pass

from core import app_log
from core.asr_align import (DEFAULT_MODEL, LANGUAGE_LABELS, MODEL_CHOICES,
                            MODEL_LABELS, backend_desc, engine_available)
from core.latency_audio import ffmpeg_exe
from core.latency_excel import (LatencyExcel, detect_pass_from_filename,
                                round_table_rows)
# 分析主流程/参数/结果类型由 core.latency_analyze 提供（无 Qt 依赖，
# 浏览器控制台与桌面共用；本页 QThread 只做信号包装）
from core.latency_analyze import AnalyzeArgs, AnalyzeResult  # noqa: F401

STATUS_TEXT = {"ok": "已确认", "warn": "待确认", "miss": "未匹配"}
STATUS_COLOR = {"ok": "#22c55e", "warn": "#f59e0b", "miss": "#ef4444"}
STATUS_BG = {"ok": "#0e3a24", "warn": "#3a3010", "miss": "#3a1620"}
ASR_SR = 16000


# ==================== 每类文件“上次目录”记忆 ====================
# v1.6.6: 录像/模板/唤醒模板分别记住各自文件夹，避免每次从固定位置重新翻
_CFG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")


def _load_ui_last_dirs() -> dict:
    try:
        with open(_CFG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return dict(data.get("ui_last_dirs") or {})
    except Exception:
        return {}


def _save_ui_last_dir(kind: str, path: str):
    try:
        with open(_CFG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}
    dirs = dict(data.get("ui_last_dirs") or {})
    if not path:
        return
    dirs[kind] = os.path.dirname(path) or path
    data["ui_last_dirs"] = dirs
    try:
        with open(_CFG_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _default_file_dir(kind: str, fallback: str = "") -> str:
    d = _load_ui_last_dirs().get(kind, "")
    if d and os.path.isdir(d):
        return d
    if fallback and os.path.isdir(fallback):
        return fallback
    return ""




class AnalyzeWorker(QThread):
    """后台: 由 core.latency_analyze 执行解码/校准/VAD/整轨 ASR/语义对齐"""
    progress = pyqtSignal(str)
    failed = pyqtSignal(str)
    finished_ok = pyqtSignal()

    def __init__(self, args: AnalyzeArgs, parent=None):
        super().__init__(parent)
        self.args = args
        self.result: AnalyzeResult = AnalyzeResult()

    def _emit(self, msg):
        self.progress.emit(msg)

    def run(self):
        """在独立子进程执行分析（latency_worker.py）。

        v1.6.6: 不在本 GUI 进程加载 faster-whisper —— 本机 PyQt 与
        ctranslate2 同进程会 native crash（表现为 UI 卡死/闪退）。
        子进程逐行回传进度，结果写临时 JSON/NPZ 后回收。
        """
        import json as _json
        import subprocess
        import sys as _sys
        import tempfile
        import threading
        args = self.args
        self.result = AnalyzeResult()
        _emit = self._emit
        a_path = r_path = n_path = ""
        try:
            fd, a_path = tempfile.mkstemp(suffix=".json", prefix="nomian_")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                _json.dump({
                    "media_path": args.media_path,
                    "template_path": args.template_path,
                    "model_name": args.model_name,
                    "language": args.language,
                    "wake_path": args.wake_path,
                    "wake_text": args.wake_text,
                    "gap_ms": int(args.gap_ms or 150),
                }, f, ensure_ascii=False)
            fd2, r_path = tempfile.mkstemp(suffix=".json", prefix="nomian_res")
            os.close(fd2)
            fd3, n_path = tempfile.mkstemp(suffix=".npz", prefix="nomian_env")
            os.close(fd3)
            wk = os.path.join(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__))), "latency_worker.py")
            _emit("启动分析子进程（不在界面进程加载 ASR，避免卡死/闪退）...")
            proc = subprocess.Popen(
                [_sys.executable, "-u", wk, a_path, r_path, n_path],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace")

            def pump():
                assert proc.stdout is not None
                for line in proc.stdout:
                    line = line.rstrip("\n")
                    if line:
                        _emit(line)
                proc.wait()
            t = threading.Thread(target=pump, daemon=True,
                                 name="latency-reader")
            t.start()
            t.join()
            if proc.returncode != 0:
                raise RuntimeError(
                    f"分析子进程退出码 {proc.returncode}（详见上方日志）")
            with open(r_path, "r", encoding="utf-8") as f:
                data = _json.load(f)
            self.result.rows = data.get("rows") or []
            self.result.results = data.get("results") or []
            self.result.units = data.get("units") or []
            self.result.cal_s = float(data.get("cal_s") or 0.0)
            self.result.cal_score = float(data.get("cal_score") or 0.0)
            self.result.sr = int(data.get("sr") or 0)
            try:
                import numpy as np
                z = np.load(n_path)
                self.result.env_t = z["t"]
                self.result.env_v = z["v"]
            except Exception:            # noqa: BLE001 无包络也不影响表格
                pass
        except Exception as e:           # noqa: BLE001
            self.result.ok = False
            self.result.message = str(e)
            self.failed.emit(str(e))
            return
        finally:
            for _p in (a_path, r_path, n_path):
                try:
                    if _p and os.path.exists(_p):
                        os.remove(_p)
                except OSError:
                    pass
        self.result.ok = True
        self.finished_ok.emit()


class BackendProbeThread(QThread):
    """后台线程检测 faster-whisper 后端（避免启动/切页时卡 UI）"""

    probed = pyqtSignal(str)

    def run(self):
        try:
            self.probed.emit(f"({backend_desc()})")
        except Exception as e:           # noqa: BLE001
            self.probed.emit(f"(后端检测失败: {e})")


class ManualFixDialog(QDialog):
    """红色/橙色行的人工修正: 波形缩略图 + 语音段列表 + 可拖端点线"""

    def __init__(self, env_t, env_v, units, parent=None):
        super().__init__(parent)
        self.setWindowTitle("手动定位 - 波形缩略修正")
        self.resize(920, 540)
        self.env_t = env_t
        self.env_v = env_v
        self.units = list(units)
        self.lines = {}          # role -> InfiniteLine
        self.roles = ["wake_end", "answer_start", "cmd_end", "reply_start"]
        self._build()
        self._draw()

    def _build(self):
        root = QVBoxLayout(self)
        hint = QLabel("拖彩色竖线到语音边界，或点击右侧语音段列表快速定位。")
        root.addWidget(hint)
        split = QSplitter(Qt.Horizontal)
        if pg is not None:
            self.plot = pg.PlotWidget()
            # v1.6.6: 深色主题 -> 绘图底/坐标轴改用暗色，避免白底刺眼
            self.plot.setBackground("#0d1016")
            self.plot.showGrid(x=True, y=False, alpha=0.25)
            self.plot.setMenuEnabled(False)
            for _ax in ("bottom", "left"):
                _a = self.plot.getPlotItem().getAxis(_ax)
                _a.setPen(pg.mkPen("#9aa3b2"))
                _a.setTextPen(pg.mkPen("#9aa3b2"))
            self._curve = self.plot.plot(pen=pg.mkPen("#60a5fa", width=1))
            # v1.6.8: 波形只画视口可见范围 + 峰值降采样，拖动/缩放不掉帧
            try:
                self.plot.getPlotItem().setClipToView(True)
            except Exception:                     # noqa: BLE001
                pass
            try:
                self._curve.setDownsampling(method="peak")
            except Exception:                     # noqa: BLE001
                pass
            split.addWidget(self.plot)
        else:
            self.plot = QLabel("缺少 pyqtgraph，无法显示波形")
            split.addWidget(self.plot)
        # 右侧说明 + 段列表
        wrap = QWidget()
        v = QVBoxLayout(wrap)
        tip = QLabel("语音段列表（双击=设为指令尾音并自动找回复）")
        v.addWidget(tip)
        self.list_widget = QTableWidget(0, 3)
        self.list_widget.setHorizontalHeaderLabels(["#", "时间(s)", "ASR 文本"])
        self.list_widget.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch)
        self.list_widget.verticalHeader().setDefaultSectionSize(22)
        self.list_widget.setVerticalScrollMode(
            QAbstractItemView.ScrollPerPixel)
        self.list_widget.setEditTriggers(QTableWidget.NoEditTriggers)
        v.addWidget(self.list_widget, 1)
        b1 = QHBoxLayout()
        self.use_cmd_btn = QPushButton("设为指令尾音")
        self.use_wake_btn = QPushButton("设为唤醒尾音")
        self.use_reply_btn = QPushButton("设为TTS首帧")
        b1.addWidget(self.use_cmd_btn)
        b1.addWidget(self.use_wake_btn)
        b1.addWidget(self.use_reply_btn)
        v.addLayout(b1)
        split.addWidget(wrap)
        split.setStretchFactor(0, 2)
        split.setStretchFactor(1, 1)
        root.addWidget(split, 1)

        self.val_label = QLabel("尾音(TTS首帧)差值: - ms")
        root.addWidget(self.val_label)
        btns = QHBoxLayout()
        self.apply_btn = QPushButton("应用")
        self.cancel_btn = QPushButton("取消")
        btns.addStretch()
        btns.addWidget(self.apply_btn)
        btns.addWidget(self.cancel_btn)
        root.addLayout(btns)
        self.apply_btn.clicked.connect(self.accept)
        self.cancel_btn.clicked.connect(self.reject)
        self.use_cmd_btn.clicked.connect(lambda: self._apply_role("cmd_end"))
        self.use_wake_btn.clicked.connect(lambda: self._apply_role("wake_end"))
        self.use_reply_btn.clicked.connect(lambda: self._apply_role("reply_start"))
        self.list_widget.itemDoubleClicked.connect(
            lambda _it: self._apply_role("cmd_end"))

    def _draw(self):
        for i, u in enumerate(self.units):
            self.list_widget.insertRow(i)
            for c, val in enumerate([str(u["index"]),
                                     f"{u['start_s']:.2f}-{u['end_s']:.2f}",
                                     (u.get("text") or "")[:26]]):
                it = QTableWidgetItem(str(val))
                if c == 2:
                    it.setForeground(QColor("#60a5fa"))
                self.list_widget.setItem(i, c, it)
        if pg is None:
            return
        if self.env_t is not None:
            self._curve.setData(self.env_t, self.env_v)
            self.plot.setXRange(0, float(self.env_t[-1]), padding=0)
        colors = {"wake_end": "#ef4444", "answer_start": "#22c55e",
                  "cmd_end": "#f59e0b", "reply_start": "#3b82f6"}
        for role in self.roles:
            ln = pg.InfiniteLine(pos=0.0, angle=90, movable=True,
                                 pen=pg.mkPen(colors[role], width=1.8))
            ln.sigPositionChanged.connect(lambda: self._update_val())
            self.plot.addItem(ln)
            self.lines[role] = ln

    def _selected_unit(self):
        rows = self.list_widget.selectionModel().selectedRows()
        if rows:
            idx = rows[0].row()
            if 0 <= idx < len(self.units):
                return self.units[idx]
        return None

    def _apply_role(self, role):
        u = self._selected_unit()
        if u is None:
            return
        pos = u["end_s"] if role in ("wake_end", "cmd_end") else u["start_s"]
        if role == "reply_start":
            pos = u["start_s"]
        self.lines[role].setValue(pos)
        self._update_val()

    def _update_val(self):
        if pg is None:
            return
        if ("cmd_end" in self.lines and "reply_start" in self.lines):
            c = float(self.lines["cmd_end"].value())
            r = float(self.lines["reply_start"].value())
            d = (r - c) * 1000.0
            self.val_label.setText(
                f"指令尾音 {c*1000:.0f}ms -> TTS首帧 {r*1000:.0f}ms | "
                f"B(端到端) = {d:+.0f} ms")

    def values(self) -> dict:
        out = {}
        for role, ln in self.lines.items():
            out[role] = float(ln.value())
        return out


class LatencyPage(QWidget):
    """端到端耗时分析主页面（结果 + 一键写入）"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.media_path = ""
        self.template_path = ""
        self._tpl_rows = []
        self.args = AnalyzeArgs()
        self.worker = None
        self.res = None              # AnalyzeResult（最近一次分析）
        self._updating = False
        self._probe = None           # 后端检测线程（懒加载，不卡 UI）
        self._backend_probed = False
        self._shown = False
        self._build_ui()
        self._bind()
        self._load_defaults()
        self._apply_enable_state()

    # ==================== UI ====================
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        # 顶部开关: 默认停用（端到端耗时涉及 ASR 模型加载，不做时整页关闭）
        r0 = QHBoxLayout()
        self.enable_cb = QCheckBox("启用 端到端耗时功能")
        self.enable_cb.setChecked(False)   # v1.6.8: 每次启动默认关闭
        self.enable_cb.setToolTip(
            "程序启动时端到端耗时功能默认关闭（不加载 ASR，界面最流畅）。\n"
            "需要做端到端耗时测试时再勾选开启（仅本次会话，重启后仍默认关闭）。")
        r0.addWidget(self.enable_cb)
        r0.addStretch(1)
        root.addLayout(r0)

        # 第一行: 音/视频 + 遍次 + 模板
        r1 = QHBoxLayout()
        self.open_btn = QPushButton("打开音/视频…")
        self.open_btn.setFixedWidth(110)
        self.file_edit = QLineEdit()
        self.file_edit.setPlaceholderText("选择 .qt/.mp4/.mov/.wav 等录像文件")
        self.file_edit.setReadOnly(True)
        self.pass_combo = QComboBox()
        for t in ["第1遍", "第2遍", "第3遍"]:
            self.pass_combo.addItem(t)
        self.pass_combo.setToolTip("从文件名自动识别遍次，可手动改")
        r1.addWidget(self.open_btn)
        r1.addWidget(self.file_edit, 1)
        r1.addWidget(QLabel("遍次"))
        r1.addWidget(self.pass_combo)
        root.addLayout(r1)

        r2 = QHBoxLayout()
        self.tpl_btn = QPushButton("载入 Excel 模板…")
        self.tpl_btn.setFixedWidth(120)
        self.tpl_edit = QLineEdit()
        self.tpl_edit.setPlaceholderText("选择 Nomi4-响应延时…模板.xlsx")
        self.tpl_edit.setReadOnly(True)
        r2.addWidget(self.tpl_btn)
        r2.addWidget(self.tpl_edit, 1)
        root.addLayout(r2)

        # 第三行: ASR 模型 / 唤醒模板 / 校准音
        r3 = QHBoxLayout()
        r3.addWidget(QLabel("ASR模型"))
        self.model_combo = QComboBox()
        for _c in MODEL_CHOICES:
            self.model_combo.addItem(MODEL_LABELS.get(_c, _c), _c)
        ix = self.model_combo.findData(DEFAULT_MODEL)
        if ix >= 0:
            self.model_combo.setCurrentIndex(ix)
        self.model_combo.setToolTip("模型越大越准越慢；首次使用会自动联网下载并缓存")
        r3.addWidget(self.model_combo)
        self.backend_lbl = QLabel("(后端未检测，启用后在页面上自动检测)")
        self.backend_lbl.setStyleSheet("color:#9aa3b2;")
        r3.addWidget(self.backend_lbl)
        r3.addWidget(QLabel("语种"))
        self.lang_combo = QComboBox()
        for code, label in LANGUAGE_LABELS.items():
            self.lang_combo.addItem(label, code)
        self.lang_combo.setCurrentIndex(0)   # auto: 中英文自动判断
        self.lang_combo.setToolTip("指令语种：自动会由模型按内容判断（中/英均支持）")
        r3.addWidget(self.lang_combo)
        r3.addSpacing(6)
        self.wake_btn = QPushButton("唤醒词模板…")
        self.wake_btn.setFixedWidth(110)
        self.wake_edit = QLineEdit()
        self.wake_edit.setPlaceholderText("电脑实际播放的唤醒词音频(可选)")
        self.wake_edit.setReadOnly(True)
        r3.addWidget(self.wake_btn)
        r3.addWidget(self.wake_edit, 1)
        self.cal_cb = QCheckBox("扣除校准音延迟")
        self.cal_cb.setChecked(True)
        self.cal_cb.setToolTip("录像开头先播放 校准_1kHz.wav(1s)，分析时自动检测并"
                               "扣除空气传播固定偏置")
        r3.addWidget(self.cal_cb)
        root.addLayout(r3)

        # 第四行: 分析按钮 + 概览
        r4 = QHBoxLayout()
        self.analyze_btn = QPushButton("开始分析 (ASR 对齐)")
        self.analyze_btn.setEnabled(False)
        self.analyze_btn.setFixedHeight(30)
        self.summary_lbl = QLabel("就绪")
        self.summary_lbl.setStyleSheet("font-weight:600; color:#e8eaee;")
        r4.addWidget(self.analyze_btn)
        r4.addWidget(self.summary_lbl, 1)
        root.addLayout(r4)

        # 结果表
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["#", "模块", "指令文本(模板)", "A唤醒(ms)", "B端到端(ms)", "状态"])
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setEditTriggers(QTableWidget.DoubleClicked |
                                   QTableWidget.EditKeyPressed)
        self.table.verticalHeader().setDefaultSectionSize(24)
        # v1.6.8: 逐像素滚动替代整行跳动，滚动手感更接近浏览器
        self.table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        root.addWidget(self.table, 1)

        # 修正栏（选中行时显示）
        fix_box = QGroupBox("修正（选择正确语音段后点应用）")
        fix_v = QHBoxLayout(fix_box)
        fix_v.addWidget(QLabel("指令段"))
        self.fix_cmd_combo = QComboBox()
        fix_v.addWidget(self.fix_cmd_combo, 1)
        fix_v.addWidget(QLabel("回复TTS段"))
        self.fix_reply_combo = QComboBox()
        fix_v.addWidget(self.fix_reply_combo, 1)
        self.manual_btn = QPushButton("波形手动定位…")
        fix_v.addWidget(self.manual_btn)
        self.apply_fix_btn = QPushButton("应用修正")
        fix_v.addWidget(self.apply_fix_btn)
        self.clear_sel_btn = QPushButton("清除选择")
        fix_v.addWidget(self.clear_sel_btn)
        root.addWidget(fix_box)

        # 底部: 状态 + 写入
        r_bot = QHBoxLayout()
        self.status_lbl = QLabel("先打开录像与模板，再点「开始分析」")
        self.status_lbl.setStyleSheet("color:#9aa3b2;")
        self.fill_btn = QPushButton("全部匹配，一键写入 Excel")
        self.fill_btn.setEnabled(False)
        r_bot.addWidget(self.status_lbl, 1)
        r_bot.addWidget(self.fill_btn)
        root.addLayout(r_bot)

    def _bind(self):
        self.enable_cb.toggled.connect(self._apply_enable_state)
        self.open_btn.clicked.connect(self._choose_file)
        self.tpl_btn.clicked.connect(self._choose_template)
        self.wake_btn.clicked.connect(self._choose_wake)
        self.analyze_btn.clicked.connect(self._start_analyze)
        self.fill_btn.clicked.connect(self._write_excel)
        self.table.itemSelectionChanged.connect(self._on_sel_row)
        self.table.itemChanged.connect(self._on_cell_edited)
        self.apply_fix_btn.clicked.connect(self._apply_fix)
        self.manual_btn.clicked.connect(self._manual_fix_dialog)
        self.clear_sel_btn.clicked.connect(
            lambda: self.table.clearSelection())

    def _load_defaults(self):
        """从脚本目录 config.json 预填唤醒词/输出目录（可被用户覆盖）

        v1.6.8: 端到端耗时功能“每次启动都默认关闭”——不再根据上次配置自动
        启用。该功能涉及 ASR 模型加载，保证程序启动时不占用资源、界面最流畅；
        用户本次会话需要时再勾选顶部开关。
        """
        try:
            cfg_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "config.json")
            if not os.path.exists(cfg_path):
                return
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            wd = cfg.get("work_dir") or ""
            word = (cfg.get("wakeup_word") or "").strip()
            self.wake_word = word
            if wd and word:
                audio = os.path.join(wd, "audio")
                for ext in (".wav", ".mp3"):
                    p = os.path.join(audio, f"{word}{ext}")
                    if os.path.exists(p):
                        self.wake_edit.setText(p)
                        break
        except Exception:
            pass

    # ==================== 启用 / 停用时延功能 ====================
    # v1.6.6: 不进行响应时延测试时可整页停用 —— 不检测/加载 ASR 后端、
    # 禁止启动分析，后台零占用，让整体界面更流畅。状态持久化到 config.json。
    def _apply_enable_state(self, *_):
        on = self.enable_cb.isChecked()
        if (not on and self.worker is not None and self.worker.isRunning()):
            QMessageBox.information(
                self, "正在分析",
                "当前分析进行中，请等待完成后再停用时延功能。")
            self.enable_cb.setChecked(True)
            return
        _base = (self.open_btn, self.tpl_btn, self.wake_btn, self.model_combo,
                 self.lang_combo, self.cal_cb, self.clear_sel_btn)
        _ctx = (self.fill_btn, self.manual_btn, self.apply_fix_btn)
        if not on:
            for w in _base + _ctx:
                if w is not None:
                    w.setEnabled(False)   # 停用：一律禁用
            self._stop_probe()
            self.backend_lbl.setText("(已停用，未加载 ASR 后端)")
            self.analyze_btn.setEnabled(False)
            self._status("端到端耗时功能已停用（后台不再检测/加载 ASR 模型）")
        else:
            for w in _base:
                if w is not None:
                    w.setEnabled(True)    # 基础操作恢复
            if getattr(self, "_backend_text", ""):
                self.backend_lbl.setText(self._backend_text)
            self._status("端到端耗时功能已启用")
            if self._shown:               # 页面可见时才探测后端（启动不加载 whisper）
                self._maybe_probe_backend()
            self._refresh_ready()
            if self.res is not None:
                self._update_fill_state()
            self._on_sel_row()            # 按当前选中行恢复“修正”类按钮可用态
        self._persist_latency_enabled()

    def _maybe_probe_backend(self):
        """懒检测 faster-whisper 后端：仅启用时、且放在后台线程执行"""
        if (not self.enable_cb.isChecked() or self._backend_probed):
            return
        if self._probe is not None and self._probe.isRunning():
            return
        self._backend_probed = True
        self.backend_lbl.setText("(后端检测中…)")
        self._probe = BackendProbeThread()

        def _on_probed(txt):
            self._backend_text = txt
            self.backend_lbl.setText(txt)

        self._probe.probed.connect(_on_probed)
        self._probe.start()

    def _stop_probe(self):
        p = self._probe
        if p is not None:
            if p.isRunning():
                p.wait(1500)
            self._probe = None

    def _persist_latency_enabled(self):
        if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
            return   # 离屏自测不落盘，避免改写源码目录 config.json
        disabled = not self.enable_cb.isChecked()
        try:
            with open(_CFG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
        if data.get("latency_disabled") is disabled:
            return
        data["latency_disabled"] = disabled
        try:
            with open(_CFG_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def showEvent(self, event):
        super().showEvent(event)
        if not self._shown:
            self._shown = True
            if self.enable_cb.isChecked():
                self._maybe_probe_backend()

    # ==================== 文件选择 ====================
    def _choose_file(self):
        if not ffmpeg_exe():
            QMessageBox.warning(self, "缺 ffmpeg",
                                "未找到 ffmpeg，请先安装依赖 imageio-ffmpeg")
            return
        start = _default_file_dir("media") or os.path.dirname(self.media_path) \
            if self.media_path else _default_file_dir("media")
        path, _ = QFileDialog.getOpenFileName(
            self, "选择音/视频", start,
            "媒体文件 (*.qt *.mp4 *.mov *.avi *.mkv *.wav *.m4a *.mp3 "
            "*.aac *.flac);;所有文件 (*.*)")
        if not path:
            return
        self.media_path = path
        self.file_edit.setText(path)
        _save_ui_last_dir("media", path)
        p = detect_pass_from_filename(path)
        if p in (1, 2, 3):
            self.pass_combo.setCurrentIndex(p - 1)
        self._status(f"已选择录像: {os.path.basename(path)}")
        self._refresh_ready()

    def _choose_template(self):
        start = _default_file_dir("template")
        path, _ = QFileDialog.getOpenFileName(
            self, "选择 Excel 模板", start,
            "Excel 模板 (*.xlsx *.xlsm);;所有文件 (*.*)")
        if not path:
            return
        try:
            LatencyExcel(path)
            rows = round_table_rows(path)
        except Exception as e:      # noqa: BLE001
            QMessageBox.warning(self, "模板无效", str(e))
            return
        self.template_path = path
        self.tpl_edit.setText(path)
        _save_ui_last_dir("template", path)
        self._tpl_rows = rows
        self._status(f"模板已载入: {os.path.basename(path)}，共 {len(rows)} 个 Query")
        self._refresh_ready()

    def _choose_wake(self):
        start = _default_file_dir("wake")
        path, _ = QFileDialog.getOpenFileName(
            self, "选择唤醒词模板音频", start,
            "音频 (*.wav *.mp3 *.m4a *.flac);;所有文件 (*.*)")
        if path:
            self.wake_edit.setText(path)
            _save_ui_last_dir("wake", path)
            self._status(f"唤醒模板: {os.path.basename(path)}")

    def _refresh_ready(self):
        ready = bool(self.media_path and self.template_path)
        self.analyze_btn.setEnabled(ready)

    # ==================== 分析 ====================
    def _start_analyze(self):
        if not self.enable_cb.isChecked():
            QMessageBox.information(
                self, "功能已停用",
                "请先勾选页面顶部的「启用 端到端耗时功能」再开始分析。")
            return
        if not (self.media_path and self.template_path):
            return
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "任务进行中", "请等待当前分析完成")
            return
        if not engine_available():
            QMessageBox.warning(
                self, "缺少 faster-whisper",
                "本地 ASR 需要 faster-whisper:\n  pip install faster-whisper\n"
                "首次分析会联网下载 base 模型(~145MB)，之后完全离线。")
            return
        self.args = AnalyzeArgs(
            media_path=self.media_path,
            template_path=self.template_path,
            model_name=self.model_combo.currentData() or "base",
            language=self.lang_combo.currentData() or "auto",
            wake_path=self.wake_edit.text().strip(),
            wake_text=getattr(self, "wake_word", ""),
            use_cal=self.cal_cb.isChecked(),
            gap_ms=150)
        self._set_busy(True)
        self._status(f"分析中(模型 {self.args.model_name})… 若首次使用会自动下载模型")
        self.worker = AnalyzeWorker(self.args)
        self.worker.progress.connect(self._status)
        self.worker.failed.connect(self._on_analyze_failed)
        self.worker.finished_ok.connect(self._on_analyze_done)
        self.worker.start()

    def _set_busy(self, busy):
        self.analyze_btn.setEnabled(not busy)
        self.fill_btn.setEnabled(False)

    def _on_analyze_failed(self, msg):
        self._set_busy(False)
        self.res = None
        self._status(f"分析失败: {msg}")
        QMessageBox.warning(self, "分析失败", msg)

    def _on_analyze_done(self):
        self._set_busy(False)
        if self.worker is None:
            return
        self.res = self.worker.result
        self._render_results()
        ok_n = sum(1 for r in self.res.results if r["status"] == "ok")
        warn_n = sum(1 for r in self.res.results if r["status"] == "warn")
        miss_n = sum(1 for r in self.res.results if r["status"] == "miss")
        self._status(
            f"分析完成: 已确认 {ok_n} / 待确认 {warn_n} / 未匹配 {miss_n} 行"
            + (f" | 已扣除校准延迟 {self.res.cal_s*1000:.1f}ms"
               if self.res.cal_s > 0 else "")
            + (f" | 唤醒词命中 {len(self.res.wake_occs)} 处"
               if self.res.wake_occs else " | 未启用/未检测到唤醒词模板"))

    # ==================== 结果渲染 ====================
    def _render_results(self):
        if self.res is None:
            return
        self._updating = True
        try:
            rows = self.res.rows
            self.table.setRowCount(len(rows))
            for i, (info, res) in enumerate(zip(rows, self.res.results)):
                status = res["status"]
                a = "" if res["a_ms"] is None else str(res["a_ms"])
                b = "" if res["b_ms"] is None else str(res["b_ms"])
                vals = [str(i + 1), info["domain"], info["query"],
                        a, b, STATUS_TEXT[status]]
                for c, txt in enumerate(vals):
                    it = QTableWidgetItem(txt)
                    if c in (3, 4):        # A/B 可手改
                        it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                        it.setFlags(it.flags() | Qt.ItemIsEditable)
                    else:
                        it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                    if c == 5:
                        it.setForeground(QColor(STATUS_COLOR[status]))
                        it.setBackground(QColor(STATUS_BG[status]))
                    self.table.setItem(i, c, it)
                self.table.item(i, 0).setData(Qt.UserRole, res)
        finally:
            self._updating = False
        self._update_fill_state()

    def _update_fill_state(self):
        if self.res is None:
            self.fill_btn.setEnabled(False)
            return
        warn_n = sum(1 for r in self.res.results if r["status"] != "ok")
        ok_n = sum(1 for r in self.res.results if r["status"] == "ok")
        total = len(self.res.results)
        if warn_n == 0:
            self.summary_lbl.setText(
                f"共 {total} 行全部已确认（绿） — 可直接写入 Excel")
            self.fill_btn.setText("全部匹配，一键写入 Excel")
            self.fill_btn.setEnabled(bool(total))
        else:
            self.summary_lbl.setText(
                f"共 {total} 行: 已确认 {ok_n}（绿）/ 需修正 {warn_n}（橙+红）")
            self.fill_btn.setText(f"先修正 {warn_n} 处异常后才能写入")
            self.fill_btn.setEnabled(False)

    # ==================== 单元格手改 / 修正 ====================
    def _on_sel_row(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows or self.res is None:
            self.fix_cmd_combo.clear()
            self.fix_reply_combo.clear()
            return
        i = rows[0].row()
        res = self.res.results[i] if 0 <= i < len(self.res.results) else None
        if res is None:
            return
        self._fill_fix_combos(res)

    def _fill_fix_combos(self, res):
        self.fix_cmd_combo.blockSignals(True)
        self.fix_reply_combo.blockSignals(True)
        self.fix_cmd_combo.clear()
        self.fix_reply_combo.clear()
        self.fix_cmd_combo.addItem("(请选择指令语音段)", -1)
        self.fix_reply_combo.addItem("(自动=指令后第一段)", -1)
        for u in (self.res.units or []):
            label = f"#{u['index']} {u['start_s']:.2f}-{u['end_s']:.2f}s " \
                    f"{(u.get('text') or '')[:20]}"
            self.fix_cmd_combo.addItem(label, u["index"])
            self.fix_reply_combo.addItem(label, u["index"])
        sel = (res.get("cmd_unit_ids") or [None])[0]
        if sel is not None:
            ix = self.fix_cmd_combo.findData(sel)
            if ix >= 0:
                self.fix_cmd_combo.setCurrentIndex(ix)
        if res.get("reply_unit_id") is not None:
            ix = self.fix_reply_combo.findData(res["reply_unit_id"])
            if ix >= 0:
                self.fix_reply_combo.setCurrentIndex(ix)
        self.fix_cmd_combo.blockSignals(False)
        self.fix_reply_combo.blockSignals(False)

    def _unit_by_id(self, uid):
        for u in (self.res.units or []):
            if u["index"] == uid:
                return u
        return None

    def _apply_fix(self):
        if self.res is None:
            return
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            QMessageBox.information(self, "提示", "请先在结果表中选中要修正的行")
            return
        i = rows[0].row()
        if not (0 <= i < len(self.res.results)):
            return
        res = self.res.results[i]
        cmd_id = self.fix_cmd_combo.currentData()
        reply_id = self.fix_reply_combo.currentData()
        if cmd_id is None or cmd_id == -1:
            QMessageBox.warning(self, "提示", "请选择正确的指令语音段")
            return
        self._recompute_row(res, cmd_id, reply_id)
        self._render_results()
        self._status(f"第 {i+1} 行已按所选语音段重算")
        self._fill_fix_combos(res)

    def _recompute_row(self, res, cmd_id, reply_id=-1):
        """按用户在修正栏选择的语音段重算该行 A/B 与状态"""
        units = self.res.units or []
        cal = (self.res.cal_s or 0.0) * 1000.0
        cmd_u = self._unit_by_id(cmd_id)
        if cmd_u is None:
            return
        res["cmd_unit_ids"] = [cmd_id]
        res["cmd_start_s"] = cmd_u["start_s"]
        res["cmd_end_s"] = cmd_u["end_s"]
        res["note"] = "人工修正"
        # 回复: 手动选择或自动取指令后第一段
        reply_u = None
        if reply_id not in (None, -1):
            reply_u = self._unit_by_id(reply_id)
        if reply_u is None:
            for u in units:
                if u["start_s"] > cmd_u["end_s"] + 0.005:
                    reply_u = u
                    break
        if reply_u is not None:
            res["reply_unit_id"] = reply_u["index"]
            res["reply_start_s"] = reply_u["start_s"]
            res["b_ms"] = int(round((reply_u["start_s"] - cmd_u["end_s"])
                                    * 1000.0 - cal))
            if res["b_ms"] < -150 or res["b_ms"] > 12000:
                res["status"] = "warn"
                res["note"] = "时延值异常，请核对端点"
            else:
                res["status"] = "ok"
        else:
            res["b_ms"] = None
            res["status"] = "warn"
            res["note"] = "指令后未找到回复段"
        # 手动修正后 A 暂不自动重算，保留原值或留空
        return res

    def _on_cell_edited(self, item):
        if self._updating or self.res is None:
            return
        col = item.column()
        row = item.row()
        if col not in (3, 4):
            return
        if not (0 <= row < len(self.res.results)):
            return
        res = self.res.results[row]
        txt = str(item.text()).strip()
        try:
            val = int(float(txt)) if txt else None
        except ValueError:
            QMessageBox.warning(self, "格式错误", "请输入整数毫秒或留空")
            self._render_results()
            return
        if col == 3:
            res["a_ms"] = val
        else:
            res["b_ms"] = val
        res["status"] = "ok" if (res["b_ms"] is not None) else "warn"
        res["note"] = "人工填值"
        self._update_fill_state()

    # ==================== 波形手动定位 ====================
    def _manual_fix_dialog(self):
        if self.res is None or pg is None:
            if pg is None:
                QMessageBox.warning(self, "提示", "缺少 pyqtgraph，无法打开波形")
            return
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            QMessageBox.information(self, "提示", "请先选中要手动定位的行")
            return
        dlg = ManualFixDialog(self.res.env_t, self.res.env_v,
                              self.res.units, self)
        if dlg.exec_() != QDialog.Accepted:
            return
        vals = dlg.values()
        i = rows[0].row()
        res = self.res.results[i]
        # 用拖出的 指令尾音 + TTS首帧 填 B；唤醒尾音+应答 填 A（若拖过）
        cal = (self.res.cal_s or 0.0) * 1000.0
        cmd_end = vals.get("cmd_end", 0.0)
        reply_start = vals.get("reply_start", 0.0)
        if reply_start > cmd_end > 0:
            res["cmd_end_s"] = cmd_end
            res["cmd_start_s"] = max(0.0, cmd_end - 2.0)
            res["cmd_unit_ids"] = []
            res["b_ms"] = int(round((reply_start - cmd_end) * 1000.0 - cal))
            res["reply_start_s"] = reply_start
            res["status"] = "ok"
            res["note"] = "波形手动定位"
            if res["b_ms"] < -150 or res["b_ms"] > 12000:
                res["status"] = "warn"
        wk = vals.get("wake_end", 0.0)
        ans = vals.get("answer_start", 0.0)
        if ans > wk > 0:
            res["wake_end_s"] = wk
            res["answer_start_s"] = ans
            res["a_ms"] = int(round((ans - wk) * 1000.0 - cal))
        self._render_results()
        self._status(f"第 {i+1} 行已按波形手动定位更新")

    # ==================== 写入 Excel ====================
    def _write_excel(self):
        if self.res is None:
            return
        if not self.template_path:
            QMessageBox.warning(self, "提示", "请先载入 Excel 模板")
            return
        bad = [i for i, r in enumerate(self.res.results) if r["status"] != "ok"]
        if bad:
            QMessageBox.warning(
                self, "存在异常行",
                f"仍有 {len(bad)} 行未确认（橙/红），请先在表格中修正：\n"
                + "、".join(str(i + 1) for i in bad[:20]))
            return
        pass_no = self.pass_combo.currentIndex() + 1
        try:
            xl = LatencyExcel(self.template_path)
        except Exception as e:      # noqa: BLE001
            QMessageBox.warning(self, "模板打开失败", str(e))
            return
        values = [{"a_ms": r["a_ms"], "b_ms": r["b_ms"]}
                  for r in self.res.results]
        if len(values) > len(xl.all_rows):
            QMessageBox.warning(self, "行数不匹配",
                                "结果行数超过模板 Query 行数，请检查模板")
            return
        xl.fill_pass(pass_no, values)
        xl.write_summary()
        out = xl.save()
        n_filled = sum(1 for v in values
                       if v["a_ms"] is not None or v["b_ms"] is not None)
        self._status(f"已写入第 {pass_no} 遍 ({n_filled} 行有值) -> "
                     f"{os.path.basename(out)}")
        QMessageBox.information(
            self, "完成",
            f"已生成回填 Excel：\n{out}\n\n共写入 {n_filled} 行。\n"
            "平均列公式已保留，用 Excel 打开会自动计算汇总。")

    # ==================== 工具 ====================
    def _status(self, msg):
        self.status_lbl.setText(msg)
        app_log.ui(msg)

    def shutdown(self):
        self._stop_probe()
        if self.worker is not None and self.worker.isRunning():
            self.worker.wait(8000)

    def closeEvent(self, event):
        self.shutdown()
        event.accept()
