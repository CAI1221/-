# core/app_log.py
# 会话运行日志：从 `python main.py` 启动到退出全程落盘。
#
# 需求背景:
#   工具运行期间的完整过程（含各 Tab 页面操作、进入安卓 ADB / QNX SSH、
#   执行的每一条命令与结果）都要求归档到脚本同目录下的一个专门日志文件夹，
#   固定文件名 "NOMI_性能测试脚本_log.txt"。
#
# 实现(性能优化版):
#   - init_log(app_dir) 在工具目录下创建: <app_dir>/运行日志/NOMI_性能测试脚本_log.txt
#   - log(tag, msg)     带时间戳(毫秒)的结构化事件日志
#   - ui(text)          界面日志镜像（连接/执行/日志/响应时延各 Tab 内容）
#   - Tee stdout/stderr: python main.py 的控制台 print 输出同步写入同一文件
#   - 调用侧只把日志行放入内存队列（极快，不回 UI 线程/执行线程做文件 I/O），
#     由独立后台线程每 ~0.25s 批量写入并 flush 一次，避免“越写越卡”。
#   - 多轮运行自动追加；单文件超过 8MB 自动轮转保留 .old
#   - 未 init_log 时所有调用均为安全空操作（不影响离屏测试与单元测试）
import os
import sys
import threading
import time

_LOG_DIR_NAME = "运行日志"
_LOG_FILE_NAME = "NOMI_性能测试脚本_log.txt"
_MAX_BYTES = 8 * 1024 * 1024
_FLUSH_INTERVAL = 0.25     # 后台落盘周期（秒）
_ROTATE_CHECK_EVERY = 200  # 每 N 次落盘检查一次文件大小

_lock = threading.Lock()
_enabled = False
_path = ""
_file = None
_buf: list = []
_writer = None
_stop_evt = threading.Event()
_stdout_orig = None
_stderr_orig = None
_drain_count = 0


def _now() -> str:
    """时间戳: 2026-09-04 23:30:11.234"""
    t = time.time()
    lt = time.localtime(t)
    ms = int((t - int(t)) * 1000)
    return "%s.%03d" % (time.strftime("%Y-%m-%d %H:%M:%S", lt), ms)


def _enqueue(line: str):
    """把一行压入内存队列（调用者无需持锁，本函数自行加锁）"""
    if not _enabled or not line:
        return
    with _lock:
        _buf.append(line)


def _rotate_locked():
    """日志超过上限时轮转：当前文件 -> <同名>.old（调用方必须持锁）"""
    global _file
    try:
        if os.path.exists(_path) and os.path.getsize(_path) > _MAX_BYTES:
            old = _path + ".old"
            if os.path.exists(old):
                os.remove(old)
            os.replace(_path, old)
    except Exception:
        pass
    try:
        if _file is not None:
            try:
                _file.close()
            except Exception:
                pass
        _file = open(_path, "a", encoding="utf-8")
    except Exception:
        _file = None


def _drain():
    """把内存队列一次性写入文件并 flush（后台线程调用）"""
    global _buf, _file, _drain_count
    with _lock:
        if not _buf:
            return
        if _file is None:
            _buf.clear()
            return
        lines, _buf = _buf, []
    try:
        _file.write("".join(line + "\n" for line in lines))
        _file.flush()
    except Exception:
        pass
    # 周期性检查文件大小，超限自动轮转
    _drain_count += 1
    if _drain_count % _ROTATE_CHECK_EVERY == 0:
        with _lock:
            _rotate_locked()


def _writer_main():
    """后台写盘线程：周期性把队列刷入文件"""
    while not _stop_evt.wait(_FLUSH_INTERVAL):
        _drain()
    _drain()


def log_path() -> str:
    """当前会话日志文件的完整路径（未初始化返回空字符串）"""
    return _path


def init_log(app_dir: str, app_version: str = "") -> bool:
    """在 app_dir/运行日志/ 下建立会话日志并接管 stdout/stderr

    app_dir 应传工具脚本(main.py)所在目录：部署到哪个目录，
    日志就落在哪个目录下，与脚本保持同路径。
    """
    global _enabled, _path, _file, _writer, _stdout_orig, _stderr_orig
    # 离屏自测/自动回归环境不落盘，避免污染源码目录
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        return False
    close_log()
    try:
        log_dir = os.path.join(str(app_dir), _LOG_DIR_NAME)
        os.makedirs(log_dir, exist_ok=True)
        _path = os.path.join(log_dir, _LOG_FILE_NAME)
        with _lock:
            _rotate_locked()
        _enabled = _file is not None
    except Exception:
        _enabled = False
        return False
    if not _enabled:
        return False
    _enqueue("=" * 72)
    _enqueue("[%s] ===== NOMI 自动化测试工具 %s 启动 (PID %d) ====="
             % (_now(), app_version, os.getpid()))
    _enqueue("[%s] 运行日志文件: %s" % (_now(), _path))
    _drain()   # 先把启动横幅落盘，保证文件立刻有内容
    # 启动后台写盘线程
    _stop_evt.clear()
    _writer = threading.Thread(target=_writer_main, daemon=True,
                               name="runlog-writer")
    _writer.start()
    # Tee: 控制台输出同步落盘
    _stdout_orig, _stderr_orig = sys.stdout, sys.stderr
    try:
        sys.stdout = _Tee(_stdout_orig)
        sys.stderr = _Tee(_stderr_orig)
    except Exception:
        pass
    return True


def close_log():
    """写结束标记并关闭日志（进程退出前调用，可重复调用）"""
    global _enabled, _file, _writer, _stdout_orig, _stderr_orig
    _stop_evt.set()
    if _writer is not None:
        try:
            if _writer.is_alive():
                _writer.join(2.0)
        except Exception:
            pass
        _writer = None
    with _lock:
        if _enabled and _file:
            try:
                _file.write("[%s] ===== 程序退出 =====\n" % _now())
                _file.flush()
            except Exception:
                pass
        _enabled = False
        if _file is not None:
            try:
                _file.close()
            except Exception:
                pass
            _file = None
    # 还原控制台流
    if _stdout_orig is not None:
        try:
            sys.stdout = _stdout_orig
        except Exception:
            pass
        _stdout_orig = None
    if _stderr_orig is not None:
        try:
            sys.stderr = _stderr_orig
        except Exception:
            pass
        _stderr_orig = None


def log(tag: str, msg: str):
    """结构化事件日志: [时间戳] [标签] 消息（仅入队，后台落盘）"""
    if not _enabled:
        return
    _enqueue("[%s] [%s] %s" % (_now(), tag, msg))


def ui(text: str):
    """界面日志镜像：把各 Tab 页面显示的过程日志同步写入文件（仅入队）"""
    if not _enabled or not text:
        return
    now = _now()
    with _lock:
        for ln in str(text).splitlines():
            if ln.strip():
                _buf.append("[%s] %s" % (now, ln))


class _Tee:
    """同时写回原始流与运行日志的 stdout/stderr 代理"""

    def __init__(self, stream):
        self._stream = stream

    def write(self, text):
        if not text:
            return
        try:
            self._stream.write(text)
            self._stream.flush()
        except Exception:
            pass
        if not _enabled:
            return
        now = _now()
        with _lock:
            for ln in str(text).splitlines():
                if ln.strip():
                    _buf.append("[%s] %s" % (now, ln))

    def flush(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    def isatty(self):
        try:
            return self._stream.isatty()
        except Exception:
            return False
