# core/latency_fast.py - 整轨一次 ASR（v1.6.5，替代逐 VAD 段独立推理）
#
# 背景: 旧实现把每段 VAD 段单独送 faster-whisper，base 模型在 CPU 上要反复
#       加载/编码，长录音数百段时总耗时十几分钟，且模型 int8 量化/推理吃满
#       所有核心，把 PyQt 界面拖到假死甚至闪退。
# 本模块: 整条录音只加载一次模型、只编码一次，逐段吐出识别结果（进度实时），
#       再与 VAD 精修段做时间交叠切分。速度提升 10-30 倍，界面不会卡。
import time


def transcribe_full(x16, model_name="base", language="auto", emit=None):
    """对整轨 16kHz float32 做一次 ASR，返回 [{start,end,text}, ...]

    x16: 整轨 16kHz 单声道音频（np.float32 数组）
    model_name/language: 与 core.asr_align 语义一致（auto=中英自动）
    emit: 可选进度回调 fn(msg)（在调用线程同步执行）
    """
    import numpy as np
    from core.asr_align import load_model, pick_backend
    x = np.asarray(x16)
    if x.size == 0:
        return []
    if emit:
        emit(f"加载 ASR 模型 {model_name}（{pick_backend()}）… "
             "首次需约 20-60 秒做 int8 量化，请稍候")
    t0 = time.time()
    model = load_model(model_name)
    if emit:
        emit(f"模型就绪（{time.time()-t0:.1f}s），整轨识别中…")
    lang = None if language == "auto" else language
    segs_iter, _info = model.transcribe(
        x, language=lang, task="transcribe", beam_size=1,
        condition_on_previous_text=False, vad_filter=False)
    out = []
    last = 0.0
    for s in segs_iter:
        txt = (s.text or "").strip()
        if not txt:
            continue
        item = {"start": float(s.start), "end": float(s.end), "text": txt}
        out.append(item)
        now = time.time()
        if emit and (now - last) > 0.35:      # 节流刷新，避免刷屏
            last = now
            emit(f"  已识别 [{item['start']:.1f}-{item['end']:.1f}s] "
                 f"{txt[:40]}")
    if emit:
        emit(f"整轨识别完成：{len(out)} 段，耗时 {time.time()-t0:.1f}s")
    return out


def units_from_segments(refined, full_segs, context_s=0.06):
    """把整轨 ASR 文本段切分到 VAD 精修段上，生成对齐单元。

    refined: [(s0,e0), ...]（秒）
    full_segs: 整轨 ASR [{start,end,text}, ...]
    context_s: 允许的边界误差（60ms）
    返回 [{index,start_s,end_s,text}, ...]
    """
    units = []
    j = 0
    n = len(full_segs)
    for idx, (s0, e0) in enumerate(refined, start=1):
        buf = []
        while j < n and full_segs[j]["end"] < s0 - context_s:
            j += 1
        k = j
        while k < n and full_segs[k]["start"] <= e0 + context_s:
            seg = full_segs[k]
            # 该 ASR 段与当前 VAD 段重叠才归属
            if seg["end"] > s0 - context_s and seg["start"] < e0 + context_s:
                buf.append(seg["text"])
            k += 1
        text = " ".join(buf).strip()
        units.append({"index": idx, "start_s": float(s0), "end_s": float(e0),
                      "text": text})
    return units
