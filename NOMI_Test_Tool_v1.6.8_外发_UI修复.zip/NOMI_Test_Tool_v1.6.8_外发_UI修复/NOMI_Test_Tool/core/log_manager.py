# core/log_manager.py
# 车机日志管理：安卓 logd 拉取/清空 + QNX slog 导出/清空
# 供「连接设备」页手动按钮和「日志测试」引擎结束后自动调用
import os
import shutil
import subprocess
from datetime import datetime
from typing import Callable, Optional, Tuple

from .constants import (
    LOGD_REMOTE_DIR, LOGCAT_CLEAR_CMD, LOGD_CLEAR_CMD,
    SLOG_REMOTE_DIR, QNX_SLOG_CLEAR_CMD,
)
from .ssh_executor import SSHClientWrapper
from . import app_log


def _adb(cmd: str, timeout: int = 60) -> Tuple[bool, str]:
    """执行 adb 命令（shell=True 保持与 AdbExecutor 一致的调用方式）"""
    try:
        app_log.log("ADB", f"执行: {cmd}")
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout)
        out = ((r.stdout or "") + (r.stderr or "")).strip()
        app_log.log("ADB", f"完成: returncode={r.returncode} 结果={out[:200] or '(空)'}")
        return r.returncode == 0, out
    except Exception as e:
        return False, str(e)


def adb_alive() -> bool:
    """ADB 是否连通"""
    ok, out = _adb("adb shell echo ok", timeout=8)
    return ok and "ok" in out


# ==================== 安卓 logd ====================
def pull_logd(local_base_dir: str,
              log_cb: Optional[Callable[[str], None]] = None) -> Tuple[bool, str]:
    """把车机 /data/misc/nio/logd 整个目录拉取到 local_base_dir/logd/

    本地目录名固定叫 logd（与 slog 目录一致），重复拉取会合并进同一目录。
    只拉取、不删除远端任何日志；清空/删除只发生在用户点击「清空日志」时。

    返回 (成功, 说明)。目录不存在 / ADB 断开 / 远端无文件 都算失败。
    """
    def _log(msg):
        if log_cb:
            try:
                log_cb(msg)
            except Exception:
                pass

    if not adb_alive():
        return False, "ADB 未连接，无法拉取 logd"

    # 先确认远端目录存在且可读（权限不足时给出明确提示）
    ok, out = _adb(f'adb shell "ls {LOGD_REMOTE_DIR}"', timeout=15)
    if not ok:
        low = out.lower()
        if "no such file" in low or "not found" in low:
            reason = "车机上不存在该目录"
        elif "denied" in low or "permission" in low:
            reason = ("权限不足，无法访问该目录（请先在 adb 中执行 adb root，"
                      "或在车机端确认 /data/misc/nio/logd 存在）")
        else:
            reason = f"访问失败（输出: {out[:120]}）"
        return False, f"logd 目录检查失败 {LOGD_REMOTE_DIR}: {reason}"
    if not out.strip():
        # ls 成功但目录为空
        return False, (f"logd 目录为空 {LOGD_REMOTE_DIR}"
                       "（若刚清过日志则暂无文件可拉取）")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = os.path.join(local_base_dir, "logd")
    os.makedirs(target, exist_ok=True)
    # 先拉到唯一临时目录，再合并进 logd，避免不同 adb 版本对“目录拉取”行为不一致
    stage = os.path.join(local_base_dir, f".nomi_logd_stage_{ts}")
    os.makedirs(stage, exist_ok=True)
    _log(f"拉取 {LOGD_REMOTE_DIR} -> {target}")
    ok, out = _adb(f'adb pull "{LOGD_REMOTE_DIR}" "{stage}"', timeout=300)
    if not ok:
        shutil.rmtree(stage, ignore_errors=True)
        low = out.lower()
        if "denied" in low or "permission" in low:
            why = "权限不足（请先 adb root 后再拉取）"
        elif "does not exist" in low or "no such" in low:
            why = "远端目录不存在"
        else:
            why = out[:180]
        return False, f"adb pull 失败: {why}"

    # adb 可能把远端目录又包了一层同名目录(logd)；有则把里面的内容提出来
    nested = os.path.join(stage, os.path.basename(LOGD_REMOTE_DIR.rstrip("/")))
    src = nested if os.path.isdir(nested) else stage

    moved = 0
    for name in os.listdir(src):
        s = os.path.join(src, name)
        d = os.path.join(target, name)
        try:
            if os.path.isdir(s):
                # 子目录整体替换：以当前远端快照为准
                if os.path.isdir(d):
                    shutil.rmtree(d, ignore_errors=True)
                shutil.move(s, d)
            else:
                # 同名文件覆盖为本次拉取的新内容
                if os.path.exists(d):
                    try:
                        os.remove(d)
                    except Exception:
                        pass
                shutil.move(s, d)
            moved += 1
        except Exception:
            continue
    shutil.rmtree(stage, ignore_errors=True)

    if moved == 0:
        return False, "拉取完成但目录为空（logd 可能没有日志文件）"
    file_count = sum(len(fs) for _r, _ds, fs in os.walk(target))
    _log(f"logd 拉取完成: 新增 {moved} 项，目录共 {file_count} 个文件")
    return True, target


def clear_android_logs(log_cb: Optional[Callable[[str], None]] = None) -> Tuple[bool, str]:
    """清空车机安卓侧日志: logcat 缓冲 + /data/misc/nio/logd 旧文件"""
    def _log(msg):
        if log_cb:
            try:
                log_cb(msg)
            except Exception:
                pass

    if not adb_alive():
        return False, "ADB 未连接，无法清空安卓日志"

    problems = []
    # 1. 清 logcat 内存缓冲
    ok, out = _adb(f'adb shell "{LOGCAT_CLEAR_CMD}"', timeout=15)
    if ok:
        _log("logcat 缓冲已清空")
    else:
        problems.append(f"logcat 清空失败: {out[:120]}")
    # 2. 删 nio/logd 旧文件（目录保留，守护进程会重建文件）
    ok, out = _adb(f'adb shell "{LOGD_CLEAR_CMD}"', timeout=30)
    if ok:
        _log(f"已删除 {LOGD_REMOTE_DIR} 旧文件")
    else:
        problems.append(f"logd 清理失败: {out[:120]}")

    if problems:
        return False, "; ".join(problems)
    return True, "安卓日志已清空"


# ==================== QNX slog ====================
def pull_slog(ssh: SSHClientWrapper, local_base_dir: str, local_name: str = "",
              log_cb: Optional[Callable[[str], None]] = None) -> Tuple[bool, str]:
    """把 QNX /blackbox/cdclogs/qnx/slog 整个目录递归拉取到 local_base_dir/slog/

    等同 scp -r /blackbox/cdclogs/qnx/slog/ .，本地固定落 <local_base_dir>/slog
    （与 logd 同规则），重复拉取合并；只拉取、不删除远端。

    返回 (成功, 说明)。SSH 断开 / 远端目录不存在或为空 都算失败。
    """
    def _log(msg):
        if log_cb:
            try:
                log_cb(msg)
            except Exception:
                pass

    if not ssh.is_connected():
        return False, "SSH 未连接，无法拉取 slog"

    target = os.path.join(local_base_dir, "slog")
    _log(f"拉取 {SLOG_REMOTE_DIR} -> {target}")
    ok, msg = ssh.sftp_get_dir_recursive(SLOG_REMOTE_DIR, target)
    if not ok:
        return False, f"slog 目录拉取失败: {msg[:200]}"
    count = sum(len(fs) for _r, _ds, fs in os.walk(target))
    _log(f"slog 拉取完成: 共 {count} 个文件 -> {target}")
    return True, target


def clear_qnx_slog(ssh: SSHClientWrapper,
                   log_cb: Optional[Callable[[str], None]] = None) -> Tuple[bool, str]:
    """清空 QNX slog2 实时缓冲区（slog2info -c）"""
    if not ssh.is_connected():
        return False, "SSH 未连接，无法清空 slog"
    ok, out = ssh.exec(QNX_SLOG_CLEAR_CMD, timeout=15)
    if not ok:
        return False, f"slog2info -c 失败: {(out or '')[:150]}"
    if log_cb:
        try:
            log_cb("QNX slog 缓冲已清空")
        except Exception:
            pass
    return True, "QNX slog 已清空"
