# core/tunnel_manager.py
# SSH 隧道管理器：纯 paramiko 实现本地端口转发
# 不依赖 sshtunnel 库（sshtunnel 0.4.0 与 paramiko>=3.2 不兼容，会导致自动建隧道失败）
# 原理: 本地 TCP 监听 -> 收到连接后通过 SSH transport 打开 direct-tcpip 通道 -> 双向泵数据
import os
import socket
import threading
import time
from typing import List, Optional, Tuple

import paramiko

from core import app_log


def check_port_open(host: str, port: int, timeout: float = 2.0) -> bool:
    """检查端口是否可连接"""
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True
    except Exception:
        return False


def get_local_ips() -> List[str]:
    """获取本机所有 IPv4 地址（诊断绑定失败用）"""
    ips = set()
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
            ips.add(info[4][0])
    except Exception:
        pass
    ips.add("127.0.0.1")
    return sorted(ips)


class _TunnelConnection:
    """一条转发连接：本地 socket <-> SSH channel 双向泵"""

    def __init__(self, sock: socket.socket, channel):
        self.sock = sock
        self.channel = channel
        self._closed = False

    def start(self):
        threading.Thread(target=self._pump_sock_to_chan, daemon=True).start()
        threading.Thread(target=self._pump_chan_to_sock, daemon=True).start()

    def _pump_sock_to_chan(self):
        try:
            while True:
                data = self.sock.recv(16384)
                if not data:
                    break
                self.channel.sendall(data)
        except Exception:
            pass
        finally:
            self.close()

    def _pump_chan_to_sock(self):
        try:
            while True:
                data = self.channel.recv(16384)
                if not data:
                    break
                self.sock.sendall(data)
        except Exception:
            pass
        finally:
            self.close()

    def close(self):
        if self._closed:
            return
        self._closed = True
        for s in (self.sock, self.channel):
            try:
                s.close()
            except Exception:
                pass


class ParamikoForwarder:
    """本地端口转发器：local_host:local_port -> (经 SSH) remote_host:remote_port"""

    def __init__(self, ssh_client, local_host: str, local_port: int,
                 remote_host: str, remote_port: int):
        self._ssh_client = ssh_client
        self._local_host = local_host
        self._local_port = local_port
        self._remote_host = remote_host
        self._remote_port = remote_port
        self._server: Optional[socket.socket] = None
        self._conns: List[_TunnelConnection] = []
        self._lock = threading.Lock()
        self._running = False

    def start(self) -> Tuple[bool, str]:
        try:
            transport = self._ssh_client.get_transport()
            if transport is None or not transport.is_active():
                return False, "SSH 传输通道不可用"
            err = self._try_bind(retry=True)
            if err is not None:
                return False, err
            self._server.listen(8)
            self._server.settimeout(1.0)
            self._running = True
            threading.Thread(target=self._accept_loop, daemon=True).start()
            return True, "ok"
        except OSError as e:
            return False, (f"本地绑定 {self._local_host}:{self._local_port} 失败: {e}"
                           f"（本机 IP: {', '.join(get_local_ips())}，"
                           f"请确认网卡已配置该静态 IP）")

    def _try_bind(self, retry: bool = False) -> Optional[str]:
        """绑定本地端口。

        Windows 上使用 SO_EXCLUSIVEADDRUSE 独占端口：
        - 若端口已被其他程序占用（例如用户手动开的 ssh 隧道），绑定立即失败，
          绝不静默“共用”同一端口导致流量被抢（SO_REUSEADDR 在 Windows 上会劫持端口）。
        - 若因上一轮连接处于 TIME_WAIT 导致占用，等待 2 秒后重试一次。
        """
        try:
            self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            if os.name == "nt":
                try:
                    self._server.setsockopt(
                        socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                except (AttributeError, OSError):
                    pass
            else:
                self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._server.bind((self._local_host, self._local_port))
            return None
        except OSError as e:
            try:
                self._server.close()
            except Exception:
                pass
            self._server = None
            if retry:
                time.sleep(2.0)
                return self._try_bind(retry=False)
            return (f"本地绑定 {self._local_host}:{self._local_port} 失败: {e}"
                    f"（端口可能已被占用，如手动隧道未关闭/刚退出工具需等 1-2 分钟；"
                    f"本机 IP: {', '.join(get_local_ips())}，"
                    f"请确认网卡已配置该静态 IP）")

    def _accept_loop(self):
        while self._running:
            try:
                conn, _ = self._server.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._handle, args=(conn,), daemon=True).start()

    def _handle(self, conn: socket.socket):
        try:
            transport = self._ssh_client.get_transport()
            if transport is None or not transport.is_active():
                conn.close()
                return
            chan = transport.open_channel(
                "direct-tcpip",
                (self._remote_host, self._remote_port),
                ("127.0.0.1", 0),
                timeout=10,
            )
            if chan is None:
                conn.close()
                return
            tc = _TunnelConnection(conn, chan)
            with self._lock:
                self._conns.append(tc)
            tc.start()
        except Exception:
            try:
                conn.close()
            except Exception:
                pass

    def stop(self):
        self._running = False
        if self._server:
            try:
                self._server.close()
            except Exception:
                pass
        with self._lock:
            conns = list(self._conns)
            self._conns.clear()
        for c in conns:
            c.close()


class TunnelManager:
    """管理 SSH 隧道的创建、状态检查和销毁（纯 paramiko，始终可用）"""

    def __init__(self):
        self._forwarders: List[ParamikoForwarder] = []
        self._clients: List[paramiko.SSHClient] = []
        self._lock = threading.Lock()

    @staticmethod
    def is_available() -> bool:
        """纯 paramiko 实现，无外部依赖"""
        return True

    @staticmethod
    def check_tunnels_active(tunnel_defs: List[Tuple[str, int]]) -> bool:
        """检查所有隧道端口是否都在监听"""
        return all(check_port_open(h, p, 1.0) for h, p in tunnel_defs)

    def create_tunnel(self, ssh_host: str, ssh_port: int, ssh_user: str,
                      ssh_password: str, local_host: str, local_port: int,
                      remote_host: str, remote_port: int) -> Tuple[bool, str]:
        """创建一条 SSH 隧道（端口已在监听则跳过）"""
        if check_port_open(local_host, local_port, 1.0):
            return True, f"端口 {local_host}:{local_port} 已在监听，跳过"

        app_log.log("隧道", f"创建: 本地 {local_host}:{local_port} -> "
                            f"{remote_host}:{remote_port} (经跳板 "
                            f"{ssh_user}@{ssh_host}:{ssh_port})")
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(
                hostname=ssh_host, port=ssh_port, username=ssh_user,
                password=ssh_password, timeout=10,
                allow_agent=False, look_for_keys=False,
            )
            transport = client.get_transport()
            if transport is not None:
                transport.set_keepalive(30)
        except Exception as e:
            app_log.log("隧道", f"连接跳板失败: {ssh_user}@{ssh_host}:{ssh_port}: {e}")
            return False, f"连接隧道服务器 {ssh_host}:{ssh_port} 失败: {e}"

        fwd = ParamikoForwarder(client, local_host, local_port,
                                remote_host, remote_port)
        ok, msg = fwd.start()
        if not ok:
            try:
                client.close()
            except Exception:
                pass
            app_log.log("隧道", f"转发器启动失败: {msg}")
            return False, msg

        with self._lock:
            self._forwarders.append(fwd)
            self._clients.append(client)

        for _ in range(10):
            if check_port_open(local_host, local_port, 1.0):
                app_log.log("隧道", f"建立成功: 本地 {local_host}:{local_port} 已监听")
                return True, (f"隧道 {local_host}:{local_port} -> "
                              f"{remote_host}:{remote_port} 建立成功")
            time.sleep(0.5)
        app_log.log("隧道", f"建立后端口 {local_host}:{local_port} 未监听")
        return False, f"隧道 {local_host}:{local_port} 建立后端口未监听"

    def stop_all(self):
        """关闭所有隧道和对应 SSH 连接"""
        app_log.log("隧道", f"关闭全部隧道/SSH 连接 (当前 {self.get_active_count()} 条)")
        with self._lock:
            forwarders = list(self._forwarders)
            clients = list(self._clients)
            self._forwarders.clear()
            self._clients.clear()
        for f in forwarders:
            f.stop()
        for c in clients:
            try:
                c.close()
            except Exception:
                pass

    def get_active_count(self) -> int:
        return len(self._forwarders)


# ==================== 共享单例 ====================
_shared: Optional[TunnelManager] = None
_shared_lock = threading.Lock()


def shared_manager() -> TunnelManager:
    """全局共享的隧道管理器（整个应用生命周期复用，退出时统一关闭）"""
    global _shared
    with _shared_lock:
        if _shared is None:
            _shared = TunnelManager()
        return _shared
