# core/latency_analyze.py - 响应时延分析纯逻辑（headless，v1.6.5）
#
# 从 ui.latency_page.AnalyzeWorker 提取的“无 Qt 依赖”主流程：
#   解码 -> 校准音互相关(可选扣除) -> VAD+端点精修 -> 包络
#   -> 唤醒词模板互相关(可选) -> 整轨一次 ASR(latency_fast)
#   -> VAD 段文本映射 -> 模板 Query 语义对齐(三色)
#
# 浏览器控制台(webapp) 与桌面「响应时延」页共用本模块，避免同一进程里
# PyQt 与 ctranslate2 的 DLL 冲突（本机 3.12 环境验证过：import PyQt 后
# 再加载 ASR 模型会 native crash）。
import os
from dataclasses import dataclass, field

import numpy as np

from core.asr_align import (DEFAULT_MODEL, LANGUAGE_LABELS, backend_desc,
                            engine_available, ensure_model_downloaded,
                            is_model_ready, set_download_callback)
from core.latency_align import TH_LOW, TH_OK, align_rows_to_audio
from core.latency_audio import (decode_to_mono, detect_cal_tone, ffmpeg_exe,
                                load_template, match_template_peaks,
                                refine_segments, rms_envelope, vad_segments)
from core.latency_excel import round_table_rows

ASR_SR = 16000


@dataclass
class AnalyzeArgs:
    media_path: str = ""
    template_path: str = ""
    model_name: str = DEFAULT_MODEL
    language: str = "auto"        # auto/zh/en（ASR 识别语种）
    wake_path: str = ""          # 唤醒词模板音频(可选)
    wake_text: str = ""          # 唤醒词文本(模板缺省时的 ASR 兜底)
    use_cal: bool = True
    gap_ms: int = 150


@dataclass
class AnalyzeResult:
    ok: bool = False
    message: str = ""
    sr: int = 0
    x: object = None
    env_t: object = None
    env_v: object = None
    cal_s: float = 0.0
    cal_score: float = 0.0
    units: list = field(default_factory=list)     # [{index,start_s,end_s,text}]
    wake_occs: list = field(default_factory=list)
    rows: list = field(default_factory=list)      # 模板行（与 results 对齐）
    results: list = field(default_factory=list)   # align_rows_to_audio 输出


def _resample_linear(x, sr_from: int, sr_to: int):
    """线性重采样到目标采样率（供 ASR 16kHz 输入）"""
    if sr_from == sr_to or x is None or x.size == 0:
        return x
    n_out = max(1, int(round(x.size * sr_to / float(sr_from))))
    src = np.arange(n_out, dtype=np.float64) * (sr_from / float(sr_to))
    src = np.clip(src, 0, x.size - 1)
    return np.interp(src, np.arange(x.size, dtype=np.float64),
                     x.astype(np.float64)).astype(np.float32)


def run_analysis(args: AnalyzeArgs, emit=None):
    """执行完整分析，成功返回 AnalyzeResult(ok=True)，失败抛 RuntimeError。

    emit: 可选进度回调 fn(str)（同步调用，调用方负责线程安全）
    """
    result = AnalyzeResult()
    try:
        _impl(args, result, emit)
    except Exception as e:               # noqa: BLE001
        result.ok = False
        result.message = str(e)
        raise
    result.ok = True
    return result


def _impl(args, result, emit):
    def _emit(msg):
        if emit:
            emit(msg)

    if not ffmpeg_exe():
        raise RuntimeError("未找到 ffmpeg，请安装依赖 imageio-ffmpeg")
    if not engine_available():
        raise RuntimeError(
            "未安装 faster-whisper，无法做指令语义定位。\n"
            "请执行: pip install faster-whisper")
    rows = round_table_rows(args.template_path)
    if not rows:
        raise RuntimeError("模板中未解析到任何 Query 行")
    result.rows = rows

    _emit("解码音/视频 44.1kHz ...")
    sr, x = decode_to_mono(args.media_path, 44100)
    x = np.asarray(x, dtype=np.float32)
    result.sr = int(sr)

    if not is_model_ready(args.model_name):
        _emit(f"正在下载 ASR 模型 [{args.model_name}] "
              "(镜像 hf-mirror.com，下载完成后完全离线)...")
        set_download_callback(_emit)
        try:
            ensure_model_downloaded(args.model_name)
        finally:
            set_download_callback(None)

    # 校准音检测（录音开头 1s 1kHz）
    cal_s = 0.0
    cal_score = 0.0
    if args.use_cal:
        hit = detect_cal_tone(x, sr)
        if hit:
            cal_s = float(hit["offset_s"])
            cal_score = float(hit["score"])
            _emit(f"校准音: 检测到 1kHz 到达 {cal_s*1000:.1f}ms "
                  f"(相关 {cal_score:.2f})，将自动扣除")
        else:
            _emit("校准音: 未在开头 4s 内检测到（不扣除，仍可分析）")
    result.cal_s = cal_s
    result.cal_score = cal_score

    gap_s = max(0.06, args.gap_ms / 1000.0)
    _emit(f"VAD 分段 (静音合并 {args.gap_ms}ms) ...")
    segs = vad_segments(x, sr, min_gap_s=gap_s, merge_gap_s=gap_s)
    refined = refine_segments(x, sr, segs)
    if not refined:
        raise RuntimeError("未检测到任何语音段，请检查录音内容/底噪")
    env_t, rms = rms_envelope(x, sr, win_s=0.020, hop_s=0.002)
    top = float(np.percentile(rms, 99.5)) or 1.0
    result.env_t = env_t
    result.env_v = np.clip(rms / top, 0.0, 1.0)

    x16 = _resample_linear(x, sr, ASR_SR)

    wake_occs = []
    if args.wake_path and os.path.exists(args.wake_path):
        templ = load_template(args.wake_path, sr)
        if templ is not None and templ.size > 0:
            wake_occs = match_template_peaks(x, sr, templ)
            _emit(f"唤醒词模板互相关: {len(wake_occs)} 处命中")
    result.wake_occs = wake_occs

    # 整轨一次 ASR：只加载/编码一次模型（v1.6.5）
    from core.latency_fast import transcribe_full, units_from_segments
    lang_txt = LANGUAGE_LABELS.get(args.language, args.language)
    _emit(f"ASR 整轨识别中 (模型 {args.model_name}, 语种 {lang_txt}, "
          f"{backend_desc()}) ...")
    full_segs = transcribe_full(x16, model_name=args.model_name,
                                language=args.language, emit=_emit)
    units = units_from_segments(refined, full_segs)
    with_text = sum(1 for u in units if u["text"])
    _emit(f"对齐切分完成：{len(units)} 段中 {with_text} 段含识别文本")
    result.units = units

    _emit("模板 Query 语义对齐 ...")
    results = align_rows_to_audio(
        units, wake_occs, rows, cal_s=cal_s,
        wake_text=args.wake_text.strip() if args.wake_text else "",
        th_ok=TH_OK, th_low=TH_LOW)
    result.results = results
    ok_n = sum(1 for r in results if r["status"] == "ok")
    warn_n = sum(1 for r in results if r["status"] == "warn")
    miss_n = sum(1 for r in results if r["status"] == "miss")
    _emit(f"对齐完成: 已确认 {ok_n} / 待确认 {warn_n} / "
          f"未匹配 {miss_n} 行")
