# core/latency_model.py
# v1.6 音频端到端耗时分析 —— 语音段 / 轮次数据模型与 A/B 计算（纯逻辑，无 Qt）
#
# 结构约定（与用户确认一致）:
#   每一轮固定四段: 唤醒词(0) -> NOMI应答TTS(1) -> 真人指令(2) -> NOMI执行TTS(3)
#   A = 唤醒段 offset -> 应答段 onset   （唤醒耗时，填「唤醒TTS时延」表）
#   B = 指令段 offset -> 执行段 onset   （端到端耗时，填「端到端TTS时延」表）
# 单位统一毫秒(ms)；段内端点使用秒内部精度，A/B 结果按 ms 取整。
from dataclasses import dataclass, field
from typing import List, Optional

from core.latency_audio import ms

ROLE_NAMES = ["唤醒词", "应答TTS", "真人指令", "执行TTS"]


@dataclass
class Segment:
    """一个语音活动段"""
    index: int = 0                  # 在总列表中的序号(1 起)
    start_s: float = 0.0            # onset(秒)
    end_s: float = 0.0              # offset(秒)
    role: int = -1                  # 0唤醒/1应答/2指令/3执行TTS；-1=未分配/忽略
    ignored: bool = False           # 用户标为噪声/无效段（不参与成轮）

    @property
    def dur_s(self) -> float:
        return max(0.0, self.end_s - self.start_s)


@dataclass
class Round:
    """一轮交互 = 四段（唤醒/应答/指令/执行），计算 A/B 耗时"""
    order: int = 0                  # 轮次序号(1 起，Excel 对号用)
    segs: List[Segment] = field(default_factory=list)  # 长度4，按角色顺序

    @property
    def wake(self) -> Optional[Segment]:
        return self.segs[0] if len(self.segs) > 0 else None

    @property
    def answer(self) -> Optional[Segment]:
        return self.segs[1] if len(self.segs) > 1 else None

    @property
    def command(self) -> Optional[Segment]:
        return self.segs[2] if len(self.segs) > 2 else None

    @property
    def reply(self) -> Optional[Segment]:
        return self.segs[3] if len(self.segs) > 3 else None

    @property
    def a_ms(self) -> Optional[int]:
        """唤醒耗时 A = 唤醒段结束 -> 应答段开始"""
        w, a = self.wake, self.answer
        if w is None or a is None:
            return None
        return ms(a.start_s - w.end_s)

    @property
    def b_ms(self) -> Optional[int]:
        """端到端耗时 B = 真人指令结束 -> 执行TTS开始"""
        c, r = self.command, self.reply
        if c is None or r is None:
            return None
        return ms(r.start_s - c.end_s)

    @property
    def complete(self) -> bool:
        return len(self.segs) == 4 and all(
            s is not None and not s.ignored for s in self.segs)


def segments_to_rounds(segs: List[Segment], start_round: int = 1,
                       four_fixed: bool = True) -> List[Round]:
    """把语音段按顺序组成轮次。

    four_fixed=True : 忽略段剔除后每 4 段为一轮（默认四段固定模型）。
    返回的轮次仅包含凑满 4 段的组；不足 4 段的尾部不生成轮。
    """
    active = [s for s in segs if not s.ignored]
    rounds: List[Round] = []
    if four_fixed:
        for i in range(0, len(active) - 3, 4):
            group = active[i:i + 4]
            for k, s in enumerate(group):
                s.role = k
            rounds.append(Round(order=start_round + len(rounds), segs=group))
    return rounds


def compute_result_values(rounds: List[Round]) -> List[dict]:
    """按轮输出 {'a_ms':..,'b_ms':..}；不完整轮 -> None(不填 Excel)"""
    out = []
    for r in rounds:
        if r.complete:
            out.append({"a_ms": r.a_ms, "b_ms": r.b_ms})
        else:
            out.append({"a_ms": None, "b_ms": None})
    return out
