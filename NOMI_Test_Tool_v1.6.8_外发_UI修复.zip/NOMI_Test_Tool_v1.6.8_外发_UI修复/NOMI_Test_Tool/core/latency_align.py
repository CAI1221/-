# core/latency_align.py
# v1.6.2 响应时延分析 —— 模板 Query 语义对齐 + A/B 时延计算（纯逻辑，无 Qt）
#
# 思路（与需求最终确认一致）:
#   - 人声指令不固定，不能用模板互相关；用「ASR 文本粗定位 + VAD 能量端点精修」。
#   - 唤醒词是电脑播放的固定音频，用「唤醒词模板互相关」精确定位(毫秒级)。
#   - 校准音(1kHz, 录音开头)互相关检测 -> 扣除空气传播固定偏置。
#   - 按模板 Query 行逐条输出 A/B，三色状态:
#       ok   = 已确认(绿)  ASR 匹配清晰且时序合理
#       warn = 待确认(橙)  匹配模糊 / 时延异常 / 缺少回复
#       miss = 未匹配(红)  没有找到对应语音段
# 修正方式(UI 层): 待确认/未匹配行可下拉选择正确的语音段或手动改数值。
from __future__ import annotations

from core.latency_model import ms as _ms_round

# 匹配用归一化: 去空白与常见中英文标点（whisper 标点不影响匹配）
# 用字符过滤代替正则字符类，避免转义告警与误匹配
_PUNCT_CHARS = frozenset(
    " \t\r\n，。！？、；：""''（）《》〈〉【】〔〕…—·,.!?;:'\"`()[]{}<>|\\/_-")
TH_OK = 0.72     # 文本得分 >= -> 绿(已确认)
TH_LOW = 0.48    # 文本得分 >= -> 橙(待确认)，否则视为无关语音


def norm_text(s):
    if not s:
        return ""
    return "".join(ch for ch in str(s).lower() if ch not in _PUNCT_CHARS)


def match_score(query: str, text: str) -> float:
    """模板 query 与 ASR 文本的相似分 [0,1]。

    包含关系(长文本内含 query / query 内含整句)与字符覆盖率都会加分，
    以容忍 whisper 的错误与前后缀。
    """
    q = norm_text(query)
    t = norm_text(text)
    if not q:
        return 0.0
    if q == t:
        return 1.0
    if len(q) >= 2 and q in t:
        return 0.90 + min(0.10, len(q) / max(1.0, len(t)) * 0.2)
    if len(t) >= 2 and t in q:
        return 0.88
    from difflib import SequenceMatcher
    ratio = SequenceMatcher(None, q, t).ratio()
    hits = sum(1 for ch in q if ch in t)
    cov = hits / len(q)
    return max(ratio, cov * 0.85)


def _cal_ms(cal_s) -> int:
    return _ms_round(cal_s) if cal_s else 0


def find_nearest_wake_before(wake_occs, cmd_start_s, horizon_s=20.0):
    """取 cmd_start 之前最近的一次唤醒出现（含重叠容差 0.05s）"""
    best = None
    for w in wake_occs or []:
        if w["end_s"] <= cmd_start_s + 0.05 and cmd_start_s - w["end_s"] <= horizon_s:
            if best is None or w["end_s"] > best["end_s"]:
                best = w
    return best


def first_unit_after(units, t_s):
    """返回时间上完全位于 t_s 之后的第一个语音段下标（不含 = 回复/应答候选）"""
    for k, u in enumerate(units or []):
        if u["start_s"] > t_s + 0.005:
            return k
    return None


def build_results_rows(rows):
    """初始化长度=模板行数的结果列表（全部 miss）"""
    out = []
    for info in rows:
        out.append({
            "info": dict(info), "status": "miss",
            "a_ms": None, "b_ms": None,
            "ratio": 0.0, "note": "未匹配到语音段",
            "cmd_unit_ids": [], "cmd_start_s": None, "cmd_end_s": None,
            "reply_unit_id": None, "reply_start_s": None,
            "wake_occ_idx": None, "wake_end_s": None,
            "answer_unit_id": None, "answer_start_s": None,
            "cal_ms": 0,
        })
    return out


def align_rows_to_audio(units, wake_occs, rows, cal_s: float = 0.0,
                        wake_text: str = "", th_ok: float = TH_OK,
                        th_low: float = TH_LOW,
                        max_merge_gap_s: float = 0.9,
                        max_merge_units: int = 3):
    """把模板 Query 行与语音段(ASR 标注)语义对齐，计算每行 A/B 与状态。

    参数:
      units      [{'index','start_s','end_s','text'}, ...] 升序（VAD 精修后的段）
      wake_occs  [{'start_s','end_s','score'}, ...] 唤醒词模板互相关命中
      rows       [{'row','domain','query'}, ...] 模板 Query 顺序
      cal_s      校准音互相关测得的空气传播延迟(秒)，计算时扣除
      wake_text  唤醒词文本（wake_occs 为空时的文本兜底）
    返回: 长度=len(rows) 的结果列表（结构见 build_results_rows）。
    """
    n_rows = len(rows)
    results = build_results_rows(rows)
    if not rows or not units:
        return results
    cal = _cal_ms(cal_s)

    # 文本兜底: 无模板命中时，把 ASR 文本与唤醒词高度相似的段视为唤醒
    woccs = list(wake_occs or [])
    wake_text = (wake_text or "").strip()
    for u in units:
        if not woccs and wake_text and match_score(wake_text, u["text"]) >= th_ok:
            woccs.append({"start_s": u["start_s"], "end_s": u["end_s"],
                          "score": 1.0, "unit_id": u["index"]})

    n = len(units)
    cursor = 0          # 下一个待匹配模板行下标
    i = 0
    while i < n and cursor < n_rows:
        u0 = units[i]
        if not (u0.get("text") or "").strip():
            i += 1
            continue

        def _span_allowed(j_end, target):
            """合并到 j_end 时，不允许吞并其中能“独立成指令”的中间段：
            若某段自身已可强匹配目标行(>=th_ok)，应等扫描到该段时单独成行，
            否则会把 唤醒+应答+指令 误并成一个指令（先于真正指令触发提交）。"""
            if j_end <= i:
                return True
            q = rows[target]["query"]
            for k in range(i + 1, j_end + 1):
                if match_score(q, units[k].get("text") or "") >= th_ok:
                    return False
            return True

        # 候选指令段 = 从 i 开始，允许合并后续紧邻的 1..max_merge_units 段
        best = None          # (score, j_end, text, target_row)
        cum_text = ""
        for j in range(i, min(n, i + max_merge_units)):
            uj = units[j]
            if j > i and (uj["start_s"] - units[j - 1]["end_s"]) > max_merge_gap_s:
                break
            cum_text = (cum_text + " " + (uj.get("text") or "")).strip()
            if not cum_text:
                continue
            for target in (cursor, cursor + 1):
                if target >= n_rows:
                    continue
                if not _span_allowed(j, target):
                    continue
                sc = match_score(rows[target]["query"], cum_text)
                if best is None or sc > best[0]:
                    best = (sc, j, cum_text, target)
        if best is None or best[0] < th_low:
            i += 1          # 无关语音(唤醒/应答TTS/噪声等)，跳过
            continue

        score, j_end, _text, target = best
        cmd_start = units[i]["start_s"]
        cmd_end = units[j_end]["end_s"]
        res = results[target]
        res["status"] = "warn" if score < th_ok else "ok"
        res["ratio"] = round(score, 3)
        res["cmd_unit_ids"] = [units[k]["index"] for k in range(i, j_end + 1)]
        res["cmd_start_s"] = cmd_start
        res["cmd_end_s"] = cmd_end
        res["cal_ms"] = cal
        res["note"] = "已匹配"

        # ---- B: 指令尾音 -> 下一个语音段起点(执行TTS 首帧) ----
        k = first_unit_after(units, cmd_end)
        if k is not None:
            reply = units[k]
            res["reply_unit_id"] = reply["index"]
            res["reply_start_s"] = reply["start_s"]
            b_raw = _ms_round(reply["start_s"] - cmd_end) - cal
            res["b_ms"] = b_raw
            if b_raw < -150 or b_raw > 12000:
                res["status"] = "warn"
                res["note"] = f"匹配但时延异常 B={b_raw}ms"
            elif score < th_ok:
                res["note"] = "匹配较模糊，请确认指令段"
        else:
            res["b_ms"] = None
            res["status"] = "warn"
            res["note"] = "未找到指令后的 TTS 回复段"

        # ---- A: 唤醒词尾音 -> 应答TTS首帧（若本段录音有唤醒）----
        wake = find_nearest_wake_before(woccs, cmd_start)
        if wake is not None:
            ans_k = first_unit_after(units, wake["end_s"])
            ans = None
            if ans_k is not None and units[ans_k]["start_s"] < cmd_start:
                ans = units[ans_k]
            if ans is not None:
                res["wake_occ_idx"] = woccs.index(wake)
                res["wake_end_s"] = wake["end_s"]
                res["answer_unit_id"] = ans["index"]
                res["answer_start_s"] = ans["start_s"]
                res["a_ms"] = _ms_round(ans["start_s"] - wake["end_s"]) - cal
            else:
                res["note"] = res["note"] + "；唤醒后未找到应答段"

        cursor = target + 1
        # 跳过该行的回复段（防 TTS 复述 query 造成串行错位）
        if k is not None:
            i = k + 1
        else:
            i = j_end + 1

    # 汇总提示
    for res in results:
        if res["status"] == "miss":
            res["note"] = "未匹配到语音段（可点手动定位补填）"
    return results
