# core/log_test_engine.py
# 日志测试引擎：模块调度 + 语音外放 + scrcpy 录屏 + 人工模块暂停 + 结束拉取 logd/slog
#
# 流程:
#   预检(ADB/语音音频/scrcpy) -> [清空车机日志] -> 逐模块执行:
#     人工模块 -> 暂停等待用户点击「继续」
#     自动模块 -> ScreenController 执行控屏步骤（失败记日志不中断）
#     语音模块 -> 电脑外放 唤醒词 + Query 循环（AudioPlayer 子线程）
#     每模块独立 scrcpy 录屏(ICS录像/模块名_时间.mkv) + 倒计时
#   -> 全部结束: 拉取安卓 logd + QNX slog -> 汇总
#
# 试跑模式(trial): 每模块 10 秒，不清日志/不录屏/不拉日志，仅验证控屏步骤。
import json
import os
import signal
import subprocess
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

from PyQt5.QtCore import QThread, pyqtSignal

from .audio_player import AudioPlayer
from .constants import (
    DIR_AUDIO, DIR_LOGD, DIR_MODULES, DIR_SLOG, DIR_VIDEO,
    LOG_MODULE_GAP, LOG_TEST_AUDIO_PREFIX, NOMI_LOG_TEST_QUERIES,
)
from .log_manager import (clear_android_logs, clear_qnx_slog, pull_logd,
                          pull_slog)
from .screen_controller import ScreenController
from .ssh_executor import SSHClientWrapper

AUDIO_EXTS = (".wav", ".mp3")


def find_audio_file(audio_dir: str, base_name: str) -> Optional[str]:
    """查找音频文件（.wav/.mp3 非空）"""
    for ext in AUDIO_EXTS:
        p = os.path.join(audio_dir, base_name + ext)
        try:
            if os.path.exists(p) and os.path.getsize(p) > 0:
                return p
        except OSError:
            continue
    return None


def load_module_config(tool_dir: str, platform: str) -> Optional[Dict]:
    """加载平台模块配置 JSON（modules/平台名.json），失败返回 None"""
    path = os.path.join(tool_dir, DIR_MODULES, f"{platform}.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        if not isinstance(cfg.get("modules"), list):
            return None
        return cfg
    except Exception:
        return None


@dataclass
class LogTestConfig:
    """一次日志测试的配置"""
    platform: str                  # NT3.0-NIO / NT2.5-NIO / NT3.0-ALPS
    wakeup_word: str               # 唤醒词（决定音频文件名）
    modules: List[Dict] = field(default_factory=list)  # 选中的模块定义
    output_root: str = ""          # 输出根目录（audio 在这）
    session_dir: str = ""          # 本轮总文件夹（产物在这）
    module_gap: int = LOG_MODULE_GAP
    record_video: bool = True      # scrcpy 录屏
    scrcpy_path: str = ""          # scrcpy 完整路径（UI 探测后传入）
    clear_logs_before: bool = True # 开始前清空车机日志
    pull_logd_after: bool = True   # 结束后拉取安卓 logd
    pull_slog_after: bool = True   # 结束后拉取 QNX slog
    voice_enabled: bool = True     # 语音模块 TTS 外放
    trial_run: bool = False        # 试跑模式
    ssh_host: str = ""
    ssh_user: str = "root"
    ssh_password: str = ""

    @property
    def trial_seconds(self) -> int:
        from .constants import LOG_TRIAL_SECONDS
        return LOG_TRIAL_SECONDS


class LogTestEngine(QThread):
    """日志测试执行引擎（独立线程）"""

    log_signal = pyqtSignal(str)             # 主日志
    progress_signal = pyqtSignal(int, int)   # 当前模块序号(1-based), 总数
    countdown_signal = pyqtSignal(int)       # 当前模块剩余秒
    module_signal = pyqtSignal(str)          # 当前模块名（"" = 结束）
    pause_signal = pyqtSignal(str)           # 人工模块暂停（模块名）
    finished_signal = pyqtSignal(bool, str)  # 成功, 汇总消息

    def __init__(self, config: LogTestConfig):
        super().__init__()
        self.config = config
        self._stop_flag = False
        self._resume_event = threading.Event()
        self._scrcpy_proc: Optional[subprocess.Popen] = None
        self._controller = ScreenController(log_cb=self._log)
        self._tts_player: Optional[AudioPlayer] = None
        self._tts_thread: Optional[threading.Thread] = None
        self._module_failures: List[str] = []   # 模块级问题汇总
        self._video_files: List[str] = []

        # 引擎日志文件
        try:
            os.makedirs(config.session_dir, exist_ok=True)
        except Exception:
            pass
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._log_file = os.path.join(config.session_dir, f"日志测试_{ts}.log")
        self._log_lock = threading.Lock()
        try:
            with open(self._log_file, "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
                        f"日志测试引擎初始化，产物目录: {config.session_dir}\n")
        except Exception:
            pass

    # ==================== 日志 ====================
    def _log(self, msg: str):
        line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
        self.log_signal.emit(line)
        with self._log_lock:
            try:
                with open(self._log_file, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
            except Exception:
                pass

    # ==================== 控制 ====================
    def stop(self):
        """用户请求停止（同时唤醒人工模块等待）"""
        self._stop_flag = True
        self._resume_event.set()
        self._log("收到停止请求...")

    def resume(self):
        """人工模块完成，用户点击「继续」"""
        self._resume_event.set()

    def _sleep(self, seconds: float) -> bool:
        """可中断等待，返回 False = 被停止"""
        end = time.time() + seconds
        while time.time() < end:
            if self._stop_flag:
                return False
            time.sleep(min(0.5, max(0.05, end - time.time())))
        return not self._stop_flag

    # ==================== 主流程 ====================
    def run(self):
        try:
            cfg = self.config
            self._log("=" * 60)
            self._log(f"日志测试开始 | 平台: {cfg.platform}"
                      + (" | 试跑模式(10s/模块, 不采集日志)" if cfg.trial_run else ""))
            self._log(f"总文件夹: {cfg.session_dir}")
            self._log(f"模块: {[m.get('name', '?') for m in cfg.modules]}")

            # ---------- 预检 ----------
            problems = self._precheck()
            if problems:
                for p in problems:
                    self._log(f"[预检失败] {p}")
                self.finished_signal.emit(
                    False, "预检未通过，测试未开始:\n" + "\n".join(problems))
                return
            self._log("预检通过")

            # ---------- 清空车机日志 ----------
            if cfg.clear_logs_before and not cfg.trial_run:
                self._clear_device_logs()

            # ---------- 逐模块执行 ----------
            total = len(cfg.modules)
            for i, mod in enumerate(cfg.modules):
                if self._stop_flag:
                    break
                name = str(mod.get("name", f"模块{i + 1}"))
                seconds = int(mod.get("seconds", 60) or 60)
                if cfg.trial_run:
                    seconds = cfg.trial_seconds
                self.progress_signal.emit(i + 1, total)
                self.module_signal.emit(name)
                self._log("")
                self._log("=" * 60)
                self._log(f"[{i + 1}/{total}] 模块: {name} "
                          f"({'人工' if mod.get('manual') else '自动'}，{seconds}s)")

                try:
                    self._run_module(mod, name, seconds)
                except Exception:
                    self._log(f"模块执行异常:\n{traceback.format_exc()}")
                    self._module_failures.append(f"{name}: 执行异常")

                if i < total - 1 and not self._stop_flag:
                    self._log(f"模块间隔 {cfg.module_gap} 秒...")
                    self._sleep(cfg.module_gap)

            # ---------- 结束收尾 ----------
            self.module_signal.emit("")
            self._stop_tts()
            self._stop_scrcpy()

            if cfg.trial_run:
                self._log("试跑模式: 跳过日志拉取")
            elif self._stop_flag:
                # 用户手动停止: 本轮数据不要了，不拉 logd/slog，避免无谓等待
                self._log("用户手动停止: 跳过安卓 logd / QNX slog 拉取")
            else:
                self._pull_logs()

            # ---------- 汇总 ----------
            self._log("=" * 60)
            if self._stop_flag:
                self._log("用户手动停止，日志测试提前结束")
                self.finished_signal.emit(False, "用户手动停止"
                                          + self._summary_tail())
            else:
                self._log("全部模块执行完成")
                self.finished_signal.emit(True, "日志测试完成" + self._summary_tail())
        except Exception as e:
            self._log(f"引擎异常:\n{traceback.format_exc()}")
            try:
                self._stop_scrcpy()
                self._stop_tts()
            except Exception:
                pass
            self.finished_signal.emit(False, f"引擎异常: {e}")
        finally:
            try:
                self._stop_scrcpy()
            except Exception:
                pass

    def _summary_tail(self) -> str:
        """结束汇总（产物统计 + 问题列表）"""
        lines = ["", f"产物目录: {self.config.session_dir}"]
        for d, desc in [(DIR_VIDEO, "ICS 录屏"), (DIR_LOGD, "安卓 logd"),
                        (DIR_SLOG, "QNX slog")]:
            path = os.path.join(self.config.session_dir, d)
            try:
                # 递归计数（logd/slog 可能含子目录文件）
                count = sum(len(fs) for _r, _ds, fs in os.walk(path))
            except Exception:
                count = 0
            lines.append(f"  {desc}: {count} 个文件")
        if self._module_failures:
            lines.append("[注意] 有问题的模块: " + "；".join(self._module_failures))
        return "\n" + "\n".join(lines)

    # ==================== 预检 ====================
    def _precheck(self) -> List[str]:
        problems: List[str] = []
        cfg = self.config

        # 1. ADB（控屏/录屏/logd 都依赖）
        ok, out = self._controller._adb_shell("echo ok", timeout=8)
        if not ok or "ok" not in out:
            problems.append(f"ADB 未连接车机安卓侧: {out[:120]}\n"
                            "  请先到「连接设备」页连接 ADB")
            return problems
        self._log("ADB 连接正常")

        # 2. 屏幕分辨率（控屏比例坐标依赖）
        w, h = self._controller.get_screen_size(refresh=True)
        if not w or not h:
            problems.append("无法获取车机屏幕分辨率（wm size 失败），控屏不可用")
        else:
            self._log(f"车机屏幕分辨率: {w}x{h}")

        # 3. 语音音频（语音模块 + 未试跑时）
        voice_mods = [m for m in cfg.modules if m.get("voice")]
        if cfg.voice_enabled and voice_mods and not cfg.trial_run:
            audio_dir = os.path.join(cfg.output_root, DIR_AUDIO)
            missing = []
            if find_audio_file(audio_dir, cfg.wakeup_word) is None:
                missing.append(f"唤醒词: {cfg.wakeup_word}.wav/.mp3")
            for mod in voice_mods:
                for q in self._module_queries(mod):
                    if find_audio_file(audio_dir,
                                       f"{LOG_TEST_AUDIO_PREFIX}{q}") is None:
                        missing.append(f"{LOG_TEST_AUDIO_PREFIX}{q}.wav/.mp3")
            if missing:
                problems.append(
                    f"语音音频缺失 {len(missing)} 个（目录: {audio_dir}）:\n  "
                    + "\n  ".join(missing[:10])
                    + ("\n  ..." if len(missing) > 10 else "")
                    + "\n  请回到本页点击「生成测试语音 (Edge TTS)」")

        # 4. scrcpy（勾选录屏时）
        if cfg.record_video and not cfg.trial_run:
            if not cfg.scrcpy_path or not os.path.exists(cfg.scrcpy_path):
                problems.append(
                    "已勾选 ICS 录屏，但未找到可用的 scrcpy，\n"
                    "  请安装 scrcpy 或在本页手动选择 scrcpy.exe")
            else:
                self._log(f"scrcpy: {cfg.scrcpy_path}")
        return problems

    @staticmethod
    def _module_queries(mod: Dict) -> List[str]:
        """模块的语音 Query 列表（未定义则用默认 Nomi 样例）"""
        queries = mod.get("queries")
        if isinstance(queries, list) and queries:
            return [str(q) for q in queries if str(q).strip()]
        return list(NOMI_LOG_TEST_QUERIES)

    # ==================== 清空车机日志 ====================
    def _clear_device_logs(self):
        self._log("清空车机日志（安卓 logcat/logd + QNX slog）...")
        ok, msg = clear_android_logs(log_cb=self._log)
        if not ok:
            self._log(f"[警告] 安卓日志清空失败: {msg[:150]}（不影响继续）")
        if self.config.ssh_host:
            ssh = SSHClientWrapper()
            ssh.configure(self.config.ssh_host, self.config.ssh_user,
                          self.config.ssh_password)
            try:
                ssh.connect(timeout=10)
                ok, msg = clear_qnx_slog(ssh, log_cb=self._log)
                if not ok:
                    self._log(f"[警告] QNX slog 清空失败: {msg[:150]}（不影响继续）")
            except Exception as e:
                self._log(f"[警告] QNX SSH 连接失败，跳过 slog 清空: {e}")
            finally:
                try:
                    ssh.close()
                except Exception:
                    pass
        else:
            self._log("未配置 QNX SSH，跳过 slog 清空")

    # ==================== 单模块执行 ====================
    def _run_module(self, mod: Dict, name: str, seconds: int):
        cfg = self.config

        # ---- 人工模块: 暂停等待用户操作 ----
        if mod.get("manual"):
            self._log(f"[人工模块] 请在车机上手动操作 [{name}]...")
            self._resume_event.clear()
            self.pause_signal.emit(name)
            # 等待用户点击「继续」或停止
            while not self._resume_event.wait(0.5):
                if self._stop_flag:
                    return
            self._resume_event.clear()
            if self._stop_flag:
                return
            self._log("用户已确认，开始采集本模块日志...")
        else:
            # ---- 自动模块: 执行控屏步骤 ----
            steps = mod.get("steps") or []
            if steps:
                self._log(f"执行控屏步骤（{len(steps)} 步）...")
                failures = self._controller.run_steps(
                    steps, apps=mod.get("apps") or self._apps_of_platform())
                if failures:
                    self._log(f"[控屏警告] 失败步骤: {'; '.join(failures)}")
                    self._module_failures.append(f"{name}: {len(failures)} 步失败")
                else:
                    self._log("控屏步骤全部执行成功")

        # ---- 模块录屏 ----
        if cfg.record_video and not cfg.trial_run:
            video = self._start_scrcpy(name)
        else:
            video = None

        # ---- 语音外放 ----
        if mod.get("voice") and cfg.voice_enabled and not self._stop_flag:
            self._start_voice(mod, name)

        # ---- 倒计时采集 ----
        self._log(f"采集 {seconds} 秒...")
        for remaining in range(seconds, 0, -1):
            if self._stop_flag:
                break
            self.countdown_signal.emit(remaining)
            if not self._sleep(1):
                break

        # ---- 收尾 ----
        self._stop_tts()
        if video:
            self._stop_scrcpy()
        self.countdown_signal.emit(0)
        if not self._stop_flag:
            self._log(f"模块 [{name}] 完成")

    def _apps_of_platform(self) -> Dict:
        """平台 apps 配置（component 映射），从模块配置 JSON 的全局段取"""
        # modules 配置中的 apps 定义在平台 JSON 顶层；由 UI 加载时并入每个模块?
        # 简化: 引擎不重复读文件 —— UI 已把 apps 合入 config.modules[0] 之外的
        # self._apps（构造后由 UI 调 set_apps 注入）
        return getattr(self, "_apps", {}) or {}

    def set_apps(self, apps: Dict):
        """UI 加载平台配置后注入 apps 映射（app名 -> {component: ...}）"""
        self._apps = apps or {}

    # ==================== 语音外放 ====================
    def _start_voice(self, mod: Dict, name: str):
        """启动语音循环线程: 唤醒词 -> Query 循环，直到模块结束/停止"""
        cfg = self.config
        audio_dir = os.path.join(cfg.output_root, DIR_AUDIO)
        wake = find_audio_file(audio_dir, cfg.wakeup_word)
        if not wake:
            self._log(f"[语音警告] 唤醒词音频缺失: {cfg.wakeup_word}.wav/.mp3，跳过语音")
            return
        queries = self._module_queries(mod)

        def _voice_worker():
            try:
                player = AudioPlayer(log_cb=self._log)
                self._tts_player = player
                self._log(f"语音外放启动: 唤醒词 [{cfg.wakeup_word}] + "
                          f"{len(queries)} 条 Query")
                player.play(wake)
                time.sleep(2)
                while not self._stop_flag:
                    for q in queries:
                        if self._stop_flag:
                            return
                        qfile = find_audio_file(
                            audio_dir, f"{LOG_TEST_AUDIO_PREFIX}{q}")
                        if qfile:
                            self._log(f"播放: {q}")
                            player.play(qfile)
                            time.sleep(2)   # 等待车机应答
                        else:
                            self._log(f"[语音警告] 音频缺失: "
                                      f"{LOG_TEST_AUDIO_PREFIX}{q}.wav/.mp3")
                        time.sleep(1)
            except Exception as e:
                self._log(f"[语音错误] 语音线程异常: {e}")

        t = threading.Thread(target=_voice_worker, daemon=True)
        self._tts_thread = t
        t.start()

    def _stop_tts(self):
        if self._tts_player:
            try:
                self._tts_player.stop()
            except Exception:
                pass
        if self._tts_thread and self._tts_thread.is_alive():
            self._tts_thread.join(timeout=3)
        self._tts_player = None
        self._tts_thread = None

    # ==================== scrcpy 录屏 ====================
    def _start_scrcpy(self, module_name: str) -> Optional[str]:
        """启动 scrcpy 后台录屏（--no-playback），返回视频文件路径

        用 CREATE_NEW_PROCESS_GROUP 创建，停止时发 CTRL_C_EVENT 让 scrcpy
        正常收尾（录像文件完整落盘）；失败自动降级加 --no-audio 重试。
        """
        cfg = self.config
        video_dir = os.path.join(cfg.session_dir, DIR_VIDEO)
        os.makedirs(video_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe = "".join(c for c in module_name if c not in '\\/:*?"<>|')
        video_path = os.path.join(video_dir, f"{safe}_{ts}.mkv")

        def _spawn(extra_args):
            cmd = [cfg.scrcpy_path, "--no-playback",
                   "--record", video_path] + extra_args
            return subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)

        try:
            proc = _spawn([])
        except FileNotFoundError:
            self._log(f"[录屏错误] scrcpy 不存在: {cfg.scrcpy_path}")
            self._module_failures.append(f"{module_name}: 录屏启动失败")
            return None
        except Exception as e:
            self._log(f"[录屏错误] 启动异常: {e}")
            self._module_failures.append(f"{module_name}: 录屏启动失败")
            return None

        # 等 2 秒确认进程存活；音频不支持等场景 scrcpy 会立刻退出
        time.sleep(2)
        if proc.poll() is not None:
            out = ""
            try:
                out = (proc.stdout.read() or "")[:200]
            except Exception:
                pass
            self._log(f"[录屏警告] scrcpy 退出({out.strip()})，加 --no-audio 重试...")
            try:
                proc = _spawn(["--no-audio"])
                time.sleep(2)
                if proc.poll() is not None:
                    out = ""
                    try:
                        out = (proc.stdout.read() or "")[:200]
                    except Exception:
                        pass
                    self._log(f"[录屏错误] --no-audio 重试仍失败: {out.strip()}")
                    self._module_failures.append(f"{module_name}: 录屏启动失败")
                    return None
            except Exception as e:
                self._log(f"[录屏错误] 重试异常: {e}")
                self._module_failures.append(f"{module_name}: 录屏启动失败")
                return None

        self._scrcpy_proc = proc
        self._log(f"ICS 录屏已启动 -> {DIR_VIDEO}/{os.path.basename(video_path)}")
        return video_path

    def _stop_scrcpy(self):
        """停止 scrcpy: 优先 CTRL_C_EVENT（正常收尾），兜底 terminate"""
        proc = self._scrcpy_proc
        if proc is None:
            return
        self._scrcpy_proc = None
        if proc.poll() is not None:
            return
        video_path = ""
        try:
            video_path = proc.args[proc.args.index("--record") + 1]
        except Exception:
            pass
        try:
            os.kill(proc.pid, signal.CTRL_C_EVENT)
        except Exception:
            try:
                proc.terminate()
            except Exception:
                pass
        try:
            proc.wait(timeout=8)
        except Exception:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                pass
        # 校验视频文件
        if video_path:
            try:
                if os.path.exists(video_path) and os.path.getsize(video_path) > 0:
                    size_kb = os.path.getsize(video_path) // 1024
                    self._log(f"ICS 录屏已停止 ({size_kb} KB): "
                              f"{os.path.basename(video_path)}")
                    self._video_files.append(video_path)
                else:
                    self._log(f"[录屏警告] 视频文件缺失或为空: {video_path}")
            except Exception:
                pass

    # ==================== 结束拉取日志 ====================
    def _pull_logs(self):
        cfg = self.config
        # 1. 安卓 logd（pull_logd 内部落在 <会话目录>/logd/）
        if cfg.pull_logd_after:
            self._log("拉取安卓 logd...")
            ok, msg = pull_logd(cfg.session_dir, log_cb=self._log)
            if not ok:
                self._log(f"[logd警告] {msg[:200]}")
                self._module_failures.append("logd 拉取: " + msg[:60])
        else:
            self._log("已取消勾选拉取 logd")

        # 2. QNX slog（整目录 scp 拉取到 <会话目录>/slog/）
        if cfg.pull_slog_after:
            if not cfg.ssh_host:
                self._log("[slog警告] 未配置 QNX SSH，跳过 slog 拉取")
            else:
                self._log("拉取 QNX slog（整目录）...")
                ssh = SSHClientWrapper()
                ssh.configure(cfg.ssh_host, cfg.ssh_user, cfg.ssh_password)
                try:
                    ssh.connect(timeout=10)
                    ok, msg = pull_slog(ssh, cfg.session_dir,
                                        log_cb=self._log)
                    if not ok:
                        self._log(f"[slog警告] {msg[:200]}")
                        self._module_failures.append("slog 拉取: " + msg[:60])
                except Exception as e:
                    self._log(f"[slog警告] SSH 连接失败: {e}")
                    self._module_failures.append("slog 拉取: SSH 失败")
                finally:
                    try:
                        ssh.close()
                    except Exception:
                        pass
        else:
            self._log("已取消勾选拉取 slog")
