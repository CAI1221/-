# core/parsers.py
# QNX 输出纯函数解析器（不依赖 SSH / Qt，便于单元测试）
#   - parse_artifact_version:   nio/version.txt 提取 Artifact 字段（车机长版本）
#   - parse_speech_pids_ps:     /nio/bin 下 ps -A 输出（进程级，干净）
#   - parse_speech_pids_pidin:  pidin 输出（线程级，按 PID 去重）
#   - is_valid_top2_content:    top2 日志头部内容校验
from typing import List, Optional

# top2 输出中不应出现的错误标记（出现即判定冒烟失败）
# 含 "Unable to enter cbreak mode" 类错误: top2 交互模式在无 TTY 会话下
# 无法进入 cbreak 模式（tcsetattr 失败），输出到重定向文件里就只有这行报错
_BAD_OUTPUT_MARKERS = (
    "cannot execute", "not found", "no such file",
    "permission denied", "command not found", "usage:",
    "unable to enter", "cbreak", "inappropriate i/o", "tcsetattr",
)


def parse_artifact_version(version_txt: str) -> Optional[str]:
    """从 nio/version.txt 内容提取 Artifact 字段（车机长版本）

    示例:
        ===========================  Version Information ===========================
        DATE     : Thu Sep 18 21:49:31 UTC 2025
        Artifact : ALPS_VFT_NT3.0_CN_STAGE_daily.Vstage.780_2025.0919.053032
        ...
    返回 "ALPS_VFT_NT3.0_CN_STAGE_daily..."，未找到返回 None。
    兼容 "Artifact : xxx" 与 "Artifact:xxx" 两种写法。
    """
    if not version_txt:
        return None
    for line in version_txt.splitlines():
        s = line.strip()
        if s.startswith("Artifact") and ":" in s:
            val = s.split(":", 1)[1].strip()
            if val:
                return val
    return None


def parse_speech_pids_ps(out: str) -> List[str]:
    """解析 ps -A | grep speech-service 输出（/nio/bin 下 ps，进程级）

    示例行: "2879596 ?        01:07:44 speech-service"
    返回 ['2879596  speech-service', ...]（按 PID+进程名去重）
    非数字开头的行（profile 回显/表头等杂音）直接忽略。
    """
    result: List[str] = []
    seen = set()
    if not out:
        return result
    for line in out.splitlines():
        tokens = line.split()
        if not tokens or not tokens[0].isdigit():
            continue
        pid = tokens[0]
        name = tokens[-1] if len(tokens) >= 2 else "speech-service"
        item = f"{pid}  {name}"
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def parse_speech_pids_pidin(out: str) -> List[str]:
    """解析 pidin | grep speech-service 输出（线程级，需按 PID 去重）

    pidin 每行格式: pid tid name ...
    示例: "  2879596   1 speech-service  ..."
    同一进程的多个线程会重复出现，按 "PID 进程名" 去重后返回。
    """
    result: List[str] = []
    seen = set()
    if not out:
        return result
    for line in out.splitlines():
        tokens = line.split()
        if len(tokens) < 3 or not tokens[0].isdigit():
            continue
        pid = tokens[0]
        name = tokens[2]
        item = f"{pid}  {name}"
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def is_valid_top2_content(head: str, size: int) -> bool:
    """校验 top2 日志是否有效（排除空文件 / shell 报错信息 / 用法提示）

    :param head: 日志文件头部内容（前几百字节）
    :param size: 文件总字节数
    """
    if size < 50 or not head or not head.strip():
        return False
    low = head.lower()
    return not any(m in low for m in _BAD_OUTPUT_MARKERS)
