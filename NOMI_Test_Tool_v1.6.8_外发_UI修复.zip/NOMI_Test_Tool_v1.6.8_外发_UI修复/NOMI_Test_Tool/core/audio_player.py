# core/audio_player.py
# TTS 音频播放控制（电脑扬声器外放 -> 车机麦克风拾音）
# 所有错误通过 log_cb 回调上报到引擎日志，绝不静默失败
import os
import shutil
import tempfile
import time
import uuid

import pygame

from core.tts import file_is_mp3, file_is_wav


class AudioPlayer:
    """音频播放器：使用 pygame 播放音频文件（wav/mp3，按内容识别格式）"""

    def __init__(self, log_cb=None):
        self._log_cb = log_cb
        self._stop_flag = False
        self._mixer_ok = False
        # 当前“假 .wav”(MP3 内容) 复制出的临时 mp3（唯一命名，播完即删）
        self._tmp_file = None
        try:
            # mixer.init 幂等：已初始化则跳过（每场景会新建播放器实例）
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            self._mixer_ok = pygame.mixer.get_init() is not None
            if not self._mixer_ok:
                self._err("音频系统初始化后仍不可用")
        except Exception as e:
            self._err(f"音频系统初始化失败: {e}")

    # ==================== 日志 ====================
    def _log(self, msg: str):
        if self._log_cb:
            try:
                self._log_cb(msg)
            except Exception:
                pass

    def _err(self, msg: str):
        self._log(f"[TTS错误] {msg}")

    # ==================== 工具 ====================
    @staticmethod
    def check_file(path: str) -> bool:
        """文件存在且非空才可播放"""
        try:
            return bool(path) and os.path.exists(path) and os.path.getsize(path) > 0
        except Exception:
            return False

    @staticmethod
    def _unload():
        """卸载当前音乐（释放 SDL 对文件的占用句柄）"""
        try:
            if hasattr(pygame.mixer.music, "unload"):
                pygame.mixer.music.unload()
        except Exception:
            pass

    def _drop_tmp(self):
        """卸载并删除本次“假 wav”复制出的临时 mp3"""
        tmp = self._tmp_file
        self._tmp_file = None
        self._unload()
        if tmp and os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass

    def _music_load(self, file_path: str):
        """按文件内容加载音乐（pygame 按扩展名选解码器）。

        历史版本把 edge-tts 的 MP3 数据写成了 .wav（内容是 MP3、扩展名 wav），
        pygame 会按 WAV 解码并报 "Unknown WAVE format"。这里检测到这种
        “假 .wav”就复制成**唯一命名**的临时 .mp3 再加载；每次都用新文件名
        可避免多个播放器实例共用同一临时文件时被 SDL 句柄占用而报
        Permission denied。真实 WAV / 真 MP3 直接加载。
        """
        self._unload()
        ext = os.path.splitext(file_path)[1].lower()
        if ext == ".wav" and not file_is_wav(file_path) \
                and file_is_mp3(file_path):
            tmp = os.path.join(tempfile.gettempdir(),
                               f"nomi_snd_{uuid.uuid4().hex[:12]}.mp3")
            shutil.copyfile(file_path, tmp)
            self._tmp_file = tmp
            file_path = tmp
        pygame.mixer.music.load(file_path)

    # ==================== 播放 ====================
    def play(self, file_path: str) -> bool:
        """播放单个音频文件（阻塞直到播放完成或被停止），返回是否成功"""
        if not self._mixer_ok:
            self._err("音频系统未就绪，无法播放")
            return False
        if not self.check_file(file_path):
            self._err(f"音频文件不存在或为空: {file_path}")
            return False
        try:
            self._music_load(file_path)
            pygame.mixer.music.play()
        except Exception as e:
            self._err(f"加载/播放失败 {os.path.basename(file_path)}: {e}")
            self._drop_tmp()
            return False
        self._stop_flag = False
        try:
            while pygame.mixer.music.get_busy() and not self._stop_flag:
                time.sleep(0.1)
        except Exception as e:
            self._err(f"播放中断 {os.path.basename(file_path)}: {e}")
            self._drop_tmp()
            return False
        self._drop_tmp()
        return True

    def play_loop(self, file_path: str, interval: float = 2) -> bool:
        """循环播放（唤醒场景，每隔 interval 秒播一次），返回是否成功启动"""
        if not self._mixer_ok:
            self._err("音频系统未就绪，无法播放")
            return False
        if not self.check_file(file_path):
            self._err(f"音频文件不存在或为空: {file_path}")
            return False
        self._stop_flag = False
        while not self._stop_flag:
            try:
                self._music_load(file_path)
                pygame.mixer.music.play()
                start = time.time()
                while pygame.mixer.music.get_busy() and not self._stop_flag:
                    time.sleep(0.1)
                elapsed = time.time() - start
                if elapsed < interval and not self._stop_flag:
                    time.sleep(interval - elapsed)
                self._drop_tmp()   # 每次播完释放句柄/删除临时文件
            except Exception as e:
                self._err(f"循环播放中断 {os.path.basename(file_path)}: {e}")
                self._drop_tmp()
                return False
        return True

    def stop(self):
        """停止播放"""
        self._stop_flag = True
        try:
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
        except Exception:
            pass
        self._drop_tmp()
