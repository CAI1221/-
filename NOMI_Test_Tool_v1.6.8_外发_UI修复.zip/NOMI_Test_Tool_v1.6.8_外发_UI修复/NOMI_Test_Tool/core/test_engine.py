# core/test_engine.py
# 测试引擎：预检 -> 场景调度 -> 采集控制 -> QNX top2 启停/拉取/校验
#
# 预检（任何一项失败都不会开始跑场景，直接报告用户）:
#   1. SSH 连接（重试 3 次）
#   2. ADB 连通
#   3. 车机长版本获取
#   4. QNX top2 定位 + 冒烟测试（非交互 shell PATH 不全，必须用完整路径）
#   5. TTS 音频文件完整性（唤醒词 + 各场景 Query）
#
# 每场景流程:
#   静置场景开头 showmap -> 启动 CPU/MEM/top2/TTS -> 采集 60s
#   -> 停止全部 -> 拉取 top2（校验内容）重命名(版本+场景+时间)并清理 QNX 侧
#   -> 交互后静置结尾 showmap -> 间隔 60s -> 下一场景
import os
import tempfile
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

from PyQt5.QtCore import QThread, pyqtSignal

from .constants import (
    SCENARIO_NAMES, SCENARIO_QUERY_KEY, INTERACTIVE_SCENARIOS,
    DIR_CPU, DIR_MEM, DIR_SHOWMAP, DIR_SPEECH_CPU, DIR_QNX_CPU,
    DIR_LOGD, DIR_SLOG, DIR_AUDIO, COLLECT_SECONDS, INTERVAL_SECONDS,
    QNX_LOG_DIR, QNX_TOP2_PROCESS_FILE, QNX_TOP2_ALL_FILE, QNX_VERSION_CMD,
    TOP2_CANDIDATE_PATHS, QNX_TOP2_SMOKE_FILE, QNX_ENV_PREFIX,
)
from .executors import AdbExecutor, CpuCollector, LocalExecutor
from .parsers import parse_artifact_version, is_valid_top2_content
from .ssh_executor import SSHClientWrapper

# 音频文件支持的后缀（edge-tts 生成的内容兼容两种命名）
AUDIO_EXTS = (".wav", ".mp3")


def normalize_pid(raw: str) -> str:
    """从任意输入提取 PID 纯数字（自适应，兼容粘贴带空格/进程名等杂讯）
    例: '1265761  speech-service' / '1265761 ' / ' 1265761\\n' -> '1265761'
    """
    if not raw:
        return ""
    return "".join(ch for ch in str(raw) if ch.isdigit())


def find_audio_file(audio_dir: str, base_name: str) -> Optional[str]:
    """在 audio 目录查找音频文件（.wav / .mp3，必须非空），找不到返回 None"""
    for ext in AUDIO_EXTS:
        p = os.path.join(audio_dir, base_name + ext)
        try:
            if os.path.exists(p) and os.path.getsize(p) > 0:
                return p
        except OSError:
            continue
    return None


@dataclass
class TestConfig:
    """一次完整测试的配置"""
    car: str                          # 车型 NIO/ALPS/FY
    wakeup_word: str                  # 唤醒词（决定音频文件名）
    short_version: str                # 短版本（用户手填，如 NT3.0-160-daily）
    long_version: str                 # 长版本（自动从车机获取，用于 showmap 命名）
    nomi_pid: str                     # NOMI 进程 PID（showmap 用）
    speech_pid: str                   # speech-service PID（top2 用）
    collect_mem: bool
    collect_cpu: bool
    collect_top2: bool
    scenarios: List[str]              # 选中的场景 key（按固定顺序）
    output_root: str                  # 输出根目录（audio、mem 脚本在这）
    session_dir: str                  # 本轮测试总文件夹（产物在这）
    queries: Dict[str, List[str]] = field(default_factory=dict)
    ssh_host: str = "192.0.2.2"
    ssh_user: str = "root"
    ssh_password: str = "CHANGE_ME"
    top2_path: str = ""               # 用户手动指定的 top2 完整路径（可选）
    collect_slog: bool = True         # 保留字段（v1.6 起执行测试不再自动拉 slog/logd）
    is_b_test: bool = False           # B 测试: 全局跳过 QNX top2 采集

    @property
    def top2_enabled(self) -> bool:
        """top2 是否真正启用（B 测试全局跳过 QNX top2）"""
        return self.collect_top2 and not self.is_b_test


class TestEngine(QThread):
    """测试执行引擎（独立线程）"""

    log_signal = pyqtSignal(str)               # 主日志
    progress_signal = pyqtSignal(int, int)     # 当前场景序号, 总数
    finished_signal = pyqtSignal(bool, str)    # 是否成功, 消息

    def __init__(self, config: TestConfig):
        super().__init__()
        self.config = config
        self._stop_flag = False
        # TTS 播放子线程的“场景级”停止信号：每个场景开始清一次，
        # 场景采集结束(正常 60s 到点或用户停止)时 set，保证循环播放能退出
        self._tts_stop = threading.Event()
        self._adb = AdbExecutor()
        self._ssh = SSHClientWrapper()
        self._ssh.configure(config.ssh_host, config.ssh_user, config.ssh_password)
        self._session = config.session_dir
        self._tts_player = None
        self._tts_thread = None

        # top2 相关状态
        self._top2_bin = ""                    # 预检时定位的完整路径
        self._top2_fail_scenes: List[str] = []  # top2 拉取内容异常的场景
        # speech-service PID（自适应: 只保留数字，去掉粘贴带入的空格/进程名）
        self._speech_pid = normalize_pid(config.speech_pid)
        # speech 进程 top2 启动模式（冒烟测试自适配后确定）:
        #   - 附加参数为空 + pty=True  = 交互刷新模式（需伪终端）
        #   - 附加参数 "-b -z 100" + pty=False = 批处理模式（兼容无 pty 车机）
        self._top2_proc_args = ""
        self._top2_proc_pty = True

        # 就绪等待相关参数（等待本身不设固定时间上限）
        self.top2_max_restarts = 15      # 产物迟迟不就绪时的重启上限（防无限卡死）
        self.top2_grow_confirm_sleep = 2 # 就绪复核两次采样的间隔秒数
        self.top2_restart_interval = 8   # 未就绪时的重启节流间隔秒数
        self.slay_wait = 2               # slay 后等待文件落盘秒数
        self.tts_query_gap = 5           # 场景内 Query 与下一条 Query 的间隔秒数

        # 日志线程锁（多线程写日志不丢行）
        self._log_lock = threading.Lock()

        # 创建产物目录结构
        for d in [DIR_CPU, DIR_MEM, DIR_SHOWMAP, DIR_SPEECH_CPU, DIR_QNX_CPU,
                  DIR_LOGD, DIR_SLOG]:
            os.makedirs(os.path.join(self._session, d), exist_ok=True)

        # 引擎日志文件（构造即创建，保证总目录下始终可见）
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._log_file = os.path.join(self._session, f"测试日志_{ts}.log")
        try:
            with open(self._log_file, "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
                        f"引擎初始化，产物目录: {self._session}\n")
        except Exception:
            pass

    # ==================== 日志 ====================
    def _log(self, msg: str):
        line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
        self.log_signal.emit(line)
        with self._log_lock:
            try:
                with open(self._log_file, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
            except Exception:
                pass

    # ==================== 控制 ====================
    def stop(self):
        """用户请求停止"""
        self._stop_flag = True
        self._log("收到停止请求...")

    def _sleep(self, seconds: int):
        """可中断的等待"""
        for _ in range(int(seconds)):
            if self._stop_flag:
                return
            time.sleep(1)

    # ==================== 主流程 ====================
    def run(self):
        try:
            self._log("=" * 60)
            self._log("测试开始")
            self._log(f"总文件夹: {self._session}")
            self._log(f"短版本: {self.config.short_version}")
            if self.config.is_b_test:
                self._log("B 测试模式: 本轮全局跳过 QNX top2 采集")
            self._log(f"场景: {[SCENARIO_NAMES[k] for k in self.config.scenarios]}")

            # ---------- 预检：任何致命问题都不开始跑 ----------
            problems = self._precheck()
            if problems:
                for p in problems:
                    self._log(f"[预检失败] {p}")
                self.finished_signal.emit(
                    False, "预检未通过，测试未开始:\n" + "\n".join(problems))
                return
            self._log("预检全部通过，开始执行场景")

            # ---------- showmap: 静置快照（对比静置/交互后静置内存差异） ----------
            if not self._stop_flag:
                self._log("---- showmap 静置快照 ----")
                self._maybe_showmap("静置")

            total = len(self.config.scenarios)
            self.progress_signal.emit(0, total)

            for i, key in enumerate(self.config.scenarios):
                if self._stop_flag:
                    break
                name = SCENARIO_NAMES[key]
                self._log("")
                self._log("=" * 60)
                self._log(f"[{i + 1}/{total}] 场景: {name}")
                self.progress_signal.emit(i + 1, total)

                # 连接检查（断线自动重连一次）
                if not self._check_connections():
                    self.finished_signal.emit(
                        False, "ADB/SSH 连接断开，测试中止。"
                               "请检查隧道和设备后重新开始。")
                    return

                try:
                    self._run_scenario(key, name)
                except Exception:
                    self._log(f"场景执行异常:\n{traceback.format_exc()}")
                    self.finished_signal.emit(False, f"场景 [{name}] 执行异常")
                    return

                # 场景间隔（最后一个不等待）
                if i < total - 1 and not self._stop_flag:
                    self._log(f"场景间隔 {INTERVAL_SECONDS} 秒...")
                    self._sleep(INTERVAL_SECONDS)

            # ---------- showmap: 交互后静置快照（正常跑完全部场景才对比） ----------
            if self._stop_flag:
                self._log("用户手动停止: 跳过交互后静置 showmap")
            else:
                self._log("---- showmap 交互后静置快照 ----")
                self._maybe_showmap("交互后静置")

            # ---------- 结束汇总 ----------
            self._stop_tts()
            self._log("=" * 60)
            if self._stop_flag:
                self._log("用户手动停止，测试提前结束")
                self.finished_signal.emit(False, "用户手动停止")
            else:
                self._log("全部场景执行完成")
                summary = self._build_summary()
                for line in summary:
                    self._log(line)
                # v1.6: 执行测试不再自动拉取 slog/logd，只给提示
                hint = ("\n[提示] 车机 slog/logd 日志不再自动拉取；"
                        "需要时请到「连接设备」页点击「拉取 slog&logd」一次性拉取")
                self._log(hint.strip())
                self.finished_signal.emit(
                    True, "测试完成\n" + "\n".join(summary) + hint)
        except Exception as e:
            self._log(f"引擎异常:\n{traceback.format_exc()}")
            self.finished_signal.emit(False, f"引擎异常: {e}")
        finally:
            self._stop_tts()
            try:
                self._ssh.close()
            except Exception:
                pass

    # ==================== 预检 ====================
    def _precheck(self) -> List[str]:
        """启动前预检，返回致命问题列表（空列表 = 全部通过）"""
        problems: List[str] = []
        cfg = self.config

        # 1. SSH 连接（重试 3 次）
        ssh_ok = False
        last_err = ""
        for i in range(3):
            if self._stop_flag:
                return ["用户在预检期间停止"]
            try:
                self._ssh.connect(timeout=10)
                ssh_ok = True
                break
            except Exception as e:
                last_err = str(e)
                self._log(f"SSH 连接尝试 {i + 1}/3 失败: {e}")
                time.sleep(2)
        if not ssh_ok:
            problems.append(
                f"无法连接 QNX (SSH): {last_err}\n"
                "  请先建立隧道并确认 QNX 可达:\n"
                "  1) 到「连接设备」页点击「自动连接」\n"
                "  2) 或按页面提示手动建立隧道后点击「手动检测」")
            return problems
        self._log("SSH 连接成功")

        # 2. ADB
        ok, out = self._adb.shell("echo ok", timeout=8)
        if 'ok' not in out:
            problems.append(f"ADB 未连接车机安卓侧: {out}\n"
                            "  请到「连接设备」页连接 ADB")
            return problems
        self._log("ADB 连接正常")

        # 3. 长版本
        if not cfg.long_version:
            self._fetch_long_version()

        # 4. top2 定位 + 冒烟（B 测试全局跳过）
        if cfg.top2_enabled:
            if not self._speech_pid:
                problems.append(
                    "已启用 QNX top2 采集，但 speech-service PID 为空/无效。\n"
                    "  请填写 speech-service 进程 PID（只保留数字，粘贴整行也没关系）")
            elif not self._discover_and_smoke_top2():
                problems.append(
                    "QNX top2 不可用（无法定位或冒烟测试失败，详见日志），\n"
                    "  已在日志中记录尝试过的路径。请确认 QNX 上 top2 的位置，\n"
                    "  或在「执行测试」页 top2 路径框手填完整路径（如 /nio/bin/top2）。\n"
                    "  若本轮为 B 测试，请勾选「B 测试」自动跳过 top2。")
            else:
                self._log(f"top2 可用: {self._top2_bin}")
        elif cfg.collect_top2 and cfg.is_b_test:
            self._log("B 测试: 跳过 top2 预检")

        # 5. 音频预检
        if any(k in INTERACTIVE_SCENARIOS for k in cfg.scenarios):
            problems.extend(self._precheck_audio())

        return problems

    def _precheck_audio(self) -> List[str]:
        """音频完整性预检：唤醒词 + 各交互场景 Query"""
        cfg = self.config
        audio_dir = os.path.join(cfg.output_root, DIR_AUDIO)
        problems: List[str] = []
        missing: List[str] = []

        # 唤醒词（唤醒场景循环用 + 每个交互场景开头用）
        if find_audio_file(audio_dir, cfg.wakeup_word) is None:
            missing.append(f"唤醒词: {cfg.wakeup_word}.wav/.mp3")

        # 各交互场景 query（唤醒场景本身只循环唤醒词音频，不要求 Query）
        for key in cfg.scenarios:
            if key == "wakeup":
                continue
            qkey = SCENARIO_QUERY_KEY.get(key)
            if not qkey:
                continue
            queries = cfg.queries.get(qkey, [])
            if not queries:
                problems.append(f"场景 [{qkey}] 在配置中没有 Query，"
                                f"请到「TTS 配置」页填写")
                continue
            for q in queries:
                safe = q.strip().replace("/", "_").replace("\\", "_")
                if find_audio_file(audio_dir, f"{qkey}_{safe}") is None:
                    missing.append(f"{qkey}_{safe}.wav/.mp3")

        if missing:
            problems.append(
                f"以下 {len(missing)} 个音频文件缺失（目录: {audio_dir}），\n"
                "  请到「TTS 配置」页点击「生成所有音频」:\n  "
                + "\n  ".join(missing))
        return problems

    # ==================== top2 定位与冒烟 ====================
    def _discover_and_smoke_top2(self) -> bool:
        """定位 top2 完整路径并做冒烟测试（3 秒真实采样）
        优先级: 用户手填路径 > which/command -v > 常见候选路径
        """
        # 0. 用户手填的路径优先
        if self.config.top2_path:
            user_path = self.config.top2_path.strip()
            self._log(f"使用手动指定的 top2 路径: {user_path}")
            if self._smoke_top2(user_path):
                self._top2_bin = user_path
                return True
            self._log("[错误] 手动指定的 top2 路径冒烟测试失败（见上方日志）")
            return False

        # 1. 自动发现: which / command -v / 候选路径逐一检查
        candidates = " ".join(TOP2_CANDIDATE_PATHS)
        discover_cmd = (
            f'. /etc/profile 2>/dev/null; '
            f'which top2 2>/dev/null; '
            f'command -v top2 2>/dev/null; '
            f'for p in {candidates}; do [ -x "$p" ] && {{ echo "$p"; break; }}; done; '
            f'echo "PATH=$PATH"'
        )
        ok, out = self._ssh.exec(discover_cmd, timeout=15)
        self._log(f"top2 路径探测输出: {out.strip()[:200] if out else '(空)'}")
        top2_bin = ""
        if ok and out:
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("/") and line.endswith("top2"):
                    top2_bin = line
                    break
        if not top2_bin:
            self._log(
                "[top2诊断] 自动发现失败。请在「执行测试」页的 top2 路径框中"
                "填入完整路径。\n"
                "  查看方法: 用 SSH 工具登录 QNX 后执行  which top2\n"
                "  常见位置: /nio/bin/top2 或 /bin/top2")
            return False
        self._top2_bin = top2_bin

        if self._smoke_top2(top2_bin):
            return True
        self._log("[top2诊断] 冒烟失败（已尝试 /etc/profile 环境和库路径），"
                  "请在「执行测试」页手填 top2 完整路径，或检查 QNX 上 top2 是否可用")
        return False

    def _smoke_top2(self, top2_bin: str) -> bool:
        """冒烟测试: 用采集同款命令真实跑 3 秒 top2，SFTP 拉取校验内容。

        完全不依赖 QNX shell 工具:
          1) 命令带 legacy_conn_tool 同款环境前缀（source /etc/profile + PATH +
             LD_LIBRARY_PATH 补全），解决缺库静默失败
          2) SFTP stat 检查文件大小 -> SFTP 拉回本地校验头部内容
          3) 关键点（本次修复）: 命令**不加 & 后台化**，而是让 top2 前台跑在
             SSH channel 上（伪终端模式时 stdin 就是 TTY）。因为非交互 shell
             会把带 & 的后台任务 stdin 重定向到 /dev/null，top2 交互模式拿不到
             终端而报 "Unable to enter cbreak mode"；这正是“终端里手动能跑、
             脚本里跑不了”的根本原因。
          4) 不阻塞等待会话结束：channel 挂起后由本机 sleep 3 秒再 slay，
             避免某些 sshd 上 pty 会话迟迟不 EOF 导致 exec 卡 30 秒超时。
          5) 每种模式前保证连接可用（失败的尝试可能断开连接）。
        """
        # 候选采集方式: (说明, 附加参数, 是否申请伪终端)
        candidates = [
            ("交互刷新(pseudo-tty)", "", True),
            ("批处理(-b -z 100)", "-b -z 100", False),
        ]
        for tag, extra, use_pty in candidates:
            smoke = QNX_TOP2_SMOKE_FILE

            # 失败的尝试可能把连接打掉，尝试下一种前先确保连接可用
            try:
                if not self._ssh.is_connected():
                    self._log(f"[top2冒烟] {tag}: SSH 连接已断开，重新连接...")
                    self._ssh.connect(timeout=10)
            except Exception as e:
                self._log(f"[top2冒烟] {tag}: 连接不可用: {e}")
                continue

            self._ssh.exec(f'rm -f {smoke}', timeout=10)
            self._log(f"[top2冒烟] 尝试 {tag} 模式...")
            # 注意: 命令末尾不加 &，让 top2 作为 channel 上的前台进程运行
            cmd = (
                f'{QNX_ENV_PREFIX} {top2_bin} {extra} -p {self._speech_pid} '
                f'> {smoke} 2>&1'
            )
            ch = self._ssh.exec_background_keep(cmd, get_pty=use_pty)
            if ch is None:
                self._log(f"[top2冒烟] {tag}: channel 建立失败")
                self._cleanup_smoke(smoke)
                continue

            time.sleep(3)   # 真实采样 3 秒（不阻塞读 channel，仅本地等待）
            self._ssh.exec("slay top2 >/dev/null 2>&1", timeout=10)
            try:
                ch.close()
            except Exception:
                pass
            if self.slay_wait > 0:
                time.sleep(self.slay_wait)   # 等文件落盘

            size = self._ssh.sftp_stat_size(smoke)
            local_tmp = os.path.join(tempfile.gettempdir(), "nomi_top2_smoke.log")
            head = ""
            if size is None or size < 0:
                self._log(f"[top2冒烟] {tag} 远端文件未生成")
            else:
                # 拉回本地校验内容（空文件 / 报错信息都算失败）
                if size > 0:
                    ok2, _ = self._ssh.sftp_get_file(smoke, local_tmp)
                    if ok2 and os.path.exists(local_tmp):
                        try:
                            with open(local_tmp, "r", encoding="utf-8",
                                      errors="replace") as f:
                                head = f.read(300)
                        except Exception:
                            head = ""
                if is_valid_top2_content(head, size):
                    # 记录该场景正式采集使用的模式
                    self._top2_proc_args = extra.strip()
                    self._top2_proc_pty = use_pty
                    self._log(f"top2 冒烟测试通过 ({tag}, 远端文件 {size} 字节)")
                    self._cleanup_smoke(smoke, local_tmp)
                    return True
                self._log(f"[top2冒烟] {tag} 输出无效 "
                          f"(size={size}): {head.strip()[:150] or '(空)'}")
            self._cleanup_smoke(smoke, local_tmp)
        return False

    def _cleanup_smoke(self, remote_file: str, local_tmp: str = ""):
        """清理冒烟测试的远端/本地临时文件"""
        try:
            self._ssh.exec(f'rm -f {remote_file}', timeout=10)
        except Exception:
            pass
        if local_tmp and os.path.exists(local_tmp):
            try:
                os.remove(local_tmp)
            except Exception:
                pass

    # ==================== 单场景执行 ====================
    def _run_scenario(self, key: str, name: str):
        cfg = self.config
        ts = datetime.now().strftime("%Y%m%d%H%M")
        cpu = None
        mem_proc = None
        top2_channels: list = []

        try:
            # ---- 先启动 QNX top2 并等待产物就绪 ----
            # 就绪 = process/all 两个远端文件已创建且在持续增长。就绪等待不设
            # 固定时间上限（不计入 60 秒采集），等全部产物就绪后再启动 CPU/MEM
            # 与 TTS，避免“启动慢被误判失败”（GPT 等场景的同类问题）。
            if cfg.top2_enabled and self._speech_pid and self._top2_bin:
                top2_channels = self._start_top2(self._speech_pid)
                if not top2_channels:
                    self._log("[错误] top2 未能就绪，本轮按失败场景记录（继续下一场景）")
                    if name not in self._top2_fail_scenes:
                        self._top2_fail_scenes.append(name)

            # ---- 就绪后再启动 CPU 采集（保证 60 秒采集口径干净） ----
            if cfg.collect_cpu:
                cpu_file = os.path.join(
                    self._session, DIR_CPU,
                    f"nomi_CPU_out-{cfg.short_version}-{name}-{ts}.log")
                cpu = CpuCollector()
                if cpu.start(cpu_file):
                    self._log(f"CPU 采集启动 -> {DIR_CPU}/{os.path.basename(cpu_file)}")
                else:
                    cpu = None
                    self._log("[错误] CPU 采集启动失败")

            # ---- 启动 MEM 脚本 ----
            if cfg.collect_mem:
                mem_script = os.path.join(cfg.output_root, "mem_command_nomi.sh")
                if os.path.exists(mem_script):
                    mem_out_dir = os.path.join(self._session, DIR_MEM)
                    mem_proc = LocalExecutor.start_mem_script(
                        mem_script, mem_out_dir, ts,
                        f"{cfg.short_version}-{name}")
                    if mem_proc:
                        self._log(f"MEM 脚本启动 (输出目录: {DIR_MEM}/, "
                                  f"命名参数: {cfg.short_version}-{name})")
                    else:
                        self._log("[错误] MEM 脚本启动失败: 未找到 bash "
                                  "(请安装 Git for Windows)")
                else:
                    self._log(f"[错误] MEM 脚本不存在: {mem_script}")

            # ---- 启动 TTS 播放（交互场景） ----
            if key in INTERACTIVE_SCENARIOS:
                self._start_tts(key)

            # ---- 采集 60 秒（产物均已就绪后开始计时） ----
            self._log(f"采集 {COLLECT_SECONDS} 秒...")
            self._sleep(COLLECT_SECONDS)

            # ---- 停止全部采集 ----
            self._log("停止采集...")
            if cpu:
                cpu.stop()
                cpu = None
                self._log("CPU 采集已停止")
            if mem_proc:
                LocalExecutor.kill_tree(mem_proc)
                mem_proc = None
                self._log("MEM 脚本已停止")
            if top2_channels:
                self._stop_top2(top2_channels)
                top2_channels = []
            self._stop_tts()

            # ---- 拉取 top2 日志并重命名 ----
            if cfg.top2_enabled and self._speech_pid and self._top2_bin:
                self._pull_top2(name, ts)
        finally:
            # 兜底清理（异常路径也要停干净）
            if cpu:
                cpu.stop()
            if mem_proc:
                LocalExecutor.kill_tree(mem_proc)
            if top2_channels:
                self._stop_top2(top2_channels)
            self._stop_tts()

        self._log(f"场景 [{name}] 完成")

    # ==================== top2 ====================
    def _start_top2(self, speech_pid: str) -> list:
        """在 QNX 上后台启动两条 top2 采集（使用预检定位的完整路径）
        - top2_process_qnx_001.log: speech 进程监控，命令与人工验证环境一致
          (交互刷新模式)。采集通过 ssh 后台会话执行，无 TTY 时 top2 报
          "Unable to enter cbreak mode"，因此必须申请伪终端(get_pty)。
        - top2_all_qnx_001.log: 全系统 batch 采样(top2 -b -z 100)，无需 TTY。
        """
        # 先清理远端残留文件，防止上个场景的数据被误拉
        channels = []
        if not self._ensure_ssh():
            self._log("[错误] top2 启动前 SSH 不可用，跳过本轮 top2")
            return channels
        self._ssh.exec(
            f'rm -f {QNX_LOG_DIR}{QNX_TOP2_PROCESS_FILE} '
            f'{QNX_LOG_DIR}{QNX_TOP2_ALL_FILE}', timeout=10)

        prefix = QNX_ENV_PREFIX
        pid = self._speech_pid or normalize_pid(speech_pid)
        mode_tag = ("伪终端交互" if self._top2_proc_pty
                    else "批处理(-b -z 100)")
        # 关键: 命令末尾不加 &（后台化会把 stdin 重定向 /dev/null，导致交互模式
        # top2 报 cbreak 错误）。top2 前台跑在 channel 上，由 _stop_top2 slay 结束。
        cmd_p = (f'{prefix} {self._top2_bin} {self._top2_proc_args} '
                 f'-p {pid} '
                 f'> {QNX_LOG_DIR}{QNX_TOP2_PROCESS_FILE} 2>&1')
        cmd_b = (f'{prefix} {self._top2_bin} -b -z 100 '
                 f'> {QNX_LOG_DIR}{QNX_TOP2_ALL_FILE} 2>&1')

        def _launch() -> list:
            chs = []
            c1 = self._ssh.exec_background_keep(
                cmd_p, get_pty=self._top2_proc_pty)
            c2 = self._ssh.exec_background_keep(cmd_b)
            if c1:
                chs.append(c1)
            if c2:
                chs.append(c2)
            return chs

        channels = _launch()
        if not channels:
            self._log("[错误] QNX top2 启动失败（channel 建立失败）")
            return channels

        self._log(f"QNX top2 已启动 (speech PID: {pid}, "
                  f"模式: {mode_tag}, 路径: {self._top2_bin})")

        # ============ 就绪等待（不设固定时间上限） ============
        # 目标: process/all 两个远端文件已创建且在持续增长才算就绪，之后才进入
        # 正式 60 秒采集。等待期间持续探测；仅以下情况放弃（记录失败继续）:
        #   1) SSH 断线且重连失败（top2 通道随之失效）
        #   2) 连续多次重启后两条产物从未就绪（判车机侧不可恢复，防无限卡死）
        #   3) 用户手动停止
        def _sizes():
            sizes = {}
            for remote_file, tag in [(QNX_TOP2_PROCESS_FILE, "process"),
                                     (QNX_TOP2_ALL_FILE, "all")]:
                sizes[tag] = self._ssh.sftp_stat_size(QNX_LOG_DIR + remote_file)
            return sizes

        def _ready() -> bool:
            """就绪 = process/all 两个文件都已创建且非空。

            说明: top2 输出是行缓冲/低频写入（空闲场景几秒都可能不新增字节），
            因此不能要求“两次采样严格变大”，否则会把正常慢速写入误判为未启动
            而反复重启（清空文件重来）。这里只要求两个文件存在、非空，并且
            隔一小段时间复查后仍非空（排除 rm 残留/进程退出即清空的假象）。
            """
            s1 = _sizes()
            if s1.get("process", -1) <= 0 or s1.get("all", -1) <= 0:
                return False
            time.sleep(self.top2_grow_confirm_sleep)
            s2 = _sizes()
            return (s2.get("process", -1) > 0 and s2.get("all", -1) > 0)

        self._log("[top2] 等待产物就绪（不设固定等待上限）...")
        restart_count = 0
        last_restart_ts = time.time()
        if _ready():
            self._log("[top2] 产物已就绪: process/all 均已创建")
        else:
            while not self._stop_flag:
                if not self._ensure_ssh():
                    self._log("[错误] top2 就绪等待期间 SSH 不可用，放弃本轮")
                    for ch in channels:
                        try:
                            ch.close()
                        except Exception:
                            pass
                    return []
                sizes = _sizes()
                # 间隔复查：文件出现且非空即认为就绪（避免慢速写入被误判重启）
                if _ready():
                    self._log("[top2] 产物已就绪: process/all 均已创建")
                    break
                # 未就绪且超过节流间隔 -> 重启一轮再等（slay + 清文件 + 重起）
                if time.time() - last_restart_ts >= self.top2_restart_interval:
                    restart_count += 1
                    if restart_count > self.top2_max_restarts:
                        self._log("[错误] top2 连续多次重启后产物仍未就绪，"
                                  "放弃等待（本轮记录失败，继续下一场景）")
                        for ch in channels:
                            try:
                                ch.close()
                            except Exception:
                                pass
                        return []
                    self._log(f"[top2] 第 {restart_count} 次重启再等"
                              f" (process={sizes.get('process', -1)} 字节, "
                              f"all={sizes.get('all', -1)} 字节)...")
                    for ch in channels:
                        try:
                            ch.close()
                        except Exception:
                            pass
                    self._ssh.exec("slay top2 >/dev/null 2>&1", timeout=10)
                    self._ssh.exec(
                        f'rm -f {QNX_LOG_DIR}{QNX_TOP2_PROCESS_FILE} '
                        f'{QNX_LOG_DIR}{QNX_TOP2_ALL_FILE}', timeout=10)
                    channels = _launch()
                    if not channels:
                        self._log("[错误] QNX top2 重启失败（channel 建立失败）")
                        return channels
                    last_restart_ts = time.time()
        return channels

    def _stop_top2(self, channels: list):
        """停止 QNX 上的 top2 进程并关闭 channel"""
        if not channels:
            return
        # QNX 标准用 slay 按进程名杀；断线时 top2 已随会话退出，跳过 slay
        if self._ssh.is_connected():
            self._ssh.exec("slay top2", timeout=10)
        else:
            self._log("SSH 已断开，top2 会话随连接退出，无需 slay")
        if self.slay_wait > 0:
            time.sleep(self.slay_wait)  # 等待文件写入完成
        for ch in channels:
            try:
                ch.close()
            except Exception:
                pass
        self._log("QNX top2 已停止")

    def _pull_top2(self, name: str, ts: str):
        """拉取 QNX top2 日志到本地，按 版本+场景+时间 重命名，校验内容并清理远端"""
        cfg = self.config
        pairs = [
            (QNX_TOP2_PROCESS_FILE, DIR_SPEECH_CPU, "top2_process_qnx"),
            (QNX_TOP2_ALL_FILE, DIR_QNX_CPU, "top2_all_qnx"),
        ]
        # 断线自动重连后再拉取（GPT 等场景曾因 SSH 抖动导致整轮文件拉不到）
        if not self._ensure_ssh():
            self._log("[错误] SSH 未连接，无法拉取 top2 日志")
            for _remote, _ld, prefix in pairs:
                if name not in self._top2_fail_scenes:
                    self._top2_fail_scenes.append(name)
            return

        for remote_file, local_dir, prefix in pairs:
            remote_path = f"{QNX_LOG_DIR}{remote_file}"
            local_name = f"{prefix}_{cfg.short_version}-{name}-{ts}.log"
            local_path = os.path.join(self._session, local_dir, local_name)
            ok, msg = self._ssh.sftp_get_file(remote_path, local_path)
            if not ok and "未连接" in msg:
                self._log(f"[重连] 拉取 {prefix} 时 SSH 断开，重连重试...")
                if self._ensure_ssh():
                    ok, msg = self._ssh.sftp_get_file(remote_path, local_path)
            if not ok:
                self._log(f"[错误] 拉取 {prefix} 失败: {msg}")
                if name not in self._top2_fail_scenes:
                    self._top2_fail_scenes.append(name)
            else:
                # 校验内容（防止拉下来的是错误信息或空文件）
                try:
                    size = os.path.getsize(local_path)
                    with open(local_path, "r", encoding="utf-8",
                              errors="replace") as f:
                        head = f.read(300)
                    if not is_valid_top2_content(head, size):
                        low = head.lower()
                        reason = ""
                        if any(k in low for k in
                               ("unable to enter", "cbreak",
                                "inappropriate i/o", "tcsetattr")):
                            reason = ("top2 需要交互终端，但伪终端申请失败"
                                      "或 sshd 未允许 TTY")
                        elif "cannot execute" in low or "not found" in low:
                            reason = "top2 路径或动态库加载失败"
                        self._log(f"[top2错误] {prefix} 拉取的内容异常 "
                                  f"(size={size}{('，原因: ' + reason) if reason else ''}): "
                                  f"{head.strip()[:120] or '(空)'}")
                        if name not in self._top2_fail_scenes:
                            self._top2_fail_scenes.append(name)
                    else:
                        self._log(f"已拉取 {prefix} ({size} 字节) -> "
                                  f"{local_dir}/{local_name}")
                except Exception as e:
                    self._log(f"[错误] 校验 {prefix} 失败: {e}")

            # 无论成功失败都清理远端，避免下个场景拉到旧数据
            self._ssh.exec(f"rm -f {remote_path}", timeout=10)

    # ==================== showmap ====================
    def _maybe_showmap(self, phase: str):
        """整轮测试的 showmap 快照（phase: 静置 / 交互后静置）。

        只在「静置(测试开始前)」与「交互后静置(全部场景跑完)」各执行一次，
        用于对比整轮测试前后的内存差异。未填 NOMI PID 时不阻塞测试，
        只给出明确警告。
        """
        pid = normalize_pid(self.config.nomi_pid)
        if not pid:
            self._log(f"[showmap警告] 未填写 NOMI PID（ALPS 填小乐 PID），"
                      f"无法生成[{phase}] showmap 快照，请填写后重跑")
            return
        ts = datetime.now().strftime("%Y%m%d%H%M")
        self._showmap(phase, ts)

    def _showmap(self, name: str, ts: str):
        """执行 showmap，产物: Mem_Showmap_{长版本}_{场景}_{时间}.log"""
        cfg = self.config
        out_name = f"Mem_Showmap_{cfg.long_version}_{name}_{ts}.log"
        out_path = os.path.join(self._session, DIR_SHOWMAP, out_name)
        ok, out = self._adb.shell(f"showmap {cfg.nomi_pid}", timeout=60)
        if ok and out:
            try:
                with open(out_path, "w", encoding="utf-8", errors="replace") as f:
                    f.write(out + "\n")
                self._log(f"showmap 完成 -> {DIR_SHOWMAP}/{out_name}")
            except Exception as e:
                self._log(f"[错误] showmap 写文件失败: {e}")
        else:
            self._log(f"[错误] showmap 执行失败: {out}")

    # ==================== 长版本获取 ====================
    def _fetch_long_version(self):
        """从 QNX nio/version.txt 解析 Artifact 字段作为车机长版本
        示例: "Artifact : ALPS_VFT_NT3.0_CN_STAGE_daily..." -> 取冒号后内容
        """
        ok, out = self._ssh.exec(QNX_VERSION_CMD, timeout=10)
        version = None
        if ok and out:
            version = parse_artifact_version(out)
        if version:
            self.config.long_version = version
            self._log(f"车机长版本 (Artifact): {version}")
        else:
            self.config.long_version = "unknown"
            self._log("[警告] version.txt 中未找到 Artifact 字段，"
                      "showmap 命名将使用 unknown")

    # ==================== TTS 播放 ====================
    def _start_tts(self, key: str):
        try:
            from .audio_player import AudioPlayer
            player = AudioPlayer(log_cb=self._log)
            self._tts_player = player
            self._tts_stop.clear()   # 新场景开始，允许循环播放继续
            self._log("TTS 播放启动")
            t = threading.Thread(target=self._play_tts, args=(key, player),
                                 daemon=True)
            self._tts_thread = t
            t.start()
        except Exception as e:
            self._log(f"[TTS错误] 启动失败: {e}")

    def _stop_tts(self):
        self._tts_stop.set()   # 通知播放子线程退出循环
        if self._tts_player:
            try:
                self._tts_player.stop()
            except Exception:
                pass
        if self._tts_thread and self._tts_thread.is_alive():
            self._tts_thread.join(timeout=3)
        if self._tts_player:
            self._log("TTS 播放已停止")
        self._tts_player = None
        self._tts_thread = None

    def _play_tts(self, key: str, player):
        """音频播放逻辑（子线程）
        - 唤醒场景: 循环播放唤醒词，间隔 2 秒，直到场景采集结束
        - 其他交互场景: 循环执行「唤醒词 -> 逐条 Query」直到场景采集结束；
          电话场景每条 Query 后加挂断音。这样无论该场景配了几条 Query，
          都会持续外放直到本场景 60 秒采集停止。
        音频文件位于 {output_root}/audio/（.wav 或 .mp3）
        """
        cfg = self.config
        audio_dir = os.path.join(cfg.output_root, DIR_AUDIO)
        wakeup_file = find_audio_file(audio_dir, cfg.wakeup_word)

        if key == "wakeup":
            if wakeup_file:
                self._log(f"循环播放唤醒词: {cfg.wakeup_word}")
                player.play_loop(wakeup_file, interval=2)
            else:
                self._log(f"[TTS错误] 唤醒词音频缺失: "
                          f"{os.path.join(audio_dir, cfg.wakeup_word)}.wav/.mp3")
            return

        qkey = SCENARIO_QUERY_KEY.get(key)
        if qkey is None:
            return
        queries = cfg.queries.get(qkey, [])

        # 场景级中止判断（用户手动停止 或 本场景 60s 采集到点都会触发）
        def aborted() -> bool:
            return self._stop_flag or self._tts_stop.is_set()

        # 唤醒词只在场景开头播一次，之后 Query 一直循环到本场景采集结束
        if wakeup_file:
            self._log(f"播放唤醒词: {cfg.wakeup_word}")
            player.play(wakeup_file)
        else:
            self._log("[TTS错误] 唤醒词音频缺失，跳过唤醒")
        if not aborted():
            time.sleep(1)

        if not queries:
            # 无 Query 配置时退化为周期性重复唤醒词（直到场景结束）
            self._log(f"[TTS警告] 场景 [{qkey}] 无 Query 配置，仅循环唤醒词")
            while not aborted():
                if wakeup_file:
                    player.play(wakeup_file)
                time.sleep(3)
            return

        # Query 循环播放，直到场景结束（唤醒词不再重复）
        # 相邻两条 Query 之间留 tts_query_gap 秒（默认 5s），给 NOMI 应答留时间
        while not aborted():
            for q in queries:
                if aborted():
                    break
                safe = q.strip().replace("/", "_").replace("\\", "_")
                q_file = find_audio_file(audio_dir, f"{qkey}_{safe}")
                if q_file:
                    self._log(f"播放: {qkey}/{q}")
                    player.play(q_file)
                    if aborted():
                        break
                    # 电话场景: query 播完 2 秒内挂断（防止误拨/漏接影响测试），
                    # 挂断后再等满 query 间隔(默认 5 秒)播下一条
                    if key == "phone":
                        time.sleep(2)
                        hangup = find_audio_file(audio_dir, "电话_挂断")
                        if hangup:
                            self._log("播放: 电话/挂断")
                            player.play(hangup)
                            if aborted():
                                break
                            time.sleep(self.tts_query_gap)
                        else:
                            self._log("[TTS警告] 电话挂断音缺失: 电话_挂断.wav")
                            time.sleep(self.tts_query_gap)
                    else:
                        time.sleep(self.tts_query_gap)
                else:
                    self._log(f"[TTS错误] 音频缺失: {qkey}_{safe}.wav/.mp3")
                    time.sleep(1)
            # 每条 Query 后已等待 tts_query_gap，轮末无需再加间隔

    # ==================== 连接检查 ====================
    def _ensure_ssh(self, timeout: int = 10) -> bool:
        """确保 SSH 连接可用；断线则自动重连。返回是否可用"""
        try:
            if not self._ssh.is_connected():
                self._log("SSH 断线，重连中...")
                self._ssh.connect(timeout=timeout)
                self._log("SSH 重连成功")
        except Exception as e:
            self._log(f"[错误] SSH 重连失败: {e}")
            return False
        return True

    def _check_connections(self) -> bool:
        ok, out = self._adb.shell("echo ok", timeout=5)
        if 'ok' not in out:
            self._log(f"[错误] ADB 连接异常: {out}")
            return False
        try:
            if not self._ssh.is_connected():
                self._log("SSH 断线，重连中...")
                self._ssh.connect(timeout=10)
                self._log("SSH 重连成功")
        except Exception as e:
            self._log(f"[错误] SSH 重连失败: {e}")
            return False
        return True

    # ==================== 结果汇总 ====================
    def _build_summary(self) -> List[str]:
        """统计产物文件数量，生成结束汇总"""
        lines = [f"产物目录: {self._session}"]
        for d, desc in [(DIR_CPU, "CPU 日志"), (DIR_MEM, "MEM 数据"),
                        (DIR_SHOWMAP, "showmap"), (DIR_SPEECH_CPU, "speech-cpu(top2)"),
                        (DIR_QNX_CPU, "qnx-cpu(top2)")]:
            path = os.path.join(self._session, d)
            try:
                count = len([f for f in os.listdir(path)
                             if os.path.isfile(os.path.join(path, f))])
            except Exception:
                count = 0
            lines.append(f"  {desc}: {count} 个文件")
        if self._top2_fail_scenes:
            lines.append(f"[注意] top2 采集异常的场景: "
                         f"{'、'.join(self._top2_fail_scenes)}")
        return lines
