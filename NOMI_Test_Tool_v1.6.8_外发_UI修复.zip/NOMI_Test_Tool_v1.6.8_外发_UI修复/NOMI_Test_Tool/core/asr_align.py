# core/asr_align.py
# v1.6.2+ 响应时延分析 —— 本地离线 ASR（faster-whisper）封装
#
# 设计:
#   - 推理后端自动检测: 有 NVIDIA GPU(ctranslate2 CUDA) 用 CUDA+float16；
#     否则平滑回退 CPU + int8。
#   - 模型规格: tiny(base/small/medium)，中英文多语种原生支持；
#     默认 base（CPU/GPU 均衡）。
#   - 模型存放: <脚本目录>/models/faster-whisper-{规格}/。
#     缺失时自动从 hf-mirror.com 镜像下载（huggingface.co 在公司网络常被
#     墙导致 ConnectTimeout，镜像可达），下载成功后完全离线。
#   - 纯逻辑模块，不依赖 Qt；真正的推理放在 UI Worker 线程内执行。
import os
import threading
import urllib.request

MODEL_CHOICES = ["tiny", "base", "small", "medium"]
DEFAULT_MODEL = "base"
LANGUAGE_CHOICES = ["auto", "zh", "en"]          # auto=按内容自动判断语种
LANGUAGE_LABELS = {"auto": "自动识别(中/英)", "zh": "中文", "en": "英文"}
# v1.6.6: 模型规格中文显示名（桌面与浏览器下拉共用）
MODEL_LABELS = {
    "tiny": "tiny（极速）",
    "base": "base（均衡）",
    "small": "small（高精度）",
    "medium": "medium（专业级）",
}

# 模型运行所需文件（经镜像仓库实测确认；注意词汇表文件是 vocabulary.txt）
# 仓库: Systran/faster-whisper-{size} 实际含: config.json / model.bin /
#       tokenizer.json / vocabulary.txt（另有 README/.gitattributes 无需下载）
_MODEL_FILES = ["config.json", "tokenizer.json", "vocabulary.txt", "model.bin"]
_MIRROR = "https://hf-mirror.com"

# 默认模型根目录: <脚本目录>/models
_DEFAULT_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
_MODEL_ROOT = _DEFAULT_ROOT

_engine = None
_engine_lock = threading.Lock()
_download_cb = None


def set_model_root(path):
    """把模型固定下载/读取到指定目录。None -> <脚本目录>/models。"""
    global _MODEL_ROOT
    _MODEL_ROOT = path or _DEFAULT_ROOT


def model_root():
    return _MODEL_ROOT


def model_dir(name: str) -> str:
    return os.path.join(_MODEL_ROOT, f"faster-whisper-{name}")


def is_model_ready(name: str) -> bool:
    """模型是否已完整在本地（无需下载即可加载）"""
    return _model_local_ok(name)


def set_download_callback(fn):
    """设置下载进度回调 fn(msg:str)（在下载线程内被调用，可转发给 UI 信号）"""
    global _download_cb
    _download_cb = fn


def _notify(msg: str):
    cb = _download_cb
    if cb is not None:
        try:
            cb(msg)
        except Exception:
            pass


def _effective_cpu_threads() -> int:
    """ASR 推理/量化线程数。

    默认不把 CPU 全部核吃满（整机与 UI 会卡），而是留一半给系统。
    可用环境变量 NOMI_ASR_CPU_THREADS 覆盖（如 8 = 全速）。
    """
    v = os.environ.get("NOMI_ASR_CPU_THREADS", "")
    if v.isdigit() and int(v) > 0:
        return int(v)
    n = os.cpu_count() or 4
    return max(2, min(n, 4))


def pick_backend():
    """自动检测推理后端。返回 (device, compute_type)。

    ctranslate2 是 faster-whisper 的推理内核：
      cuda_devices>0 -> 'cuda'/'float16'，否则 'cpu'/'int8'。
    """
    try:
        import ctranslate2
        if ctranslate2.get_cuda_device_count() > 0:
            return "cuda", "float16"
    except Exception:
        pass
    return "cpu", "int8"


def backend_desc():
    dev, ct = pick_backend()
    if dev == "cuda":
        return f"GPU (CUDA / {ct})"
    return f"CPU ({ct})"


def engine_available() -> bool:
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def _model_local_ok(name: str) -> bool:
    d = model_dir(name)
    return os.path.exists(os.path.join(d, "model.bin")) and all(
        os.path.exists(os.path.join(d, f)) for f in _MODEL_FILES)


def ensure_model_downloaded(name: str) -> str:
    """确保模型在本地 models/ 目录，缺失则从 hf-mirror 下载。返回目录路径。"""
    d = model_dir(name)
    if _model_local_ok(name):
        return d
    os.makedirs(d, exist_ok=True)
    # 分别下载每个必需文件（可断点续传：先下载到 .part 再改名）
    for f in _MODEL_FILES:
        dst = os.path.join(d, f)
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            continue
        url = f"{_MIRROR}/Systran/faster-whisper-{name}/resolve/main/{f}"
        part = dst + ".part"
        _notify(f"下载 ASR 模型 [{name}] {f} ...")
        try:
            _download_file(url, part, fname=f, notify=_notify)
            os.replace(part, dst)
            _notify(f"  {f} 完成 ({os.path.getsize(dst)/1024/1024:.1f}MB)")
        except Exception as e:
            for p in (part, dst):
                try:
                    if os.path.exists(p):
                        os.remove(p)
                except OSError:
                    pass
            raise RuntimeError(
                f"ASR 模型下载失败: {url}\n{e}\n"
                f"若网络受限，可手动用浏览器下载以下 4 个文件到：\n{d}\n"
                "(文件列表: config.json, tokenizer.json, vocabulary.txt, "
                "model.bin；下载完成后重启工具即可离线使用)")
    return d


def _download_file(url: str, dst: str, fname: str, notify) -> None:
    """流式下载到 dst（带进度回调，超时/错误抛异常）"""
    req = urllib.request.Request(url, headers={"User-Agent": "NOMI-Test-Tool/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r, open(dst, "wb") as fp:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = r.read(1 << 18)
            if not chunk:
                break
            fp.write(chunk)
            done += len(chunk)
            if total and notify:
                pct = done * 100 // max(1, total)
                if pct % 10 == 0 or done == total:
                    notify(f"    {fname} {pct}% "
                           f"({done/1024/1024:.1f}/{total/1024/1024:.1f}MB)")
    if total and done < total:
        raise RuntimeError("下载不完整（连接中断）")


def load_model(model_name: str = DEFAULT_MODEL):
    """加载 faster-whisper 模型并缓存复用（线程锁保护）。返回 WhisperModel。

    模型缺失时自动从 hf-mirror 下载（huggingface.co 直连在公司网络常超时）。
    """
    global _engine
    if model_name not in MODEL_CHOICES:
        raise RuntimeError(f"未知 ASR 模型: {model_name}（可选 {MODEL_CHOICES}）")
    with _engine_lock:
        if _engine is not None and getattr(_engine, "_model_name", "") == model_name:
            return _engine
        try:
            from faster_whisper import WhisperModel
        except Exception as e:
            raise RuntimeError(
                "未安装 faster-whisper，请先执行: pip install faster-whisper"
                f"（当前: {e}）")
        device, compute_type = pick_backend()
        try:
            path = ensure_model_downloaded(model_name)
            model = WhisperModel(
                path, device=device, compute_type=compute_type,
                cpu_threads=_effective_cpu_threads(), num_workers=1)
        except RuntimeError:
            raise
        except Exception as e:
            raise RuntimeError(
                f"ASR 模型加载失败（{model_name} / {device} / {compute_type}）："
                f"{e}\n模型目录: {model_dir(model_name)}")
        _engine = model
        _engine._model_name = model_name
        return _engine


def reset_model():
    """释放已加载模型（切换模型或退出时调用）"""
    global _engine
    with _engine_lock:
        _engine = None


def transcribe_clip(audio16k, model_name: str = DEFAULT_MODEL,
                    language: str = "auto"):
    """对一段 16kHz 单声道 float32 音频做 ASR，返回段列表。

    返回 [{start, end, text}, ...]（text 去除首尾空白）；无声/过短返回 []。
    language: 'auto'/'zh'/'en'；auto 交给模型自动判断（中英文均支持）。
    """
    import numpy as np
    if audio16k is None:
        return []
    x = np.asarray(audio16k)
    if x.size == 0:
        return []
    if float(len(x)) / 16000.0 < 0.08:
        return []
    model = load_model(model_name)
    lang = None if language == "auto" else language
    segs, _info = model.transcribe(
        x, language=lang, task="transcribe", beam_size=1,
        condition_on_previous_text=False, vad_filter=False)
    out = []
    for s in segs:
        txt = (s.text or "").strip()
        if txt:
            out.append({"start": float(s.start), "end": float(s.end),
                        "text": txt})
    return out
