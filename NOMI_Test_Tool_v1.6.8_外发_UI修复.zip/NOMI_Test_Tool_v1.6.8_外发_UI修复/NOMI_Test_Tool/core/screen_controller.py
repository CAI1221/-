# core/screen_controller.py
# 安卓 ICS 屏幕控制器（不依赖 AutoMaster）:
#   - 比例坐标 tap/swipe（跨分辨率通用，配置写 0~1 的比例值）
#   - uiautomator dump 按控件文本/content-desc 定位点击
#   - am start 拉起应用（配置了 component）或 桌面图标按名字点击（兜底）
# 所有命令走 adb shell input / am / uiautomator，无第三方依赖。
import os
import re
import subprocess
import time
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Tuple

from core import app_log

DEFAULT_STEP_WAIT = 0.6   # 每步执行后的默认间隔（秒）
DUMP_FILE = "/sdcard/nomi_uidump.xml"


class ScreenController:
    """ICS 屏幕控制器（adb 直控）"""

    def __init__(self, log_cb=None):
        self._log_cb = log_cb
        self._screen_w = 0
        self._screen_h = 0

    # ==================== 日志 ====================
    def _log(self, msg: str):
        if self._log_cb:
            try:
                self._log_cb(msg)
            except Exception:
                pass

    # ==================== 基础 ====================
    @staticmethod
    def _adb_shell(cmd: str, timeout: int = 15) -> Tuple[bool, str]:
        try:
            app_log.log("安卓操作", f"执行: adb shell {cmd}")
            r = subprocess.run(f'adb shell "{cmd}"', shell=True,
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace",
                               timeout=timeout)
            out = ((r.stdout or "") + (r.stderr or "")).strip()
            app_log.log("安卓操作",
                        f"完成: rc={r.returncode} 结果={out[:120] or '(空)'}")
            return r.returncode == 0, out
        except Exception as e:
            return False, str(e)

    def get_screen_size(self, refresh: bool = False) -> Tuple[int, int]:
        """解析 wm size（Override 优先），返回 (宽, 高)"""
        if self._screen_w and self._screen_h and not refresh:
            return self._screen_w, self._screen_h
        ok, out = self._adb_shell("wm size")
        w = h = 0
        if ok and out:
            # 优先 Override size（用户/系统改过分辨率时生效）
            m = re.search(r"Override size:\s*(\d+)x(\d+)", out)
            if not m:
                m = re.search(r"Physical size:\s*(\d+)x(\d+)", out)
            if m:
                w, h = int(m.group(1)), int(m.group(2))
        self._screen_w, self._screen_h = w, h
        return w, h

    # ==================== 原子操作 ====================
    def tap_ratio(self, x: float, y: float) -> bool:
        """按比例点击（0~1），自动换算成当前分辨率像素坐标"""
        w, h = self.get_screen_size()
        if not w or not h:
            self._log("[控屏] 未获取到屏幕分辨率，先执行 wm size 失败?")
            return False
        px = max(0, min(w - 1, int(round(x * w))))
        py = max(0, min(h - 1, int(round(y * h))))
        ok, out = self._adb_shell(f"input tap {px} {py}")
        if not ok:
            self._log(f"[控屏] tap({px},{py}) 失败: {out[:100]}")
        return ok

    def double_tap_ratio(self, x: float, y: float) -> bool:
        """双击（地图放大常用），两次 tap 间隔 0.15 秒"""
        if not self.tap_ratio(x, y):
            return False
        time.sleep(0.15)
        return self.tap_ratio(x, y)

    def swipe_ratio(self, x1: float, y1: float, x2: float, y2: float,
                    ms: int = 300) -> bool:
        """按比例滑动（0~1 坐标 + 毫秒时长）"""
        w, h = self.get_screen_size()
        if not w or not h:
            return False
        args = [max(0, min(w - 1, int(round(x1 * w)))),
                max(0, min(h - 1, int(round(y1 * h)))),
                max(0, min(w - 1, int(round(x2 * w)))),
                max(0, min(h - 1, int(round(y2 * h))))]
        ok, out = self._adb_shell(f"input swipe {args[0]} {args[1]} "
                                  f"{args[2]} {args[3]} {int(ms)}")
        if not ok:
            self._log(f"[控屏] swipe{args} 失败: {out[:100]}")
        return ok

    def key(self, keycode: str) -> bool:
        """按键（KEYCODE_HOME / KEYCODE_BACK / 数字等）"""
        ok, out = self._adb_shell(f"input keyevent {keycode}")
        if not ok:
            self._log(f"[控屏] keyevent {keycode} 失败: {out[:100]}")
        return ok

    # ==================== 控件文本定位 ====================
    def _dump_ui(self) -> Optional[str]:
        """uiautomator dump，返回 XML 字符串"""
        self._adb_shell(f"rm -f {DUMP_FILE}", timeout=10)
        ok, _ = self._adb_shell("uiautomator dump " + DUMP_FILE, timeout=20)
        if not ok:
            # 部分设备不认参数顺序，退化为无参 dump（输出到默认路径）
            ok, _ = self._adb_shell("uiautomator dump", timeout=20)
            if not ok:
                return None
        ok, out = self._adb_shell("cat " + DUMP_FILE, timeout=15)
        self._adb_shell(f"rm -f {DUMP_FILE}", timeout=10)
        if ok and out.startswith("<"):
            return out
        return None

    @staticmethod
    def _bounds_center(bounds: str) -> Optional[Tuple[int, int]]:
        """解析 bounds="[x1,y1][x2,y2]" 中心点"""
        m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds or "")
        if not m:
            return None
        x1, y1, x2, y2 = (int(v) for v in m.groups())
        return (x1 + x2) // 2, (y1 + y2) // 2

    def tap_by_text(self, text: str, exact: bool = False) -> bool:
        """按控件文本/content-desc 定位并点击中心"""
        xml = self._dump_ui()
        if not xml:
            self._log(f"[控屏] uiautomator dump 失败，无法按文本点击 [{text}]")
            return False
        center = self._find_node_center(xml, text, exact)
        if not center:
            self._log(f"[控屏] 界面上未找到控件 [{text}]")
            return False
        ok, out = self._adb_shell(f"input tap {center[0]} {center[1]}")
        if not ok:
            self._log(f"[控屏] 点击 [{text}] 失败: {out[:100]}")
        return ok

    @staticmethod
    def _find_node_center(xml: str, text: str,
                          exact: bool) -> Optional[Tuple[int, int]]:
        """在 dump XML 中查找 text/content-desc 匹配的节点，返回中心坐标"""
        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            return None
        nodes = []
        for node in root.iter("node"):
            t = (node.get("text") or "").strip()
            d = (node.get("content-desc") or "").strip()
            hit = (t == text or d == text) if exact \
                else (text in t or text in d)
            if hit and node.get("bounds"):
                nodes.append(node)
        if not nodes:
            return None
        # 多个匹配时取面积最小的（通常是具体按钮而非外层容器）
        best, best_area = None, None
        for node in nodes:
            m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", node.get("bounds"))
            if not m:
                continue
            x1, y1, x2, y2 = (int(v) for v in m.groups())
            area = max(1, (x2 - x1) * (y2 - y1))
            if best_area is None or area < best_area:
                best, best_area = node, area
        # 注意: 不能用 `if best` 判断——XML Element 的真值在 Python 3.12 已弃用，
        # 叶子节点(无子元素)会被判为 False，导致文本点击静默失效
        return (ScreenController._bounds_center(best.get("bounds"))
                if best is not None else None)

    # ==================== 应用拉起 ====================
    def launch_component(self, component: str) -> bool:
        """am start 拉起 component（pkg/.Activity）"""
        ok, out = self._adb_shell(f"am start -n {component}")
        if not ok or ("Error" in out or "error" in out):
            self._log(f"[控屏] am start {component} 失败: {out[:120]}")
            return False
        return True

    def launch_app(self, app_name: str, component: str = "") -> bool:
        """拉起应用: 有 component 用 am start；否则回桌面按图标名点击"""
        if component:
            if self.launch_component(component):
                return True
            self._log(f"[控屏] component 启动失败，回退按图标点击 [{app_name}]")
        self.key("KEYCODE_HOME")
        time.sleep(1.0)
        return self.tap_by_text(app_name)

    # ==================== 步骤执行 ====================
    def run_steps(self, steps: List[Dict], apps: Optional[Dict] = None) -> List[str]:
        """执行操作步骤列表，返回失败步骤描述（空列表 = 全部成功）

        支持的 action:
          app        {app: 配置名}          拉起应用（apps 字典提供 component）
          app_name   {name: 应用名}         桌面图标按名点击
          home / back                       按键
          key        {code: KEYCODE_xx}
          tap        {x: 0~1, y: 0~1}       比例点击
          swipe      {x1,y1,x2,y2, ms}      比例滑动
          text_tap   {text: 文本}           按控件文本点击
          wait       {sec: 秒}
        """
        apps = apps or {}
        failures = []
        for i, step in enumerate(steps):
            action = str(step.get("action", "")).strip()
            try:
                if action == "app":
                    name = step.get("app", "")
                    comp = (apps.get(name) or {}).get("component", "")
                    if not self.launch_app(name, comp):
                        failures.append(f"步骤{i + 1} app:{name}")
                elif action == "app_name":
                    if not self.launch_app(step.get("name", "")):
                        failures.append(f"步骤{i + 1} app_name:{step.get('name')}")
                elif action == "home":
                    if not self.key("KEYCODE_HOME"):
                        failures.append(f"步骤{i + 1} home")
                elif action == "back":
                    if not self.key("KEYCODE_BACK"):
                        failures.append(f"步骤{i + 1} back")
                elif action == "key":
                    if not self.key(str(step.get("code", "KEYCODE_HOME"))):
                        failures.append(f"步骤{i + 1} key:{step.get('code')}")
                elif action == "tap":
                    if not self.tap_ratio(float(step.get("x", 0)),
                                          float(step.get("y", 0))):
                        failures.append(f"步骤{i + 1} tap")
                elif action == "double_tap":
                    if not self.double_tap_ratio(float(step.get("x", 0)),
                                                 float(step.get("y", 0))):
                        failures.append(f"步骤{i + 1} double_tap")
                elif action == "swipe":
                    if not self.swipe_ratio(
                            float(step.get("x1", 0)), float(step.get("y1", 0)),
                            float(step.get("x2", 0)), float(step.get("y2", 0)),
                            int(step.get("ms", 300))):
                        failures.append(f"步骤{i + 1} swipe")
                elif action == "text_tap":
                    if not self.tap_by_text(str(step.get("text", ""))):
                        failures.append(f"步骤{i + 1} text_tap:{step.get('text')}")
                elif action == "wait":
                    time.sleep(float(step.get("sec", 1)))
                    continue  # wait 本身不占用步骤间隔
                else:
                    failures.append(f"步骤{i + 1} 未知动作 {action}")
            except Exception as e:
                failures.append(f"步骤{i + 1} {action} 异常: {e}")
            time.sleep(DEFAULT_STEP_WAIT)
        return failures
