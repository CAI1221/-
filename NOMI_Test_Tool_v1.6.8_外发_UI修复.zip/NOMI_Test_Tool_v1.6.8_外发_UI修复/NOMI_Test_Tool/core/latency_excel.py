# core/latency_excel.py
# v1.6 音频端到端耗时分析 —— Excel 模板读写
#
# 约定（来自用户提供的模板 Nomi4-响应延时真人测试用例模版）:
#   sheet1 "汇总":      B2=唤醒平均值, B3=端到端平均值, B4..B18=各模块端到端平均值
#   sheet2 "唤醒TTS时延": 每行一个 Query; C/D/E = 第1/2/3遍的唤醒耗时(A)
#   sheet3 "端到端TTS时延": 每行一个 Query; E/F/G = 第1/2/3遍的端到端耗时(B)
#                        C/D 列(语义VAD/TopQuery) 工具不填; H/I 保留 Excel 公式
# 平均口径:
#   行平均  = 该行已填延时列的均值(忽略空, 等同 Excel AVERAGE)
#   模块平均= 该模块所有 Query 行的行平均的均值(等同模板 I 列公式逻辑)
#   B2     = 唤醒表 普通模块(TopQuery..天气) 全部行 行平均 的均值(不含GPT/Agent)
#   B3     = 端到端表 普通模块 模块平均 的均值(不含GPT/Agent, 用户口径=I列平均)
#   B4..B18 = 端到端表各模块(含GPT/Agent)的模块平均
import os
import re

import openpyxl

SHEET_SUMMARY = "汇总"
SHEET_WAKE = "唤醒TTS时延"
SHEET_END = "端到端TTS时延"

# 唤醒表: 第1/2/3遍 -> C/D/E 列
WAKE_PASS_COLS = {1: 3, 2: 4, 3: 5}      # 1-based Excel 列
# 端到端表: 第1/2/3遍 -> E/F/G 列
END_PASS_COLS = {1: 5, 2: 6, 3: 7}

# 汇总表: 各模块行标签(顺序对应 B4..B18)
SUMMARY_MODULES = [
    "Top Query", "车控", "电话", "媒体", "导航", "天气",
    "GPT媒体", "GPT快教快学", "GPT车控", "GPT趣玩表情", "GPT车书", "GPT开放域",
    "Agent车窗", "Agent媒体", "Agent动态NLG",
]
# 汇总行标签 -> 延时表 A 列 Domain 文本（两边书写存在差异，统一映射）
DOMAIN_ALIAS = {
    "Top Query": "TopQuery",
    "TopQuery": "TopQuery",
    "车控": "车控", "电话": "电话", "媒体": "媒体", "导航": "导航", "天气": "天气",
    "GPT媒体": "GPT媒体", "GPT快教快学": "GPT快教快学", "GPT车控": "GPT车控",
    "GPT趣玩表情": "GPT趣玩表情", "GPT车书": "GPT车书", "GPT开放域": "GPT开放域",
    "Agent车窗": "Agent车窗", "Agent媒体": "Agent媒体", "Agent动态NLG": "Agent动态NLG",
}
ORDINARY_MODULES = {"TopQuery", "车控", "电话", "媒体", "导航", "天气"}   # 不含 GPT/Agent
SUMMARY_FIRST_ROW = 4                          # B4 = Top Query


def detect_pass_from_filename(path: str) -> int:
    """从文件名识别遍次(1/2/3)。样例命名 1.qt / 2.mp4 / 第3遍.qt。

    规则: 匹配文件名里的数字(第*遍 优先，其次独立数字)；范围 1..3。
    识别不出返回 0（由 UI 让用户指定/确认）。
    """
    base = os.path.splitext(os.path.basename(str(path)))[0]
    m = re.search(r"第\s*([123])\s*遍", base)
    if m:
        return int(m.group(1))
    nums = re.findall(r"\d+", base)
    for tok in nums:
        if tok in ("1", "2", "3"):
            return int(tok)
    return 0


class LatencyExcel:
    """封装模板 Excel 的结构解析与延时回填"""

    def __init__(self, path: str):
        if not os.path.exists(path):
            raise FileNotFoundError(f"Excel 不存在: {path}")
        self.path = path
        self.wb = openpyxl.load_workbook(path)      # 保留公式
        for name in (SHEET_WAKE, SHEET_END, SHEET_SUMMARY):
            if name not in self.wb.sheetnames:
                raise ValueError(f"模板缺少 sheet: {name}（当前: {self.wb.sheetnames}）")
        self.wake_ws = self.wb[SHEET_WAKE]
        self.end_ws = self.wb[SHEET_END]
        self.summary_ws = self.wb[SHEET_SUMMARY]
        self._parse()

    # ---------------- 结构解析 ----------------
    def _parse(self):
        """解析两个延时表: 得到按顺序的 query 行列表与各模块行范围"""
        self.wake_rows = self._parse_query_rows(self.wake_ws)
        self.end_rows = self._parse_query_rows(self.end_ws)
        # 两个表结构应一致(顺序/模块相同)；以端到端表的行序作为“模板 Query 总顺序”
        self.all_rows = self.end_rows

    @staticmethod
    def _parse_query_rows(ws):
        """解析单张延时表: 返回 [{'row':int,'domain':str,'query':str}, ...]
        domain 取自 A 列(含合并单元格)；query 取 B 列非空；跳过 '统计' 行。
        """
        merged = {}
        for rng in ws.merged_cells.ranges:
            if rng.min_col <= 1 <= rng.max_col:
                merged[rng.min_row] = (rng.max_row, ws.cell(rng.min_row, 1).value)
        rows = []
        cur_domain = None
        for r in range(2, ws.max_row + 1):   # 跳过表头(第1行)
            bval = ws.cell(r, 2).value
            aval = ws.cell(r, 1).value
            # A 列给出新的 domain 标记(合并块顶部或独立行)
            if isinstance(aval, str) and aval.strip():
                txt = str(aval).strip()
                if txt != "统计":
                    cur_domain = txt
            elif r in merged:
                _, dom = merged[r]
                if isinstance(dom, str) and dom.strip() and dom.strip() != "统计":
                    cur_domain = dom.strip()
            if not (isinstance(bval, str) and bval.strip()):
                continue
            q = str(bval).strip()
            if q == "统计":
                continue
            if not cur_domain:
                cur_domain = ""
            rows.append({"row": r, "domain": cur_domain, "query": q})
        return rows

    # ---------------- 回填 ----------------
    def fill_pass(self, pass_no: int, values):
        """把一遍测量结果回填模板。

        values: [{'a_ms': int|None, 'b_ms': int|None}, ...]，下标 0..n 依序对应
                模板 Query 行(all_rows)。None/失败轮则跳过不写。
        pass_no: 1/2/3
        """
        if pass_no not in (1, 2, 3):
            raise ValueError("pass_no 必须是 1/2/3")
        wcol = WAKE_PASS_COLS[pass_no]
        ecol = END_PASS_COLS[pass_no]
        for i, v in enumerate(values):
            if i >= len(self.all_rows):
                break
            info = self.all_rows[i]
            a_ms = (v or {}).get("a_ms")
            b_ms = (v or {}).get("b_ms")
            # 唤醒耗时 -> 唤醒表 C/D/E
            wrow = self._wake_row_for(info)
            if a_ms is not None and wrow:
                self.wake_ws.cell(wrow, wcol).value = int(a_ms)
            # 端到端耗时 -> 端到端表 E/F/G
            if b_ms is not None:
                self.end_ws.cell(info["row"], ecol).value = int(b_ms)

    def _wake_row_for(self, info):
        """按 (domain, query) 在唤醒表里定位行号；找不到返回 None"""
        for w in self.wake_rows:
            if w["query"] == info["query"]:
                return w["row"]
        return None

    # ---------------- 汇总平均 ----------------
    @staticmethod
    def _row_avg(ws, row, cols):
        vals = []
        for c in cols:
            cell = ws.cell(row, c).value
            if isinstance(cell, (int, float)) and not isinstance(cell, bool):
                vals.append(float(cell))
        return (sum(vals) / len(vals)) if vals else None

    @staticmethod
    def _module_rows(parsed_rows, domain):
        return [p for p in parsed_rows if p["domain"] == domain]

    def _module_avg(self, ws, parsed_rows, domain, cols):
        """模块平均 = 该模块各 Query 行 行平均 的均值（等同模板 I 列公式逻辑）"""
        avgs = []
        for p in self._module_rows(parsed_rows, domain):
            a = self._row_avg(ws, p["row"], cols)
            if a is not None:
                avgs.append(a)
        return (sum(avgs) / len(avgs)) if avgs else None

    @staticmethod
    def _sheet_domain(label: str) -> str:
        """汇总行标签/别名 -> 延时表 A 列 Domain 文本"""
        return DOMAIN_ALIAS.get(str(label).strip(), str(label).strip())

    def end_module_avg(self, label):
        """端到端表 某模块平均（列 E/F/G）。label 可用汇总行标签或 Domain 原名"""
        domain = self._sheet_domain(label)
        return self._module_avg(self.end_ws, self.end_rows, domain, [5, 6, 7])

    def wake_module_avg(self, label):
        """唤醒表 某模块平均（列 C/D/E）"""
        domain = self._sheet_domain(label)
        return self._module_avg(self.wake_ws, self.wake_rows, domain, [3, 4, 5])

    def compute_summary_values(self):
        """按确认口径计算汇总数值，返回 {'b2':x,'b3':x,'modules':{标签:x}}

        口径（与用户最终确认一致）:
          - 每行行平均 = 该行已填延时列均值(等同 Excel AVERAGE, 忽略空)
          - 每模块平均 = 该模块各 Query 行行平均的均值(=模板 I 列公式逻辑)
          - B4..B18 = 端到端表各模块(含GPT/Agent)模块平均
          - B3      = 端到端 普通模块(TopQuery/车控/电话/媒体/导航/天气)
                      模块平均的均值（用户: 注意是 I 列的平均值）
          - B2      = 唤醒表 普通模块 全部 Query 行 C/D/E 已填值总平均(不含GPT/Agent)
        """
        # 端到端各模块平均(含GPT/Agent)
        end_mods = {}
        for label in SUMMARY_MODULES:
            end_mods[label] = self.end_module_avg(label)
        # B2 = 唤醒表 普通模块全部已填延时(C/D/E)总平均
        wake_cells = []
        for p in self.wake_rows:
            if p["domain"] not in ORDINARY_MODULES:
                continue
            for c in (3, 4, 5):
                cell = self.wake_ws.cell(p["row"], c).value
                if isinstance(cell, (int, float)) and not isinstance(cell, bool):
                    wake_cells.append(float(cell))
        b2 = (sum(wake_cells) / len(wake_cells)) if wake_cells else None
        # B3 = 端到端普通模块模块平均的均值 (不含 GPT/Agent)
        ord_end = []
        for label in SUMMARY_MODULES[:6]:
            v = end_mods.get(label)
            if v is not None:
                ord_end.append(v)
        b3 = (sum(ord_end) / len(ord_end)) if ord_end else None
        return {"b2": b2, "b3": b3, "modules": end_mods}

    def write_summary(self, values=None):
        """把汇总平均值写入 sheet1 的 B 列。values=None 时自动重算。"""
        if values is None:
            values = self.compute_summary_values()
        if values.get("b2") is not None:
            self.summary_ws.cell(2, 2).value = round(float(values["b2"]), 1)
        if values.get("b3") is not None:
            self.summary_ws.cell(3, 2).value = round(float(values["b3"]), 1)
        for idx, label in enumerate(SUMMARY_MODULES):
            row = SUMMARY_FIRST_ROW + idx
            v = values.get("modules", {}).get(label)
            if v is not None:
                self.summary_ws.cell(row, 2).value = round(float(v), 1)

    # ---------------- 保存 ----------------
    def save(self, out_path=None):
        """保存；默认在同目录生成 <原名>_已填.xlsx，避免覆盖模板"""
        if not out_path:
            root, ext = os.path.splitext(self.path)
            out_path = f"{root}_已填.xlsx"
        self.wb.save(out_path)
        return out_path


def round_table_rows(template_path: str):
    """便捷接口：返回模板的 Query 顺序清单（domain, query, 是否普通模块）"""
    xl = LatencyExcel(template_path)
    return [
        {"domain": p["domain"], "query": p["query"],
         "ordinary": p["domain"] in ORDINARY_MODULES}
        for p in xl.all_rows
    ]
