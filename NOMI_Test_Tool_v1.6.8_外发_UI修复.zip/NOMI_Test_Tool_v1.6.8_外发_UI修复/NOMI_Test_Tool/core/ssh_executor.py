# core/ssh_executor.py
# SSH 客户端封装：基于 paramiko
#   - 断线重连
#   - 后台命令执行（channel 保活，防止 top2 被 SIGHUP 杀死）
#   - SFTP 单文件拉取（top2 日志）
import os
from typing import Optional, Tuple

import paramiko

from core import app_log


class SSHClientWrapper:
    """复用 SSH 连接，支持断线重连和 SFTP 拉取文件"""

    def __init__(self):
        self._client: Optional[paramiko.SSHClient] = None
        self._host = "192.0.2.2"
        self._user = "root"
        self._password = "CHANGE_ME"

    def configure(self, host: str, user: str, password: str):
        """配置 SSH 连接参数"""
        self._host = host
        self._user = user
        self._password = password

    def connect(self, timeout: int = 10) -> bool:
        """建立或重建 SSH 连接"""
        if self._client is not None:
            if self.is_connected():
                return True
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None

        try:
            app_log.log("QNX", f"SSH 登录: {self._user}@{self._host}:22")
            self._client = paramiko.SSHClient()
            self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self._client.connect(
                hostname=self._host,
                username=self._user,
                password=self._password,
                timeout=timeout,
                allow_agent=False,
                look_for_keys=False,
            )
            try:
                # 保活: 防止车机网络把空闲/长会话静默断开（top2 整轮跑约 10 分钟）
                self._client.get_transport().set_keepalive(15)
            except Exception:
                pass
            app_log.log("QNX", "SSH 登录成功")
            return True
        except Exception as e:
            self._client = None
            app_log.log("QNX", f"SSH 登录失败: {e}")
            raise Exception(f"SSH 连接失败 ({self._host}): {e}")

    def exec(self, cmd: str, timeout: int = 30,
             get_pty: bool = False) -> Tuple[bool, str]:
        """执行远程命令并等待返回，返回 (成功, 输出)

        :param get_pty: 申请伪终端。QNX 的 top2 交互模式必须在有 TTY 的会话
            下才能进入 cbreak 模式，否则输出 "Unable to enter cbreak mode"
            直接失败；本工具用它与采集命令保持一致。申请伪终端后远端
            stderr 会并入 stdout，只读 stdout 即可。
        """
        app_log.log("QNX", f"执行: {cmd}")
        if self._client is None:
            app_log.log("QNX", "跳过: SSH 未连接")
            return False, "SSH 未连接"
        try:
            _, stdout, stderr = self._client.exec_command(
                cmd, timeout=timeout, get_pty=get_pty)
            if get_pty:
                output = stdout.read().decode(errors='replace').strip()
                return (True, output) if output else (True, "")
            output = stdout.read().decode(errors='replace').strip()
            error = stderr.read().decode(errors='replace').strip()
            # QNX 部分命令正常输出走 stderr，只要有内容即视为有结果
            if output:
                app_log.log("QNX", f"执行完成: {(output or '')[:200]}")
                return True, output
            if error:
                app_log.log("QNX", f"执行完成(stderr): {(error or '')[:200]}")
                return False, error
            app_log.log("QNX", "执行完成: (无输出)")
            return True, ""
        except Exception as e:
            self._client = None
            app_log.log("QNX", f"执行异常: {e}")
            return False, f"SSH 执行异常: {e}"

    def exec_background_keep(self, cmd: str, get_pty: bool = False):
        """在独立 channel 上执行远程命令并保持 channel 打开，返回 channel。

        用途: top2 采集。命令**不加 & 后台化**，让 top2 作为该 channel 的
        前台进程运行（伪终端模式下 stdin 才是 TTY；若加 &，非交互 shell 会
        把后台任务 stdin 指到 /dev/null，top2 交互模式会报 cbreak 错误）。
        停止采集时先发 slay 再 close channel。

        :param get_pty: 申请伪终端。speech 进程 top2 走交互刷新模式时需要。
        """
        if self._client is None:
            return None
        app_log.log("QNX", f"后台执行(保持channel): {cmd}")
        try:
            transport = self._client.get_transport()
            if transport is None:
                return None
            channel = transport.open_session()
            if get_pty:
                channel.get_pty()
            channel.exec_command(cmd)
            return channel
        except Exception:
            return None

    def is_connected(self) -> bool:
        """检查连接是否活跃"""
        if self._client is None:
            return False
        try:
            transport = self._client.get_transport()
            if transport is None or not transport.is_active():
                return False
            _, stdout, _ = self._client.exec_command("echo ok", timeout=5)
            return 'ok' in stdout.read().decode()
        except Exception:
            return False

    # ==================== SFTP ====================
    def sftp_get_file(self, remote_path: str, local_path: str) -> Tuple[bool, str]:
        """通过 SFTP 拉取单个文件到本地"""
        if self._client is None:
            return False, "SSH 未连接"
        app_log.log("SFTP", f"拉取文件: {remote_path} -> {local_path}")
        sftp = None
        try:
            sftp = self._client.open_sftp()
            local_dir = os.path.dirname(local_path)
            if local_dir:
                os.makedirs(local_dir, exist_ok=True)
            sftp.get(remote_path, local_path)
            return True, "OK"
        except Exception as e:
            return False, str(e)
        finally:
            if sftp:
                try:
                    sftp.close()
                except Exception:
                    pass

    def sftp_stat_size(self, remote_path: str) -> int:
        """返回远端文件大小（字节），失败返回 -1"""
        if self._client is None:
            return -1
        sftp = None
        try:
            sftp = self._client.open_sftp()
            return int(sftp.stat(remote_path).st_size)
        except Exception:
            return -1
        finally:
            if sftp:
                try:
                    sftp.close()
                except Exception:
                    pass

    def sftp_get_dir_recursive(self, remote_dir: str,
                               local_dir: str) -> Tuple[bool, str]:
        """递归拉取远端目录到本地（等同 scp -r），返回 (成功, 说明)"""
        if self._client is None:
            return False, "SSH 未连接"
        app_log.log("SFTP", f"拉取目录: {remote_dir} -> {local_dir} (递归)")
        sftp = None
        fetched = 0
        try:
            sftp = self._client.open_sftp()
            os.makedirs(local_dir, exist_ok=True)
            sftp.stat(remote_dir)      # 目录不存在会抛异常

            def _walk(rpath: str, lpath: str):
                nonlocal fetched
                for attr in sftp.listdir_attr(rpath):
                    rsub = f"{rpath.rstrip('/')}/{attr.filename}"
                    lsub = os.path.join(lpath, attr.filename)
                    if attr.filename in (".", ".."):
                        continue
                    if attr.st_mode is not None and \
                            attr.st_mode & 0o170000 == 0o040000:  # S_IFDIR
                        os.makedirs(lsub, exist_ok=True)
                        _walk(rsub, lsub)
                    else:
                        os.makedirs(lpath, exist_ok=True)
                        sftp.get(rsub, lsub)
                        fetched += 1

            _walk(remote_dir, local_dir)
            if fetched == 0:
                return False, f"远端目录为空: {remote_dir}"
            return True, f"{local_dir}（{fetched} 个文件）"
        except Exception as e:
            return False, str(e)
        finally:
            if sftp:
                try:
                    sftp.close()
                except Exception:
                    pass

    def close(self):
        """关闭 SSH 连接"""
        if self._client:
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None
