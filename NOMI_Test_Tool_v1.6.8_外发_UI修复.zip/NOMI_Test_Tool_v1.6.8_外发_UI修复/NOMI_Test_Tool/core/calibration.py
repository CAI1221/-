# core/calibration.py - 端到端耗时「校准训练」评估核心（v1.6.8）
#
# 用途: 读取「录像/录音 + 人工确认完成的响应时延 Excel」样本集，
# 逐个样本重跑自动分析(独立子进程 latency_worker.py，不污染 GUI 进程)，
# 与人工 A唤醒/B端到端 逐 Query 比对，输出命中率与逐 Query 偏差，
# 供人工确认后做参数/逐 Query 偏移校准。
#
# 纯逻辑、无 Qt 依赖；Excel 读取复用 core.latency_excel 的结构定义。
import os
import json
import subprocess
import sys
import tempfile

MEDIA_EXTS = (".mp4", ".qt", ".mov", ".avi", ".mkv",
              ".wav", ".m4a", ".mp3", ".aac", ".flac")


def default_dataset_dir(work_dir: str) -> str:
    """默认训练集目录: <work_dir>/audio/训练数据集"""
    return os.path.join(str(work_dir or ""), "audio", "训练数据集")


def _find_media(folder: str):
    """子目录内任选一个可分析媒体（优先体积大的录像/录音文件）"""
    hits = []
    for f in os.listdir(folder):
        p = os.path.join(folder, f)
        if os.path.isfile(p) and f.lower().endswith(MEDIA_EXTS):
            try:
                hits.append((os.path.getsize(p), p))
            except OSError:
                continue
    if not hits:
        return ""
    hits.sort(reverse=True)
    return hits[0][1]


def _find_golden_xlsx(folder: str):
    """找人工确认表：优先文件名含「完成」，否则第一个 .xlsx"""
    xlsx = []
    for f in sorted(os.listdir(folder)):
        if f.lower().endswith(".xlsx"):
            xlsx.append(os.path.join(folder, f))
    if not xlsx:
        return ""
    for p in xlsx:
        if "完成" in os.path.basename(p):
            return p
    return xlsx[0]


def scan_samples(root: str):
    """扫描 <root>/<样本子目录>，返回 [{'name','media','excel','pass_no'}]"""
    if not root or not os.path.isdir(root):
        return []
    from core.latency_excel import detect_pass_from_filename
    out = []
    for name in sorted(os.listdir(root)):
        d = os.path.join(root, name)
        if not os.path.isdir(d):
            continue
        media = _find_media(d)
        excel = _find_golden_xlsx(d)
        if not media or not excel:
            continue
        pass_no = detect_pass_from_filename(media) or 1
        out.append({"name": name, "media": media, "excel": excel,
                    "pass_no": pass_no})
    return out


def read_golden(excel_path: str, pass_no: int):
    """读取人工真值: 按模板行序返回 [{'domain','query','a','b'}, ...]"""
    from core.latency_excel import (LatencyExcel, WAKE_PASS_COLS,
                                    END_PASS_COLS)
    le = LatencyExcel(excel_path)
    wcol = WAKE_PASS_COLS.get(pass_no, 3)
    ecol = END_PASS_COLS.get(pass_no, 5)
    gold = []
    for info in le.all_rows:
        a = le.wake_ws.cell(le._wake_row_for(info), wcol).value
        b = le.end_ws.cell(info["row"], ecol).value
        gold.append({
            "domain": info["domain"],
            "query": info["query"],
            "a": a if isinstance(a, (int, float)) and not isinstance(a, bool) else None,
            "b": b if isinstance(b, (int, float)) and not isinstance(b, bool) else None,
        })
    return gold


def _run_worker(media_path: str, template_path: str, model: str,
                language: str, gap_ms: int, timeout: int):
    """以子进程跑一次自动分析，返回结果 dict（无 Qt / 无模型同进程加载）"""
    worker = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "latency_worker.py")
    with tempfile.TemporaryDirectory() as td:
        args_f = os.path.join(td, "args.json")
        res_f = os.path.join(td, "res.json")
        with open(args_f, "w", encoding="utf-8") as f:
            json.dump({"media_path": media_path,
                       "template_path": template_path,
                       "model_name": model,
                       "language": language,
                       "wake_path": "",
                       "wake_text": "",
                       "gap_ms": int(gap_ms or 150)}, f,
                      ensure_ascii=False)
        r = subprocess.run([sys.executable, worker, args_f, res_f],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout)
        if not os.path.exists(res_f):
            raise RuntimeError((r.stderr or r.stdout or "")[-500:])
        with open(res_f, "r", encoding="utf-8") as f:
            data = json.load(f)
    return data


def evaluate_sample(sample: dict, model: str = "tiny",
                    language: str = "zh", gap_ms: int = 150,
                    tol_a_ms: int = 80, tol_b_ms: int = 120,
                    timeout: int = 1200, emit=None):
    """对单个样本评估: 自动值 vs 人工值。

    返回 dict: name / rows(逐Query明细) / n / a_ok / b_ok / combined
    """
    def log(m):
        if emit:
            emit(m)

    log(f"[{sample['name']}] 自动分析 {os.path.basename(sample['media'])} ...")
    res = _run_worker(sample["media"], sample["excel"], model,
                      language, gap_ms, timeout=timeout)
    gold = read_golden(sample["excel"], sample["pass_no"])
    rows_by_q = {}
    results = res.get("results") or []
    rows = res.get("rows") or []
    for info, r in zip(rows, results):
        rows_by_q.setdefault(str(info.get("query", "")), r)
    detail = []
    n_a = n_b = a_ok = b_ok = n_both = both_ok = 0
    for g in gold:
        r = rows_by_q.get(str(g["query"])) or {}
        auto_a = r.get("a_ms")
        auto_b = r.get("b_ms")
        if not isinstance(auto_a, (int, float)) or auto_a != auto_a:
            auto_a = None
        if not isinstance(auto_b, (int, float)) or auto_b != auto_b:
            auto_b = None
        hit_a = hit_b = ""
        if g["a"] is not None:
            n_a += 1
            hit_a = "命中" if auto_a is not None and abs(auto_a - g["a"]) <= tol_a_ms else "偏差"
            a_ok += hit_a == "命中"
        if g["b"] is not None:
            n_b += 1
            hit_b = "命中" if auto_b is not None and abs(auto_b - g["b"]) <= tol_b_ms else "偏差"
            b_ok += hit_b == "命中"
        if g["a"] is not None and g["b"] is not None:
            n_both += 1
            both_ok += (hit_a == "命中" and hit_b == "命中")
        detail.append({
            "query": g["query"], "status": (r or {}).get("status", "miss"),
            "g_a": g["a"], "a": auto_a,
            "da": (auto_a - g["a"]) if (g["a"] is not None and auto_a is not None) else None,
            "g_b": g["b"], "b": auto_b,
            "db": (auto_b - g["b"]) if (g["b"] is not None and auto_b is not None) else None,
            "hit_a": hit_a, "hit_b": hit_b,
        })
    return {"name": sample["name"], "rows": detail,
            "n": len(detail), "n_a": n_a, "n_b": n_b,
            "a_ok": a_ok, "b_ok": b_ok,
            "n_both": n_both, "both_ok": both_ok}


def summarize(samples_eval, tol_a_ms=80, tol_b_ms=120):
    """汇总所有样本并给出偏差建议（后续可写回 config 的候选参数）"""
    ta = sum(e["n_a"] for e in samples_eval)
    tb = sum(e["n_b"] for e in samples_eval)
    oa = sum(e["a_ok"] for e in samples_eval)
    ob = sum(e["b_ok"] for e in samples_eval)
    return {
        "samples": len(samples_eval),
        "n_a": ta, "a_ok": oa, "a_rate": (oa / ta) if ta else None,
        "n_b": tb, "b_ok": ob, "b_rate": (ob / tb) if tb else None,
        "tol_a_ms": tol_a_ms, "tol_b_ms": tol_b_ms,
    }
