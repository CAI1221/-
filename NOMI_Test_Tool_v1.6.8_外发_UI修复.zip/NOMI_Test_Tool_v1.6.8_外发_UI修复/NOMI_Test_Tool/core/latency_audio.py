# core/latency_audio.py
# v1.6 音频端到端耗时分析 —— 音频/视频解码 + 能量曲线 + VAD 分段 + 端点精修
# 纯逻辑模块（不依赖 Qt），便于单元测试与后续 UI 复用。
#
# 术语约定:
#   segment  = 一个语音活动段（能量明显高于噪声底的连续区间）
#   onset    = 该段起点（第一帧有意义能量处）
#   offset   = 该段终点（尾音回落处）
#
# 阈值策略: dB 域——噪声底取包络低分位(noise_q)，语音阈值 = 噪声底 + margin_db。
# 该策略对本项目"车内有底噪、人声与TTS音量不一"的素材比线性倍率稳定得多。
import os
import shutil
import subprocess

import numpy as np

try:
    import imageio_ffmpeg
    _FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
except Exception:
    _FFMPEG = shutil.which("ffmpeg") or ""

DEFAULT_TARGET_SR = 44100


# ==================== 解码 ====================
def ffmpeg_exe() -> str:
    """返回可用 ffmpeg 路径；无则返回空串（上层提示）"""
    return _FFMPEG or ""


def decode_to_mono(path: str, target_sr: int = DEFAULT_TARGET_SR):
    """把任意音频/视频文件解码为单声道 float32 [-1,1]，返回 (sr, samples)"""
    if not _FFMPEG:
        raise RuntimeError("未找到 ffmpeg，无法解码音/视频（请安装 imageio-ffmpeg）")
    if not os.path.exists(path):
        raise RuntimeError(f"文件不存在: {path}")
    cmd = [_FFMPEG, "-hide_banner", "-loglevel", "error",
           "-i", path, "-vn", "-ac", "1",
           "-ar", str(target_sr), "-f", "f32le", "pipe:1"]
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=3600)
    except subprocess.TimeoutExpired:
        raise RuntimeError("ffmpeg 解码超时（文件过大？）")
    if proc.returncode != 0:
        err = proc.stderr.decode("utf-8", "replace").strip()[:500]
        raise RuntimeError(f"ffmpeg 解码失败: {err}")
    x = np.frombuffer(proc.stdout, dtype="<f4").astype(np.float32)
    if x.size == 0:
        raise RuntimeError("音轨为空（文件无音频流？）")
    return target_sr, x


# ==================== 能量包络 ====================
def rms_envelope(x, sr, win_s=0.020, hop_s=0.005):
    """滑动 RMS 包络，返回 (times_seconds, rms)

    帧长默认 20ms，步进 5ms（端点粗定位粒度 < 30ms 要求）。
    v1.6.3: 分块流式计算，避免一次性构造 nframes x win 帧矩阵。
    v1.6.6: 块内前缀和 O(n) 计算窗口能量，超长录音(60min+)从十几秒
            降到亚秒级，显著降低分析期的 CPU 占用与整机卡顿。
    """
    x = np.asarray(x)
    win = max(1, int(round(win_s * sr)))
    hop = max(1, int(round(hop_s * sr)))
    n = x.size
    if n < win:
        return np.array([0.0]), np.array([0.0])
    nframes = 1 + max(0, (n - win) // hop)
    rms = np.empty(nframes, dtype=np.float64)
    BLK = 1 << 20                      # 样本块（~24s @44.1k）
    b0 = 0
    while b0 < n:
        b1 = min(n, b0 + BLK)
        seg = x[b0:b1].astype(np.float64, copy=False)
        cs = np.empty(len(seg) + 1, dtype=np.float64)
        cs[0] = 0.0
        np.cumsum(seg * seg, out=cs[1:])
        # 完全落在本块内的帧: 起始 s ∈ [b0, b1-win]
        lo_f = (b0 + hop - 1) // hop
        hi_f = min(nframes - 1, (b1 - win) // hop)
        if lo_f <= hi_f:
            fs = (np.arange(lo_f, hi_f + 1, dtype=np.int64)) * hop
            rms[lo_f:hi_f + 1] = np.sqrt(
                (cs[fs - b0 + win] - cs[fs - b0]) / float(win))
        # 窗口跨块边界的少量帧（<= win/hop 个）直接精确求和
        c_f = max(lo_f, hi_f + 1)
        c_hi = min(nframes - 1, (b1 - 1) // hop)
        if c_f <= c_hi:
            for f in range(c_f, c_hi + 1):
                s = f * hop
                rms[f] = np.sqrt(float(
                    np.mean((x[s:s + win].astype(np.float64)) ** 2)))
        b0 = b1
    times = (np.arange(nframes, dtype=np.float64) * hop + win / 2) / sr
    return times, rms


def rms_db_of(rms):
    """RMS 转 dB（避免 0 值 -inf，加极小底）"""
    return 20.0 * np.log10(rms + 1e-12)


def noise_floor_db(rms, noise_q=0.10) -> float:
    """噪声底(dB)：包络低分位（假设语音占比 < noise_q）"""
    if rms.size == 0:
        return -60.0
    db = rms_db_of(rms)
    return float(np.percentile(db, noise_q * 100.0))


def speech_threshold_from_noise(noise_db, margin_db=12.0) -> float:
    """噪声底(dB)+裕量(dB) -> 线性幅度阈值"""
    return float(10.0 ** ((noise_db + margin_db) / 20.0))


# ==================== VAD 分段 ====================
def vad_segments(x, sr, margin_db=12.0, win_s=0.020, hop_s=0.005,
                 hang_s=0.04, min_gap_s=0.30, min_len_s=0.06,
                 noise_q=0.10, merge_gap_s=None):
    """dB 域语音活动检测。

    返回 [(start_s, end_s), ...] 已做:
      - 悬挂(hangover): 低于阈值短于 hang_s 的回落不算断点
      - 间隙合并: 两段间隔 < merge_gap_s(默认=min_gap_s) 时合成一段
      - 过滤 < min_len_s 的毛刺段
    """
    if x is None or x.size == 0:
        return []
    sr = int(sr)
    times, rms = rms_envelope(x, sr, win_s=win_s, hop_s=hop_s)
    thr = speech_threshold_from_noise(noise_floor_db(rms, noise_q), margin_db)
    over = rms >= thr
    merge_gap = merge_gap_s if merge_gap_s is not None else min_gap_s
    if not over.any():
        return []

    # v1.6.6: 不再逐帧 Python 状态机（长录音上百万帧会卡数秒），
    # 改为“过阈连续区(run)级”处理：仅当静音间隙 < hang_s 才视为同一活动。
    ov = over.astype(np.int8)
    d = np.diff(ov, prepend=0, append=0)
    s_idx = np.flatnonzero(d == 1)
    e_idx = np.flatnonzero(d == -1)        # run 结束后的下一帧（exclusive）
    segs = []
    i = 0
    nruns = len(s_idx)
    while i < nruns:
        j = i
        # 间隙 < hang_s 的相邻 run 合并为同一活动段
        while (j + 1 < nruns and
               times[s_idx[j + 1]] - times[e_idx[j]] < hang_s):
            j += 1
        start_t = float(times[s_idx[i]])
        ef = int(e_idx[j])
        end_t = float(times[ef]) if ef < len(times) else float(times[-1])
        if (end_t - start_t) >= min_len_s:
            segs.append((start_t, end_t))
        i = j + 1
    # 间隙合并
    merged = []
    for s, e in segs:
        if merged and (s - merged[-1][1]) < merge_gap:
            merged[-1] = (merged[-1][0], e)
        else:
            merged.append((s, e))
    return merged


# ==================== 端点精修 ====================
def onset_offset(x, sr, seg_start_s, seg_end_s, thr,
                 probe_win_s=0.003):
    """在语音活动段内精修端点（3ms 探针窗，贴近听感第一帧）

    返回 (onset_s, offset_s)。
    """
    n = x.size
    s0 = max(0, int(round(seg_start_s * sr)))
    e0 = min(n, int(round(seg_end_s * sr)))
    if e0 - s0 < 32:
        return seg_start_s, seg_end_s
    w = max(2, int(round(probe_win_s * sr)))
    reg = x[s0:e0].astype(np.float64)
    step = max(1, w // 2)
    if reg.size < w:
        return seg_start_s, seg_end_s
    starts = np.arange(0, reg.size - w + 1, step)
    # v1.6.6: 前缀和计算探针窗能量（替代构造 frames 矩阵）
    cs = np.empty(len(reg) + 1, dtype=np.float64)
    cs[0] = 0.0
    np.cumsum(reg * reg, out=cs[1:])
    lev = np.sqrt((cs[starts + w] - cs[starts]) / float(w))
    over = lev >= thr
    if not over.any():
        return seg_start_s, seg_end_s
    # 取最长过阈连续区间（防噪声毛刺）
    best = None
    cur = None
    for i in range(len(over)):
        if over[i]:
            if cur is None:
                cur = [i, i]
            else:
                cur[1] = i
        else:
            if cur is not None:
                if best is None or (cur[1] - cur[0]) > (best[1] - best[0]):
                    best = cur
                cur = None
    if cur is not None and (best is None or (cur[1] - cur[0]) > (best[1] - best[0])):
        best = cur
    if best is None:
        return seg_start_s, seg_end_s
    onset_s = (s0 + starts[best[0]]) / sr
    offset_s = (s0 + starts[best[1]] + w) / sr
    # 极短命中视为噪声
    if (offset_s - onset_s) < 0.015:
        return seg_start_s, seg_end_s
    return onset_s, offset_s


def refine_segments(x, sr, segs, margin_db=12.0, noise_q=0.10):
    """对 VAD 粗段逐段精修端点，返回精修后段列表。"""
    if not segs:
        return []
    _, rms = rms_envelope(x, sr)
    thr = speech_threshold_from_noise(noise_floor_db(rms, noise_q), margin_db)
    out = []
    for s, e in segs:
        os_, oe = onset_offset(x, sr, s, e, thr)
        out.append((os_, oe))
    return out


# ==================== 时长工具 ====================
def ms(dur_s: float) -> int:
    """秒 -> 毫秒整数（四舍五入，远离 0.5 边界时同模板样例风格）"""
    return int(dur_s * 1000.0 + (0.5 if dur_s >= 0 else -0.5))


# ==================== WAV 写出 / 校准音 / 模板互相关 ====================
# v1.6.2 新增: 校准音(1kHz)生成与检测扣除、唤醒词模板互相关定位。
# 全部纯 numpy，无额外第三方依赖（WAV 用标准库 wave 写 16bit PCM）。
def write_wav_mono(path: str, sr: int, x):
    """把 float32 [-1,1] 单声道样本写成 16bit PCM wav（标准库，无依赖）"""
    import wave
    arr = np.clip(np.rint(np.asarray(x, dtype=np.float64) * 32767.0),
                  -32768.0, 32767.0).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(sr))
        w.writeframes(arr.tobytes())


def gen_cal_tone(dur_s: float = 1.0, sr: int = 44100,
                 freq: float = 1000.0) -> np.ndarray:
    """生成 1 秒 1kHz 正弦校准音（5ms 淡入淡出防爆音），float32"""
    n = max(1, int(round(dur_s * sr)))
    t = np.arange(n, dtype=np.float64) / sr
    x = np.sin(2.0 * np.pi * freq * t)
    fade = max(1, int(round(0.005 * sr)))
    env = np.ones(n, dtype=np.float64)
    env[:fade] = np.linspace(0.0, 1.0, fade)
    env[-fade:] = np.linspace(1.0, 0.0, fade)
    return (x * env).astype(np.float32)


def _fft_dot_long_short(long_x: np.ndarray, short_t: np.ndarray) -> np.ndarray:
    """线性相关: dot[k] = sum_j long_x[k+j] * short_t[j]（k=0..len-m）

    实现: c = irfft(rfft(x) * conj(rfft(t))) 时 c[k] 即模板起点在 k 的点积
    （已用数值样例验证: 小窗口与大窗口结果均与直接求和一致）。
    """
    m = short_t.size
    n = long_x.size
    if n <= m:
        return np.zeros(1, dtype=np.float64)
    L = 1 << ((n + m - 1).bit_length())
    Xf = np.fft.rfft(long_x.astype(np.float64), n=L)
    Tf = np.fft.rfft(short_t.astype(np.float64), n=L)
    corr = np.fft.irfft(Xf * np.conj(Tf), n=L)
    # 只保留模板能完整放入 x 的位置
    return corr[:n - m + 1]


def _window_energy(long_x: np.ndarray, m: int) -> np.ndarray:
    """滑动窗平方和: en[k] = sum_j long_x[k+j]^2, 长度 len(long_x)-m+1"""
    n = long_x.size
    if n <= m:
        return np.ones(1, dtype=np.float64)
    sq = long_x.astype(np.float64) ** 2
    cs = np.concatenate(([0.0], np.cumsum(sq)))
    return cs[m:] - cs[:-m]


def match_template_peaks(x, sr, templ, thr: float = 0.40,
                         min_gap_s: float = 0.8,
                         chunk_s: float = 20.0):
    """在整段录音 x 中定位固定模板音频 templ 的每次出现（归一化互相关）。

    参数:
      x       录音 float32 单声道（采样率 sr）
      sr      录音采样率
      templ   模板音频 float32（任意采样率，内部重采样到 sr）
      thr     相关峰阈值（归一化互相关系数）
      min_gap_s 两次出现之间的最小间隔（避免同一声多次命中）
    返回: [{'start_s','end_s','score'}, ...] 按出现时间升序。
    """
    if x is None or templ is None:
        return []
    x = np.asarray(x, dtype=np.float32)
    templ = np.asarray(templ, dtype=np.float32)
    if x.size == 0 or templ.size == 0 or x.size <= templ.size:
        return []
    m = templ.size
    # 模板需与录音同采样率；请用 load_template(path, sr) 读模板
    if sr is None:
        return []
    t2 = float(np.dot(templ, templ))
    if t2 <= 1e-12:
        return []
    occ = []          # (score, start_sample)
    stride = max(1, int(round(chunk_s * sr)))
    n = x.size - m + 1
    pos = 0
    while pos < n:
        seg_len = min(stride + m, n - pos)      # 多取 m 保证跨块命中
        if seg_len <= m:
            break
        seg = x[pos:pos + seg_len]
        dot = _fft_dot_long_short(seg, templ)
        denom = np.sqrt(np.maximum(_window_energy(seg, m) * t2, 1e-30))
        score = dot / denom
        k_len = min(stride, score.size)
        # 块内局部极大 + 超过阈值
        for k in range(1, k_len - 1):
            if (score[k] >= thr and score[k] >= score[k - 1]
                    and score[k] >= score[k + 1]):
                occ.append((float(score[k]), pos + k))
        pos += stride
    if not occ:
        return []
    # 贪心去重: 按分数降序选取，剔除与已选重叠(间隔<min_gap)的峰
    min_sep = max(1, int(round(min_gap_s * sr)))
    occ.sort(key=lambda v: v[0], reverse=True)
    picked = []
    for sc, s0 in occ:
        if all(abs(s0 - p0) >= min_sep for _, p0 in picked):
            picked.append((sc, s0))
    picked.sort(key=lambda v: v[1])
    return [{"start_s": float(s0) / sr, "end_s": float(s0 + m) / sr,
             "score": float(sc)} for sc, s0 in picked]


def detect_cal_tone(x, sr, dur_s: float = 1.0, freq: float = 1000.0,
                    search_s: float = 4.0, thr: float = 0.30):
    """在录音开头(0..search_s)定位 1kHz 校准音，返回 {'offset_s','score'} 或 None。

    校准音由电脑在录像开始时播放，经空气传播被手机录到；其“到达时刻”
    即 0.003~0.01s 量级的固定传播偏置，后续 A/B 按需扣除。
    用 |相关系数| 找峰（容忍相位翻转），并加能量门限排除纯静音误峰。
    """
    if x is None or sr is None:
        return None
    x = np.asarray(x, dtype=np.float32)
    if x.size == 0:
        return None
    ref = gen_cal_tone(dur_s=dur_s, sr=sr, freq=freq)
    nwin = max(1, int(round(search_s * sr)))
    seg = x[:min(x.size, nwin)]
    if seg.size <= ref.size:
        return None
    dot = _fft_dot_long_short(seg, ref)
    win = _window_energy(seg, ref.size)
    t2 = float(np.dot(ref, ref))
    if t2 <= 1e-12:
        return None
    denom = np.sqrt(np.maximum(win * t2, 1e-30))
    score = np.abs(dot) / denom
    # 只在实际有能量(非静音)的位置里找峰，避免 FFT 尾噪声在小分母下放大
    valid = np.where(win > 1e-4)[0]
    if valid.size == 0:
        return None
    k = int(valid[np.argmax(score[valid])])
    if float(score[k]) < thr:
        return None
    return {"offset_s": float(k) / sr, "score": float(score[k])}


def load_template(path: str, sr: int):
    """读取模板音频文件（wav/mp3/视频均可）并重采样到 sr，返回 float32 样本。"""
    if not path or not os.path.exists(path):
        return None
    try:
        tsr, t = decode_to_mono(path, target_sr=sr)
        return t.astype(np.float32)
    except Exception:
        return None
