# core/tts.py
# Edge TTS 单条合成工具：唤醒词现场补生成 / 日志测试语音生成 共用
# 注意: edge-tts 输出固定是 MP3 编码（audio-24khz-48kbitrate-mono-mp3），
#       与 --write-media 给什么扩展名无关。早期版本把 MP3 数据写成了 .wav，
#       pygame 按扩展名选解码器时报 "Unknown WAVE format"。
#       因此所有新生成统一落 .mp3，并兼容清理“假 .wav”历史文件。
#
# v1.6.2: 支持音色选择（女声/男声/童声）与可选情感语气（SSML express-as）。
#   优先使用 python edge_tts 库（异步）；库缺失时退回原 edge-tts 命令行，
#   命令行方式仅能使用默认音色（不带情感）。
import asyncio
import os
import subprocess
import threading
import time
import xml.sax.saxutils
from shutil import which
from typing import Tuple

# 音频文件支持的后缀（先 wav 后 mp3: 用户手工提供的真实 wav 优先）
AUDIO_EXTS = (".wav", ".mp3")

# 情感/语气：界面显示中文，config 保存英文 token（Edge 服务端要求 token）
# v1.6.6: 新增中文显示映射（桌面与浏览器共用）。
STYLE_LABELS = {
    "默认": "默认",
    "cheerful": "开心欢快",
    "affectionate": "温柔亲切",
    "gentle": "温和舒缓",
    "empathetic": "感同身受",
    "serious": "严肃正式",
    "sad": "难过低沉",
    "angry": "生气愤怒",
    "newscast": "新闻播报",
    "storytelling": "讲故事",
    "cheer-up": "打起精神",
    "chat": "日常闲聊",
    "narration-relaxed": "轻松解说",
    "narration-professional": "专业解说",
}

DEFAULT_VOICE = "zh-CN-XiaoxiaoNeural"   # 晓晓(女, 默认, 与原行为最接近)
DEFAULT_VOICE_TYPE = "女声"

# 中文音色库（分组: 类型 -> [(voice, 说明)]，均为微软 Edge 稳定中文神经音色）
VOICE_GROUPS = {
    "女声": [
        ("zh-CN-XiaoxiaoNeural", "晓晓 · 温暖亲和（情感丰富）"),
        ("zh-CN-XiaoyiNeural", "晓伊 · 甜美"),
        ("zh-CN-XiaomoNeural", "晓墨 · 情感更丰富"),
        ("zh-CN-XiaoxuanNeural", "晓萱 · 成熟知性"),
    ],
    "男声": [
        ("zh-CN-YunxiNeural", "云希 · 阳光清亮"),
        ("zh-CN-YunjianNeural", "云健 · 沉稳磁性"),
        ("zh-CN-YunyangNeural", "云扬 · 新闻播报"),
        ("zh-CN-YunyeNeural", "云野 · 自然口语"),
        ("zh-CN-YunzeNeural", "云泽 · 讲故事/旁白"),
    ],
    "童声": [
        ("zh-CN-YunxiaNeural", "云夏 · 男童/少年"),
        ("zh-CN-XiaoyouNeural", "小悠 · 女童故事音"),
    ],
}

# 情感语气: 仅列出经过验证稳定支持的 voice -> 可用 style
# （未列出或未支持的音色只提供“默认”，避免合成报错）
VOICE_STYLES = {
    "zh-CN-XiaoxiaoNeural": [
        "默认", "cheerful", "affectionate", "gentle", "empathetic",
        "serious", "sad", "angry", "newscast", "storytelling"],
    "zh-CN-XiaomoNeural": [
        "默认", "cheerful", "affectionate", "gentle", "serious", "sad",
        "angry", "storytelling"],
    "zh-CN-YunxiNeural": [
        "默认", "cheer-up", "chat", "narration-relaxed", "sad", "angry"],
    "zh-CN-YunjianNeural": [
        "默认", "cheer-up", "chat", "narration-relaxed", "sad", "angry"],
    "zh-CN-YunyangNeural": ["默认", "narration-professional"],
    "zh-CN-YunzeNeural": ["默认", "storytelling"],
    "zh-CN-XiaoyouNeural": ["默认", "cheerful", "affectionate",
                            "serious", "sad", "angry"],
}
NIO_TTS_HINT = ("NIO 内部 TTS 为预留入口：需提供接口地址、鉴权方式与声音ID，"
                "配置到 config.json 的 nio_tts 字段后即可使用。当前请先用 Edge-TTS。")


def voices_of_type(vtype: str):
    """返回某类型的 [(voice_id, 说明)]，未知类型返回空列表"""
    return list(VOICE_GROUPS.get(vtype, []))


def styles_of(voice: str):
    """返回某音色可用情感列表（首个固定为“默认”）"""
    return list(VOICE_STYLES.get(voice, ["默认"]))


def style_label(style: str) -> str:
    """情感 token -> 中文显示名（未知 token 原样返回，兼容旧配置）"""
    return STYLE_LABELS.get(str(style), str(style))


def style_items(voice: str):
    """下拉用 [(中文名, 存储token), ...]，按 styles_of 顺序"""
    return [(style_label(s), s) for s in styles_of(voice)]


def tts_available() -> bool:
    """edge-tts 是否可用（python 库或命令行任一即可）"""
    try:
        import edge_tts  # noqa: F401
        return True
    except Exception:
        pass
    return which("edge-tts") is not None or which("edge-tts.exe") is not None


def file_is_wav(path: str) -> bool:
    """按文件头判断是否为真实 WAV（RIFF....WAVE）"""
    try:
        with open(path, "rb") as f:
            h = f.read(12)
        return len(h) == 12 and h[:4] == b"RIFF" and h[8:12] == b"WAVE"
    except Exception:
        return False


def file_is_mp3(path: str) -> bool:
    """按文件头判断是否为 MP3 帧数据（0xFF Ex）"""
    try:
        with open(path, "rb") as f:
            h = f.read(2)
        return len(h) == 2 and h[0] == 0xFF and (h[1] & 0xE0) == 0xE0
    except Exception:
        return False


def prepare_output(audio_dir: str, base: str) -> str:
    """决定本次应合成的完整输出路径（统一 .mp3）。

    - 已存在“可正常播放”的同名音频（真实 WAV 或 MP3）-> 返回 ""（跳过生成）
    - 存在历史“扩展名 .wav 但内容是 MP3”的假文件 -> 自动删除后返回 mp3 路径，
      否则 pygame 会一直按 .wav 解码这类文件并报错
    - 都不存在 -> 返回待生成的 .mp3 路径
    """
    os.makedirs(audio_dir, exist_ok=True)
    legacy = os.path.join(audio_dir, base + ".wav")
    if os.path.exists(legacy) and os.path.getsize(legacy) > 0:
        if file_is_wav(legacy):
            return ""                       # 用户手工提供的真实 wav，优先保留
        try:
            os.remove(legacy)               # 假 wav（内容是 mp3）清理掉
        except OSError:
            pass
    mp3_p = os.path.join(audio_dir, base + ".mp3")
    if os.path.exists(mp3_p) and os.path.getsize(mp3_p) > 0:
        return ""
    return mp3_p


def _escape(text: str) -> str:
    return xml.sax.saxutils.escape(str(text))


def _styled_ssml(escaped_text: str, voice: str, style: str) -> str:
    """构造带 express-as 情感节点的完整 speak 文档。

    edge_tts 库内部会把输入文本 XML 转义后塞进它自己的 <speak>，
    直接把整段 <speak> 当 text 传入会被“朗读成代码”（v1.6.5 缺陷）。
    因此这里通过临时替换库内 mkssml 实现，让库生成的 speak 正文带上
    <voice name=...><mstts:express-as style=...>...</...></voice>。
    """
    return ('<speak version="1.0" '
            'xmlns="http://www.w3.org/2001/10/synthesis" '
            'xmlns:mstts="https://www.w3.org/2001/mstts" xml:lang="zh-CN">'
            '<voice name="{v}"><mstts:express-as style="{s}">{t}'
            '</mstts:express-as></voice></speak>').format(
        v=voice, s=style, t=escaped_text)


_STYLE_PATCH_LOCK = threading.Lock()


async def _synth_edge_async(text: str, filepath: str, voice: str,
                            style: str = "默认"):
    """用 python edge_tts 异步合成；带情感时注入 express-as SSML 节点。

    v1.6.6 修复: 旧实现把整段 SSML 当 Communicate(text) 传入，被库转义
    后服务端会朗读 XML 源码（像读代码）。现改为在合成期间临时替换库的
    SSML 组装函数，使库发送的请求真正包含 express-as 节点。
    """
    import edge_tts
    if style and style != "默认":
        import edge_tts.communicate as _comm
        with _STYLE_PATCH_LOCK:
            orig = _comm.mkssml
            try:
                _comm.mkssml = (lambda tc, esc, _v=voice, _s=style:
                                _styled_ssml(esc, _v, _s))
                com = edge_tts.Communicate(text, voice)
                await com.save(filepath)
            finally:
                _comm.mkssml = orig
    else:
        com = edge_tts.Communicate(text, voice)
        await com.save(filepath)


def _synth_edge_cli(text: str, filepath: str, timeout: int):
    """命令行兜底（无 python 库时），仅默认音色"""
    cmd = ["edge-tts", "--text", text, "--write-media", filepath,
           "--voice", DEFAULT_VOICE]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout)
    except FileNotFoundError:
        return False, "未找到 edge-tts 命令（pip install edge-tts）"
    except subprocess.TimeoutExpired:
        return False, f"合成超时({timeout}s)"
    except Exception as e:
        return False, str(e)
    if r.returncode != 0:
        err = (r.stderr or r.stdout or "").strip()[:160]
        return False, err or f"退出码 {r.returncode}"
    return True, ""


def synth_one(text: str, filepath: str, timeout: int = 90,
              voice: str = "", style: str = "默认") -> Tuple[bool, str]:
    """合成单条音频（.mp3）并校验文件生成，返回 (成功, 错误信息)

    :param voice: 音色ID（见 VOICE_GROUPS），空则用默认晓晓
    :param style: 情感/语气（见 styles_of；无效或“默认”时不加 express-as）

    v1.6.8: 批量合成常遇 “No audio was received”（Edge 服务端偶发空响应/
    限流）。改为“带重试与退避”的合成：每种风格至多重试 3 次（间隔递增），
    情感风格失败自动降级默认风格；全部失败再退回命令行兜底。
    """
    if not voice:
        voice = DEFAULT_VOICE
    if style != "默认" and style not in VOICE_STYLES.get(voice, []):
        style = "默认"

    def _file_ok() -> bool:
        try:
            return (os.path.exists(filepath)
                    and os.path.getsize(filepath) > 0)
        except OSError:
            return False

    def _remove_partial():
        try:
            if os.path.exists(filepath):
                os.remove(filepath)
        except OSError:
            pass

    # 需要尝试的风格序列：优先用户所选；非默认时失败后自动降级默认。
    candidates = [style] if style == "默认" else [style, "默认"]
    last_err = ""
    tried = 0
    for st in candidates:
        for attempt in range(1, 4):          # 每风格最多 3 次尝试
            tried += 1
            try:
                asyncio.run(_synth_edge_async(text, filepath, voice, st))
                if _file_ok():
                    return True, ""
                last_err = "生成后文件为空"
            except Exception as e:             # noqa: BLE001
                last_err = str(e)
            _remove_partial()
            # 指数退避：重试前等待 1s/2s，给服务端恢复时间
            if attempt < 3:
                time.sleep(1.0 * attempt)

    # python 库全失败 -> 命令行兜底（仅默认音色/无情感）
    _remove_partial()
    try:
        ok, cli_err = _synth_edge_cli(text, filepath, timeout)
        if ok and _file_ok():
            return True, ""
        last_err = cli_err or last_err
    except Exception as e:                     # noqa: BLE001
        last_err = str(e)
    if not _file_ok():
        _remove_partial()
        note = ("；情感风格已自动降级默认重试" if style != "默认"
                else "")
        return False, (f"Edge-TTS 合成失败: {last_err}{note}；"
                       "请确认网络可用（必要时稍后重试或换音色）")
    return True, ""
