# core/executors.py
# ADB 命令封装 / CPU 采集（Python 逐行加时间戳）/ 本地 bash 脚本执行
import os
import subprocess
import threading
import time
from typing import List, Optional, Tuple

from core import app_log


class AdbExecutor:
    """ADB 命令封装"""

    @staticmethod
    def connect(host: str, port: str = "7777") -> Tuple[bool, str]:
        """adb connect + adb root，并验证连通"""
        try:
            app_log.log("ADB", f"执行: adb connect {host}:{port}（进入 Android 侧）")
            subprocess.run(f'adb connect {host}:{port}', shell=True,
                           capture_output=True, timeout=10)
            time.sleep(1)
            app_log.log("ADB", "执行: adb root")
            subprocess.run('adb root', shell=True, capture_output=True,
                           timeout=10, text=True)
            time.sleep(1)
            ok, out = AdbExecutor.shell('echo ok', timeout=5)
            return 'ok' in out, out
        except Exception as e:
            return False, str(e)

    @staticmethod
    def shell(cmd: str, timeout: int = 10) -> Tuple[bool, str]:
        """执行 adb shell 命令，返回 (成功, 输出)"""
        try:
            app_log.log("ADB", f"执行: adb shell {cmd}")
            r = subprocess.run(f'adb shell {cmd}', shell=True, capture_output=True,
                               timeout=timeout, text=True, encoding='utf-8',
                               errors='replace')
            out = (r.stdout or '').strip()
            err = (r.stderr or '').strip()
            brief = (out or err or '')[:200]
            app_log.log("ADB", f"完成: returncode={r.returncode} 结果={brief or '(空)'}")
            return (r.returncode == 0 and 'error' not in out.lower()), (out or err)
        except Exception as e:
            return False, str(e)

    @staticmethod
    def get_nomi_pids(car: str = "NIO") -> List[str]:
        """按车型查询 NOMI/小乐主进程 PID（showmap 用）

        - NIO / FY:  ps -A | grep nomi
        - ALPS:      ps -A | grep xiaole（小乐进程 com.alps.xiaole）
        自动排除 "com.alps.xiaole:updater" 之类带冒号的子进程，
        只保留主进程。返回 ['PID  进程名', ...] 供弹窗选择。
        """
        keyword = "xiaole" if car == "ALPS" else "nomi"
        ok, out = AdbExecutor.shell(f'ps -A | grep {keyword}', timeout=10)
        if not ok or not out:
            return []
        result = []
        seen = set()
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 2 and parts[1].isdigit():
                name = parts[-1]
                if ":" in name:
                    continue  # 子进程(:updater/:dm/:km 等)不参与 showmap
                item = f"{parts[1]}  {name}"
                if item not in seen:
                    seen.add(item)
                    result.append(item)
        return result


class CpuCollector:
    """CPU 采集：执行 adb shell top -d 1，逐行加本地时间戳写入文件
    等效于: adb shell top -d 1 | while IFS= read -r line;
            do echo "$(date '+%Y-%m-%d %H:%M:%S') $line"; done >> xxx.log
    纯 Python 实现，不依赖 bash。
    """

    def __init__(self):
        self.proc: Optional[subprocess.Popen] = None
        self.thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def start(self, log_file: str) -> bool:
        try:
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            self._stop.clear()
            app_log.log("CPU采集", f"启动: adb shell top -d 1 -> {log_file}")
            self.proc = subprocess.Popen(
                'adb shell top -d 1',
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                encoding='utf-8',
                errors='replace',
            )
            self.thread = threading.Thread(target=self._pump, args=(log_file,), daemon=True)
            self.thread.start()
            return True
        except Exception:
            return False

    def _pump(self, log_file: str):
        with open(log_file, 'a', encoding='utf-8', errors='replace') as f:
            while not self._stop.is_set() and self.proc and self.proc.poll() is None:
                line = self.proc.stdout.readline()
                if not line:
                    break
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                f.write(f"{ts} {line.rstrip()}\n")
                f.flush()

    def stop(self):
        self._stop.set()
        app_log.log("CPU采集", "停止 top 采集")
        if self.proc and self.proc.poll() is None:
            # 先杀进程树（shell + adb 子进程），避免残留 adb.exe 僵尸进程
            try:
                subprocess.run(f'taskkill /F /T /PID {self.proc.pid}', shell=True,
                               capture_output=True, timeout=10)
            except Exception:
                try:
                    self.proc.terminate()
                except Exception:
                    pass
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=3)
        self.proc = None
        self.thread = None


class LocalExecutor:
    """本地命令执行：bash 检测、MEM 脚本启动与进程树终止"""

    _bash: Optional[str] = None
    _bash_checked: bool = False

    @staticmethod
    def find_bash() -> Optional[str]:
        """查找可用的 bash（Git Bash / WSL bash）"""
        if LocalExecutor._bash_checked:
            return LocalExecutor._bash
        LocalExecutor._bash_checked = True
        candidates = [
            'bash',
            r'C:\Program Files\Git\bin\bash.exe',
            r'C:\Program Files (x86)\Git\bin\bash.exe',
            r'C:\Program Files\Git\usr\bin\bash.exe',
        ]
        for c in candidates:
            try:
                r = subprocess.run(f'"{c}" --version', shell=True,
                                   capture_output=True, timeout=5)
                if r.returncode == 0:
                    LocalExecutor._bash = c
                    return c
            except Exception:
                continue
        return None

    @staticmethod
    def start_mem_script(script_path: str, out_dir: str, ts: str,
                         version_scene: str) -> Optional[subprocess.Popen]:
        """启动 MEM 采集脚本
        等效于: ./mem_command_nomi.sh "{out_dir}" "{ts}" "{version_scene}" "Windows" "Nomi" "0"
        """
        bash = LocalExecutor.find_bash()
        if not bash:
            return None
        script_fwd = script_path.replace('\\', '/')
        out_dir_fwd = out_dir.replace('\\', '/')
        cmd = (f'"{bash}" "{script_fwd}" "{out_dir_fwd}" "{ts}" '
               f'"{version_scene}" "Windows" "Nomi" "0"')
        app_log.log("MEM脚本", f"启动: bash 执行 {script_path} (输出 {out_dir})")
        try:
            return subprocess.Popen(cmd, shell=True,
                                    stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL)
        except Exception:
            return None

    @staticmethod
    def kill_tree(proc: Optional[subprocess.Popen]) -> bool:
        """终止进程及其全部子进程（Windows: taskkill /T /F）"""
        if proc is None:
            return True
        try:
            subprocess.run(f'taskkill /F /T /PID {proc.pid}', shell=True,
                           capture_output=True, timeout=10)
            return True
        except Exception:
            try:
                proc.kill()
                return True
            except Exception:
                return False

    @staticmethod
    def open_folder(path: str):
        """在资源管理器中打开文件夹"""
        try:
            subprocess.Popen(f'explorer "{path}"')
        except Exception:
            pass
