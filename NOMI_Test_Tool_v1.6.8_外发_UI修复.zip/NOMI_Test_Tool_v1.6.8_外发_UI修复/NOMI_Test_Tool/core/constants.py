# core/constants.py
# 全局常量：场景清单、车型唤醒词、目录结构、时长、QNX 路径

# ==================== 场景清单（执行顺序） ====================
SCENARIOS = [
    ("idle", "静置"),
    ("wakeup", "唤醒"),
    ("vehicle", "车控"),
    ("media", "媒体"),
    ("navigation", "导航"),
    ("phone", "电话"),
    ("weather", "天气"),
    ("joke", "笑话"),
    ("gpt", "GPT"),
    ("idle_after", "交互后静置"),
]
SCENARIO_KEYS = [k for k, _ in SCENARIOS]
SCENARIO_NAMES = dict(SCENARIOS)

# ==================== 车型 -> 唤醒词 ====================
CAR_WAKEUP_WORDS = {
    "NIO": "HI NOMI",
    "ALPS": "小乐小乐",
    "FY": "HI lumo",
}

# 交互场景 key -> Query 配置键（与 config.json queries 对应）
SCENARIO_QUERY_KEY = {
    "wakeup": "唤醒",
    "vehicle": "车控",
    "media": "媒体",
    "navigation": "导航",
    "phone": "电话",
    "weather": "天气",
    "joke": "笑话",
    "gpt": "GPT",
}
# 需要播放音频的交互场景
INTERACTIVE_SCENARIOS = list(SCENARIO_QUERY_KEY.keys())

# ==================== 产物目录名（总文件夹下的子目录） ====================
DIR_CPU = "CPU"                 # nomi_CPU_out-*.log
DIR_MEM = "MEM"                 # nomi_mem_out-*.txt（由 MEM 脚本自行生成）
DIR_SHOWMAP = "showpmap测试"    # Mem_Showmap_*.log
DIR_SPEECH_CPU = "speech-cpu"   # top2_process_qnx_*.log
DIR_QNX_CPU = "qnx-cpu"         # top2_all_qnx_*.log
DIR_SLOG = "slog"               # QNX slog 整目录拉取产物（/blackbox/cdclogs/qnx/slog）
DIR_AUDIO = "audio"             # TTS 音频（输出根目录下，跨测试复用）

# ==================== 时长（秒） ====================
COLLECT_SECONDS = 60    # 每场景采集时长
INTERVAL_SECONDS = 60   # 场景间隔

# ==================== QNX 侧路径 ====================
QNX_LOG_DIR = "/var/log/"
QNX_TOP2_PROCESS_FILE = "top2_process_qnx_001.log"
QNX_TOP2_ALL_FILE = "top2_all_qnx_001.log"

# top2 可执行文件候选路径
# 非交互 SSH shell 的 PATH 不全，直接执行 top2 会报
# "sh: top2: cannot execute - No such file or directory"，必须先定位完整路径
TOP2_CANDIDATE_PATHS = [
    "/bin/top2", "/usr/bin/top2", "/sbin/top2", "/usr/sbin/top2",
    "/opt/bin/top2", "/opt/sbin/top2", "/proc/boot/top2",
    "/nio/bin/top2", "/usr/nio/bin/top2", "/usr/local/bin/top2",
]
# top2 冒烟测试临时文件（预检时验证 top2 真正可用）
QNX_TOP2_SMOKE_FILE = "/var/log/nomi_top2_smoke.log"

# ==================== QNX 命令环境前缀（legacy_conn_tool 同款） ====================
# 非交互 SSH 的 PATH / LD_LIBRARY_PATH 不全，直接跑 /nio/bin/top2 会因
# 缺库/缺路径静默失败（文件为空）。legacy_conn_tool 的做法是每条命令前
# source /etc/profile，这里再显式补全 PATH 和库路径双保险。
QNX_ENV_PREFIX = (
    ". /etc/profile 2>/dev/null; "
    "PATH=/bin:/usr/bin:/sbin:/usr/sbin:/nio/bin:$PATH; "
    "export LD_LIBRARY_PATH=/lib:/usr/lib:/nio/lib:/usr/lib/dll:$LD_LIBRARY_PATH; "
)
# 兼容旧名（top2 调用前附加的环境前缀）
QNX_TOP2_PATH_PREFIX = QNX_ENV_PREFIX

# 长版本读取命令（QNX 上执行，解析 Artifact 字段）
QNX_VERSION_CMD = "cat /nio/version.txt"
# speech-service 进程查询命令（QNX 上执行，双命令兜底）:
#   首选: /etc/profile 环境下 ps -A（/nio/bin 的 ps，进程级输出干净）
QNX_SPEECH_PID_PS_CMD = ". /etc/profile 2>/dev/null; ps -A | grep speech-service"
#   兜底: pidin（QNX 原生，线程级输出，需按 PID 去重）
QNX_SPEECH_PID_PIDIN_CMD = "pidin | grep speech-service"

# ==================== slog（QNX 系统日志） ====================
# 用户要求: slog 不是单文件导出，而是整目录拉取，
# 等同 scp -r /blackbox/cdclogs/qnx/slog/ .（本地落在 <会话>/slog/）
SLOG_REMOTE_DIR = "/blackbox/cdclogs/qnx/slog"
# 清空 QNX slog2 实时缓冲区（「清空车机日志」用，仅清缓冲不动历史文件目录）
QNX_SLOG_CLEAR_CMD = ". /etc/profile 2>/dev/null; slog2info -c"

# ==================== 安卓 logd（日志测试 / 日志管理） ====================
# 用户确认: 只拉取 /data/misc/nio/logd 目录
LOGD_REMOTE_DIR = "/data/misc/nio/logd"
# 清空安卓日志: 清 logcat 内存缓冲 + 删 nio/logd 旧文件（目录保留）
LOGCAT_CLEAR_CMD = "logcat -b all -c"
LOGD_CLEAR_CMD = "rm -rf /data/misc/nio/logd/*"

# ==================== 日志测试（xlsx 模块清单） ====================
LOG_MODULE_SECONDS = 60          # 每模块默认时长
LOG_MODULE_GAP = 3               # 模块间切换缓冲秒数
LOG_TRIAL_SECONDS = 10           # 试跑模式每模块时长（不采集日志）
DIR_LOGD = "logd"                # 安卓 logd 拉取产物子目录
DIR_VIDEO = "ICS录像"            # scrcpy 录屏产物子目录
DIR_MODULES = "modules"          # 三平台模块操作配置 JSON 目录
# 日志测试语音 Query 音频文件名前缀（与「TTS 配置」页场景 Query 区分）
LOG_TEST_AUDIO_PREFIX = "日志测试_"
# Nomi 模块语音交互样例（xlsx 备注列，唤醒词 + 以下 query 循环外放）
NOMI_LOG_TEST_QUERIES = [
    "今天天气", "明天天气", "后天天气", "周末天气", "上海天气", "北京天气",
    "讲个笑话", "换一个", "再换一个", "再来一个",
    "导航", "去上海南站", "下一页", "上一页", "第一个",
    "去上海虹桥", "去浦东机场", "去外滩", "去人民广场",
]

# 日志测试平台 -> 模块配置文件名（modules/ 目录下）
LOG_TEST_PLATFORMS = {
    "NT3.0-NIO": "NT3.0-NIO.json",
    "NT2.5-NIO": "NT2.5-NIO.json",
    "NT3.0-ALPS": "NT3.0-ALPS.json",
}
# 日志测试平台 -> 平台显示说明（连接设备页对应关系）
LOG_TEST_PLATFORM_TIPS = {
    "NT3.0-NIO": "对应「连接设备」页平台 NT3.0-NIO / ALPS（NIO 侧）",
    "NT2.5-NIO": "对应「连接设备」页平台 NT2.5",
    "NT3.0-ALPS": "对应「连接设备」页平台 NT3.0-NIO / ALPS（ALPS 侧）",
}

# scrcpy 自动探测候选路径（用户机器已装 v3.3.4，找不到时提示手填）
SCRCPY_CANDIDATES = [
    "scrcpy",                       # PATH 里
    r"D:\auto\scrcpy\scrcpy.exe",
    r"D:\scrcpy\scrcpy.exe",
    r"C:\scrcpy\scrcpy.exe",
    r"C:\Program Files\scrcpy\scrcpy.exe",
    r"D:\Program Files\scrcpy\scrcpy.exe",
    r"D:\11\scrcpy\scrcpy.exe",
]
