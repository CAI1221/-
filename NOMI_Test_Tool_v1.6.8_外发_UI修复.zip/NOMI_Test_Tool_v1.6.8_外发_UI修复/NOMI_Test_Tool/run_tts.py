# run_tts.py - 仅启动「TTS 配置/音频合成」页的独立窗口（与其它 Tab 隔离）
# 用法:  python run_tts.py
# 独立进程，合成/校验音频时不占用主工具的 UI 线程。
import os
import sys

_APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _APP_DIR)
os.chdir(_APP_DIR)

from PyQt5.QtWidgets import QApplication, QMainWindow  # noqa: E402


def main():
    from ui.config_page import ConfigPage  # noqa: E402
    app = QApplication(sys.argv)
    win = QMainWindow()
    win.setWindowTitle("NOMI TTS 配置与音频合成（独立窗口）")
    page = ConfigPage()
    win.setCentralWidget(page)
    try:
        scr = app.primaryScreen()
        geo = scr.availableGeometry()
        win.resize(min(1080, geo.width() - 60),
                   min(760, geo.height() - 80))
    except Exception:
        win.resize(1000, 700)
    win.show()
    rc = app.exec_()
    if page.worker and page.worker.isRunning():
        page.worker.stop()
        page.worker.wait(3000)
    sys.exit(rc)


if __name__ == "__main__":
    main()
