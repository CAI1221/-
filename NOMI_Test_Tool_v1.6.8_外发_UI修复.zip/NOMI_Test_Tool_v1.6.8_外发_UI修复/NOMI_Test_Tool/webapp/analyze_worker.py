# webapp/analyze_worker.py - 响应时延分析独立子进程（v1.6.5）
#
# 由 webapp/runner.start_analyze 以 subprocess 方式调用：
#   python analyze_worker.py <args.json> <result.json>
#
# 本进程绝不 import PyQt5（本机 3.12 环境验证：PyQt 与 ctranslate2 同进程
# 会 native crash），只依赖 core 下的纯逻辑模块跑完整链路：
#   解码 -> 校准音 -> VAD -> 整轨 ASR -> 模板对齐
# 进度走 stdout（调用方逐行收），结果写 <result.json>。
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def main():
    if len(sys.argv) < 3:
        print("[参数不足] 需要 args.json result.json", flush=True)
        return 2
    args_path, result_path = sys.argv[1], sys.argv[2]
    with open(args_path, "r", encoding="utf-8") as f:
        p = json.load(f)
    from core.latency_analyze import AnalyzeArgs, run_analysis

    def emit(msg):
        print(msg, flush=True)

    args = AnalyzeArgs(
        media_path=p.get("media_path", ""),
        template_path=p.get("template_path", ""),
        model_name=p.get("model_name", "base"),
        language=p.get("language", "auto"),
        wake_path=p.get("wake_path", ""),
        wake_text=p.get("wake_text", ""),
        use_cal=True,
        gap_ms=int(p.get("gap_ms") or 150))
    try:
        r = run_analysis(args, emit=emit)
    except Exception as e:                 # noqa: BLE001
        print(f"[分析失败] {e}", flush=True)
        return 3
    out = {
        "ok": True,
        "rows": _jsonable(r.rows),
        "results": _jsonable(r.results),
        "units": _jsonable(r.units),
        "cal_s": float(r.cal_s or 0.0),
        "cal_score": float(r.cal_score or 0.0),
        "media_path": p.get("media_path", ""),
        "template_path": p.get("template_path", ""),
    }
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    print("[子进程完成]", flush=True)
    return 0


def _jsonable(obj):
    import numpy as np

    def conv(o):
        if isinstance(o, dict):
            return {k: conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, float):
            return None if o != o else o
        return o
    return conv(obj)


if __name__ == "__main__":
    sys.exit(main())
