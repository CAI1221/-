# webapp/server.py - NOMI_Test_Tool 浏览器控制台（本地版，与桌面 UI 并存）
#
# 纯标准库（http.server + threading），无需额外 pip 安装。
# 启动:  python webapp/server.py  -> 浏览器打开 http://127.0.0.1:8765
#
# 能力(v1.6.5):
#   连接设备: 平台选择 / 自动建隧道 / 手动检测 / 状态
#   执行测试: 车型/场景/PID 抓取 / 预检 / 后台运行（同桌面引擎）
#   日志测试: 平台模块选择 / 正式或试跑 / 人工模块等待继续 / 停止
#   响应时延: 上传或选用本地录音 / 模板 Excel / 整轨 ASR 分析 / 修正 / 写 Excel
#   TTS/音频: 配置读写(work_dir/音色/语料) / 批量生成 / 完整性
#   ASR 模型: 就绪状态 + 一键下载(hf-mirror 镜像)
#   运行日志: 实时查看/搜索
# 长任务全部在 webapp.runner 的后台线程执行，浏览器轮询日志，不卡 HTTP。
import json
import os
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

# 无界面兜底：本进程只复用引擎逻辑，不创建窗口
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
LOG_DIR = os.path.join(ROOT, "运行日志")
CONFIG_PATH = os.path.join(ROOT, "config.json")
PORT = int(os.environ.get("NOMI_WEB_PORT", "8765"))
VERSION = "v1.6.8"

import webapp.runner as R          # noqa: E402

# ---------------- ASR 下载状态 ----------------
_asr_lock = threading.Lock()
_asr_msgs = []
_asr_active = {"model": None, "running": False, "error": ""}


def _mirror_config_audio(data: dict):
    """v1.6.6: 把配置镜像一份到 <work_dir>/audio/config.json（与 TTS 音频同路径）。

    桌面 config_page 保存配置时同样会写这份副本，浏览器端保持一致。
    """
    try:
        wd = str((data or {}).get("work_dir") or "").strip()
        if not wd:
            return
        audio = os.path.join(wd, "audio")
        os.makedirs(audio, exist_ok=True)
        with open(os.path.join(audio, "config.json"), "w",
                  encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:                # noqa: BLE001
        pass


def _asr_push(msg):
    with _asr_lock:
        _asr_msgs.append(msg)
        if len(_asr_msgs) > 300:
            del _asr_msgs[:-300]


def _asr_download_worker(model):
    try:
        import core.asr_align as aa
        aa.set_download_callback(_asr_push)
        aa.ensure_model_downloaded(model)
        _asr_push(f"[完成] 模型 {model} 已就绪: {aa.model_dir(model)}")
        with _asr_lock:
            _asr_active.update(running=False, model=None, error="")
    except Exception as e:           # noqa: BLE001
        with _asr_lock:
            _asr_active.update(running=False, model=None, error=str(e))
        _asr_push(f"[失败] {e}")
    finally:
        try:
            import core.asr_align as aa
            aa.set_download_callback(None)
        except Exception:
            pass


# ---------------- TTS 生成状态 ----------------
_tts_lock = threading.Lock()
_tts_msgs = []
_tts_active = {"running": False, "error": ""}


def _tts_push(msg):
    with _tts_lock:
        _tts_msgs.append(msg)
        if len(_tts_msgs) > 400:
            del _tts_msgs[:-400]


def _tts_generate_worker():
    try:
        cfg = load_config()
        wd = cfg.get("work_dir") or ""
        if not wd or not os.path.isdir(wd):
            _tts_push("[失败] config 未设置有效 work_dir")
            raise RuntimeError("work_dir 无效")
        provider = cfg.get("voice_provider") or "Edge-TTS（在线）"
        if str(provider).startswith("NIO"):
            _tts_push("[跳过] 当前合成来源为 NIO 预留，请先在配置页改用 Edge-TTS")
            raise RuntimeError("合成来源为 NIO 预留")
        queries = cfg.get("queries") or {}
        data = {k: [q for q in v if str(q).strip()]
                for k, v in queries.items() if k != "唤醒" and v}
        wake = (cfg.get("wakeup_word") or "").strip()
        # 唤醒词缺省: 取车型默认（NIO -> HI NOMI）
        if not wake:
            wake = "HI NOMI"
        # 复用桌面端同一合成 worker（直接同步执行 run()，无需 Qt 事件循环）
        from ui.config_page import TtsWorker
        w = TtsWorker(wd, data, wake,
                      voice=cfg.get("voice", ""),
                      style=cfg.get("tts_style", "默认"))
        w.log_signal.connect(_tts_push)
        w.run()      # 跳过已存在 / 失败自动重试一次 / 完成汇总
        _tts_push("[完成] TTS 生成任务结束")
        with _tts_lock:
            _tts_active.update(running=False, error="")
    except Exception as e:           # noqa: BLE001
        _tts_push(f"[失败] {e}")
        with _tts_lock:
            _tts_active.update(running=False, error=str(e))


# ---------------- 数据接口 ----------------
def newest_log_path():
    if not os.path.isdir(LOG_DIR):
        return None
    files = [os.path.join(LOG_DIR, f) for f in os.listdir(LOG_DIR)
             if f.lower().endswith(".txt")]
    if not files:
        return None
    return max(files, key=os.path.getmtime)


def tail_text(path, lines=400):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = f.read()
        arr = data.splitlines()
        return "\n".join(arr[-lines:])
    except Exception:
        return ""


def load_config():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def audio_overview(cfg):
    wd = cfg.get("work_dir") or ""
    audio = os.path.join(wd, "audio") if wd else ""
    exists = os.path.isdir(audio)
    files = []
    if exists:
        try:
            files = [f for f in os.listdir(audio)
                     if f.lower().endswith((".wav", ".mp3"))]
        except OSError:
            files = []
    missing = []
    wake = (cfg.get("wakeup_word") or "HI NOMI").strip()
    queries = cfg.get("queries") or {}
    if exists and wake:
        if not any(os.path.splitext(f)[0] == wake for f in files):
            missing.append(f"{wake} (唤醒词)")
    if exists and not any(f.startswith("电话_挂断") for f in files):
        missing.append("电话_挂断")
    for scene, qs in queries.items():
        if scene == "唤醒":
            continue
        for q in qs:
            q = str(q).strip()
            if not q:
                continue
            safe = q.replace("/", "_").replace("\\", "_")
            if not any(os.path.splitext(f)[0] == f"{scene}_{safe}"
                       for f in files):
                missing.append(f"{scene}_{safe}")
    summary = {}
    for scene, qs in queries.items():
        summary[scene] = len(qs)
    return {"work_dir": wd, "audio_dir": audio, "exists": exists,
            "file_count": len(files), "missing": missing[:60],
            "scenario_counts": summary,
            "wakeup": wake,
            "voice": cfg.get("voice", ""),
            "tts_style": cfg.get("tts_style", "默认"),
            "voice_provider": cfg.get("voice_provider", ""),
            "car": cfg.get("car", "")}


def asr_overview():
    try:
        import core.asr_align as aa
    except Exception as e:
        return {"error": str(e), "models": []}
    out = []
    for m in aa.MODEL_CHOICES:
        d = aa.model_dir(m)
        ready = aa.is_model_ready(m)
        size = ""
        b = os.path.join(d, "model.bin")
        if os.path.exists(b):
            size = "%.0fMB" % (os.path.getsize(b) / 1024 / 1024)
        out.append({"model": m, "ready": ready, "size": size,
                    "dir": d})
    return {"root": aa.model_root(), "models": out}


# ---------------- 上传文件解析 ----------------
def _parse_multipart(body: bytes, content_type: str):
    """解析 multipart/form-data，返回 (fields, files)
    fields: {name: str}  files: [{name, filename, content}]"""
    m = re.search(r'boundary=(?:"([^"]+)"|([^;]+))', content_type or "")
    boundary = (m.group(1) or m.group(2)).strip() if m else ""
    if not boundary:
        return {}, []
    delim = b"--" + boundary.encode("latin-1")
    parts = body.split(delim)
    fields = {}
    files = []
    for part in parts:
        part = part.strip(b"\r\n")
        if not part or part == b"--":
            continue
        head, _, data = part.partition(b"\r\n\r\n")
        if not head:
            continue
        head_txt = head.decode("latin-1", "replace")
        name_m = re.search(r'name="([^"]*)"', head_txt)
        name = name_m.group(1) if name_m else ""
        fn_m = re.search(r'filename="([^"]*)"', head_txt)
        filename = fn_m.group(1) if fn_m else ""
        # 去掉尾部换行（RFC 每 part 结尾 \r\n）
        if data.endswith(b"\r\n"):
            data = data[:-2]
        if filename:
            files.append({"name": name, "filename": filename,
                          "content": data})
        else:
            fields[name] = data.decode("utf-8", "replace")
    return fields, files


# ---------------- API 路由 ----------------
def handle_api(path_q, query, post=None, body=b"", ctype=""):
    p = path_q.path

    # ---- 保留接口 ----
    if p == "/api/logs":
        lines = int(query.get("lines", ["300"])[0] or 300)
        lp = newest_log_path()
        if not lp:
            return {"error": "未找到运行日志", "path": ""}
        return {"path": lp, "text": tail_text(lp, lines)}
    if p == "/api/overview":
        return audio_overview(load_config())
    if p == "/api/asr":
        return asr_overview()
    if p == "/api/asr/download":
        model = (post or {}).get("model", "base")
        with _asr_lock:
            if _asr_active["running"]:
                return {"started": False, "busy": _asr_active["model"]}
            _asr_active.update(running=True, model=model, error="")
        threading.Thread(target=_asr_download_worker, args=(model,),
                         daemon=True).start()
        return {"started": True, "model": model}
    if p == "/api/asr/status":
        with _asr_lock:
            msgs = list(_asr_msgs[-80:])
            act = dict(_asr_active)
        return {"msgs": msgs, "active": act}
    if p == "/api/tts/generate":
        with _tts_lock:
            if _tts_active["running"]:
                return {"started": False, "busy": True}
            _tts_active.update(running=True, error="")
        threading.Thread(target=_tts_generate_worker, daemon=True).start()
        return {"started": True}
    if p == "/api/tts/status":
        with _tts_lock:
            msgs = list(_tts_msgs[-100:])
            act = dict(_tts_active)
        return {"msgs": msgs, "active": act}
    if p == "/api/version":
        return {"version": VERSION, "root": ROOT}

    # ---- 平台 / 连接设备 ----
    if p == "/api/platforms":
        from ui.connect_page import PLATFORM_CONFIG
        return {"connect": list(PLATFORM_CONFIG.keys()),
                "state": R.STATE}
    if p == "/api/connect/status":
        j = R.job_json("connect")
        j["state"] = R.STATE
        return j
    if p == "/api/connect/set-platform":
        platform = (post or {}).get("platform", "")
        if platform and platform in _connect_platforms():
            R.STATE["platform"] = platform
            return {"ok": True, "platform": platform}
        return {"error": f"未知平台: {platform}"}
    if p == "/api/connect/start":
        post = post or {}
        platform = post.get("platform") or R.STATE["platform"]
        action = post.get("action", "auto")
        if action not in ("auto", "check"):
            return {"error": f"未知动作: {action}"}
        j = R.job("connect")
        if j.running:
            return {"started": False, "busy": True}
        return R.start_connect(platform, action)

    # ---- 配置读写 ----
    if p == "/api/config":
        return load_config()
    if p == "/api/config/save":
        data = load_config()
        new = post or {}
        for key in ("work_dir", "car", "wakeup_word", "voice_provider",
                    "voice", "tts_style"):
            if key in new and new[key] is not None:
                data[key] = str(new[key]).strip()
        if "queries" in new and isinstance(new["queries"], dict):
            data["queries"] = {
                k: [str(q) for q in v if str(q).strip()]
                for k, v in new["queries"].items() if v}
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            # v1.6.6: 镜像一份到 <work_dir>/audio/config.json（与 TTS 音频同路径）
            _mirror_config_audio(data)
            return {"ok": True, "config": data}
        except Exception as e:          # noqa: BLE001
            return {"error": f"保存失败: {e}"}
    if p == "/api/voices":
        return R.voices_overview()

    # ---- 执行测试 ----
    if p == "/api/run/meta":
        return R.run_meta()
    if p == "/api/run/fetch":
        post = post or {}
        try:
            return R.fetch_from_car(post.get("type", "version"),
                                    post.get("platform") or R.STATE["platform"])
        except Exception as e:          # noqa: BLE001
            return {"ok": False, "type": post.get("type", ""),
                    "msg": str(e), "value": "", "pids": []}
    if p == "/api/run/start":
        j = R.job("run")
        if j.running:
            return {"started": False, "busy": True}
        try:
            return R.start_run(post or {})
        except Exception as e:          # noqa: BLE001
            return {"started": False, "error": str(e)}
    if p == "/api/run/stop":
        return R.stop_run()
    if p == "/api/run/status":
        return R.job_json("run")

    # ---- 日志测试 ----
    if p == "/api/logtest/meta":
        try:
            return R.logtest_meta()
        except Exception as e:          # noqa: BLE001
            return {"error": str(e)}
    if p == "/api/logtest/start":
        j = R.job("logtest")
        if j.running:
            return {"started": False, "busy": True}
        try:
            return R.start_logtest(post or {})
        except Exception as e:          # noqa: BLE001
            return {"started": False, "error": str(e)}
    if p == "/api/logtest/control":
        post = post or {}
        return R.logtest_control(post.get("cmd", ""))
    if p == "/api/logtest/status":
        return R.job_json("logtest")

    # ---- 响应时延分析 ----
    if p == "/api/analyze/files":
        try:
            return R.analyze_files()
        except Exception as e:          # noqa: BLE001
            return {"error": str(e)}
    if p == "/api/analyze/upload":
        fields, files = _parse_multipart(body or b"", ctype)
        kind = fields.get("kind", "media")
        if kind not in ("media", "template", "wake"):
            return {"error": f"未知类型: {kind}"}
        if not files:
            return {"error": "未收到文件（字段名需为 file）"}
        f = files[0]
        path = R._safe_upload(kind, f["filename"], f["content"])
        return {"ok": True, "kind": kind, "path": path,
                "name": os.path.basename(path)}
    if p == "/api/analyze/start":
        j = R.job("analyze")
        if j.running:
            return {"started": False, "busy": True}
        try:
            return R.start_analyze(post or {})
        except Exception as e:          # noqa: BLE001
            return {"started": False, "error": str(e)}
    if p == "/api/analyze/status":
        j = R.job_json("analyze")
        j["result"] = R.job("analyze").result
        return j
    if p == "/api/analyze/fix":
        post = post or {}
        return R.analyze_fix(int(post.get("row", -1)),
                             post.get("cmd_id"), post.get("reply_id"))
    if p == "/api/analyze/cell":
        post = post or {}
        return R.analyze_set_cell(int(post.get("row", -1)),
                                  post.get("col", "b"), post.get("val"))
    if p == "/api/analyze/excel":
        post = post or {}
        return R.analyze_write_excel(int(post.get("pass_no") or 1))

    return {"error": f"未知接口: {p}"}


def _connect_platforms():
    try:
        from ui.connect_page import PLATFORM_CONFIG
        return list(PLATFORM_CONFIG.keys())
    except Exception:
        return []


class Handler(BaseHTTPRequestHandler):
    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/"):
            q = parse_qs(parsed.query)
            try:
                self._json(handle_api(parsed, q))
            except Exception as e:      # noqa: BLE001
                self._json({"error": str(e)}, 500)
            return
        name = parsed.path.lstrip("/") or "index.html"
        if "/" in name or ".." in name:
            name = "index.html"
        fp = os.path.join(STATIC, name)
        if not os.path.exists(fp):
            fp = os.path.join(STATIC, "index.html")
        ctype = ("text/html; charset=utf-8" if fp.endswith(".html")
                 else "application/javascript; charset=utf-8"
                 if fp.endswith(".js") else "text/css; charset=utf-8")
        try:
            with open(fp, "rb") as f:
                body = f.read()
        except Exception:
            body = b""
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            ln = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(ln) if ln else b""
        except Exception:
            body = b""
        ctype = self.headers.get("Content-Type", "")
        post = {}
        if "multipart/form-data" in ctype:
            pass                      # handle_api 内部解析
        elif body:
            try:
                post = json.loads(body.decode("utf-8") or "{}")
            except Exception:
                post = {}
        if parsed.path.startswith("/api/"):
            try:
                self._json(handle_api(parsed, {}, post, body, ctype))
            except Exception as e:      # noqa: BLE001
                self._json({"error": str(e)}, 500)
            return
        self._json({"error": "未知接口"}, 404)


def main():
    if not os.path.exists(STATIC):
        os.makedirs(STATIC, exist_ok=True)
    print("=" * 58)
    print(f" NOMI_Test_Tool 浏览器控制台 {VERSION}")
    print(f" 项目目录: {ROOT}")
    print(f" 请在浏览器打开: http://127.0.0.1:{PORT}")
    print(" 支持: 连接设备 / 执行测试 / 日志测试 / 端到端耗时 / TTS / ASR / 日志")
    print(" 长任务在后台执行，页面可随时刷新（任务不中断）")
    print(" (Ctrl+C 停止)")
    print("=" * 58)
    httpd = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
