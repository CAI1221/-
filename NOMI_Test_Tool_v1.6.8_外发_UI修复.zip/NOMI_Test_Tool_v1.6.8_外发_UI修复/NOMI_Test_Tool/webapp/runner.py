# webapp/runner.py - 浏览器控制台后台任务容器（v1.6.5）
#
# 把桌面版五个页签的长任务（连接设备/执行测试/日志测试/响应时延/TTS）
# 以 headless 方式跑在 webapp 进程的后台线程里。
#
# 复用方式: 桌面引擎均为 QThread 子类，但 run() 内部只用 time.sleep +
# pyqtSignal。PyQt 信号连接普通 Python 函数是直连（DirectConnection），
# 不需要 QApplication / 事件循环，因此直接 w.run() 同步执行即可
# （webapp 早期版本已用 TtsWorker.run() 验证此模式）。
# 长任务放到 threading.Thread 后台线程，绝不占用 HTTP 处理线程。
import os
import sys
import threading
import time
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# 上传/选择文件的落盘目录（分析/模板/唤醒词）
UPLOAD_ROOT = os.path.join(ROOT, "webapp_uploads")
for _sub in ("media", "template", "wake"):
    try:
        os.makedirs(os.path.join(UPLOAD_ROOT, _sub), exist_ok=True)
    except OSError:
        pass

CONFIG_PATH = os.path.join(ROOT, "config.json")

# 当前“连接平台”（浏览器选定，决定 SSH/ADB 参数与执行测试页联动）
STATE = {"platform": "NT3.0-NIO / ALPS", "adb_ok": False, "ssh_ok": False,
         "msg": "", "update_time": ""}

# ---------------- 通用 Job ----------------
class Job:
    """一个可轮询的后台任务（每类同时只跑一个）"""

    def __init__(self, kind):
        self.kind = kind
        self.running = False
        self.done = False
        self.ok = False
        self.error = ""
        self.result = None          # 引擎产物（如分析结果/汇总）
        self.engine = None          # 引擎引用（供 stop/resume）
        self.waiting = ""           # 人工等待标记（日志测试 [人工] 模块）
        self._logs = []
        self._lock = threading.Lock()
        self.started_at = datetime.now().strftime("%H:%M:%S")

    def log(self, msg):
        with self._lock:
            self._logs.append(str(msg))
            if len(self._logs) > 800:
                del self._logs[:-800]

    def snapshot(self, n=500):
        with self._lock:
            return list(self._logs[-n:])


_JOBS = {}


def job(kind):
    j = _JOBS.get(kind)
    if j is None:
        j = Job(kind)
        _JOBS[kind] = j
    return j


def _new_job(kind):
    j = Job(kind)
    _JOBS[kind] = j
    return j


def _spawn(j, fn):
    j.running = True
    j.done = False
    j.ok = False
    j.error = ""
    j.result = None
    j.waiting = ""

    def runner():
        try:
            fn(j)
        except Exception as e:           # noqa: BLE001
            import traceback
            j.log(f"[任务异常] {e}")
            j.log(traceback.format_exc())
            j.error = str(e)
            j.ok = False
        finally:
            j.running = False
            j.done = True
    threading.Thread(target=runner, daemon=True, name=f"job-{j.kind}").start()


def job_json(kind):
    j = job(kind)
    return {"running": j.running, "done": j.done, "ok": j.ok,
            "error": j.error, "waiting": j.waiting,
            "started_at": j.started_at, "logs": j.snapshot()}


# ---------------- config.json 读写 ----------------
def load_config():
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json_load(f)
    except Exception:
        return {}


def json_load(f):
    import json
    return json.load(f)


def save_config(data):
    import json
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ---------------- 平台联动 ----------------
# 日志测试平台 -> 连接设备平台名（与桌面 log_test_page.PLATFORM_TO_CONNECT 一致）
LOGTEST_TO_CONNECT = {
    "NT3.0-NIO": "NT3.0-NIO / ALPS",
    "NT2.5-NIO": "NT2.5",
    "NT3.0-ALPS": "NT3.0-NIO / ALPS",
}


def _connect_cfg(platform):
    """延迟导入桌面连接配置，返回该平台的 PLATFORM_CONFIG 项"""
    from ui.connect_page import PLATFORM_CONFIG
    cfg = dict(PLATFORM_CONFIG.get(platform, {}))
    if not cfg:
        raise RuntimeError(f"未知平台: {platform}")
    return cfg


def _ssh_from_cfg(cfg):
    return {"ssh_host": cfg.get("qnx_host", "192.0.2.2"),
            "ssh_user": cfg.get("qnx_user", "root"),
            "ssh_password": cfg.get("qnx_password", "CHANGE_ME")}


# ==================== 连接设备 ====================
def start_connect(platform, action):
    from ui.connect_page import (AutoConnectWorker, CheckWorker,
                                 begin_conn_log, conn_log_push)
    cfg = _connect_cfg(platform)
    STATE["platform"] = platform
    STATE["msg"] = f"{datetime.now().strftime('%H:%M:%S')} 正在{('自动连接' if action == 'auto' else '手动检测')}…"
    STATE["update_time"] = datetime.now().strftime("%H:%M:%S")
    j = _new_job("connect")
    begin_conn_log()

    def fn(_j):
        worker = AutoConnectWorker(platform) if action == "auto" else \
            CheckWorker(platform)
        _j.engine = worker

        def cb(msg):
            _j.log(msg)
            conn_log_push(msg)            # 进“最近连接记录”，带入测试日志

        def done(ssh_ok, adb_ok):
            STATE["adb_ok"] = bool(adb_ok)
            STATE["ssh_ok"] = bool(ssh_ok)
            STATE["update_time"] = datetime.now().strftime("%H:%M:%S")
            STATE["msg"] = (f"ADB {'正常' if adb_ok else '异常'} / "
                            f"SSH {'正常' if ssh_ok else '异常'}")
            _j.result = {"adb_ok": adb_ok, "ssh_ok": ssh_ok}
            _j.ok = adb_ok or ssh_ok
        worker.log_signal.connect(cb)
        if action == "auto":
            worker.finished_signal.connect(done)
        else:
            worker.status_signal.connect(done)
        worker.run()
        if not _j.result:
            _j.ok = False
            _j.error = "任务未返回结果"
    _spawn(j, fn)
    return {"started": True, "platform": platform, "action": action}


# ==================== 执行测试 ====================
def run_meta():
    from core.constants import CAR_WAKEUP_WORDS, SCENARIO_KEYS, SCENARIO_NAMES
    from ui.connect_page import PLATFORM_CONFIG
    cfg = load_config()
    return {"cars": list(CAR_WAKEUP_WORDS.keys()),
            "wake_words": CAR_WAKEUP_WORDS,
            "scenarios": SCENARIO_KEYS,
            "scenario_names": SCENARIO_NAMES,
            "platforms": list(PLATFORM_CONFIG.keys()),
            "current_platform": STATE["platform"],
            "work_dir": cfg.get("work_dir", "")}


def fetch_from_car(fetch_type, platform):
    """同步抓取长版本 / speech PID（SSH，耗时数秒，HTTP 线程直接等待）"""
    from ui.run_page import FetchLongVersionThread, FetchSpeechPidThread
    cfg = _connect_cfg(platform)
    ssh = _ssh_from_cfg(cfg)
    out = {"type": fetch_type, "ok": False, "msg": "", "value": "",
           "pids": []}
    if fetch_type == "version":
        w = FetchLongVersionThread(ssh)
        w.done.connect(lambda ok, val: (out.update(ok=ok, value=val)))
        w.run()
        out["msg"] = "获取成功" if out["ok"] else (out.get("value") or "获取失败")
        return out
    if fetch_type == "speech_pid":
        w = FetchSpeechPidThread(ssh)
        w.done.connect(lambda ok, m, pids: out.update(ok=ok, msg=m, pids=pids))
        w.run()
        return out
    out["msg"] = f"未知类型: {fetch_type}"
    return out


def _validate_session_name(name):
    bad = '\\/:*?"<>|'
    for c in bad:
        if c in name:
            return f"总文件夹名含非法字符 ({bad})"
    return ""


def start_run(p):
    cfg = load_config()
    output_root = (cfg.get("work_dir") or "").strip()
    if not output_root or not os.path.isdir(output_root):
        raise RuntimeError("输出目录无效，请先在「TTS / 音频」页设置 work_dir 并保存")
    platform = p.get("platform") or STATE["platform"]
    car = (p.get("car") or "").strip()
    short_version = (p.get("short_version") or "").strip()
    scenarios = p.get("scenarios") or []
    if not car:
        raise RuntimeError("请选择车型")
    if not short_version:
        raise RuntimeError("请填写短版本号（如 NT3.0-160-daily）")
    if not scenarios:
        raise RuntimeError("请至少勾选一个测试场景")
    session_name = (p.get("session_name") or "").strip()
    err = _validate_session_name(session_name)
    if err:
        raise RuntimeError(err)
    # 互斥: run 与 logtest 共享 adb/声卡，不能同时跑
    lt = job("logtest")
    if lt.running:
        raise RuntimeError("「日志测试」正在运行，请先停止后再开始执行测试")
    collect_mem = bool(p.get("collect_mem"))
    if collect_mem:
        script = os.path.join(output_root, "mem_command_nomi.sh")
        if not os.path.exists(script):
            raise RuntimeError("已勾选 MEM 采集，但输出目录缺少 mem_command_nomi.sh，"
                               "请先上传（TTS / 音频页）")
        from core.executors import LocalExecutor
        if not LocalExecutor.find_bash():
            raise RuntimeError("MEM 脚本需要 bash，未检测到，请安装 Git for Windows")
    # 车型 -> 唤醒词（允许配置的自定义唤醒词覆盖）
    from core.constants import CAR_WAKEUP_WORDS
    wakeup = (p.get("wakeup_word") or "").strip() or \
        CAR_WAKEUP_WORDS.get(car, "")
    if not wakeup:
        raise RuntimeError("无法确定唤醒词")
    from core import constants
    from core.test_engine import TestConfig
    cc = _connect_cfg(platform)
    ssh = _ssh_from_cfg(cc)
    if not session_name:
        session_name = f"{short_version}_{datetime.now().strftime('%Y%m%d_%H%M')}"
    session_dir = os.path.join(output_root, session_name)
    try:
        os.makedirs(session_dir, exist_ok=True)
    except OSError as e:
        raise RuntimeError(f"无法创建产物目录: {e}")
    config = TestConfig(
        car=car, wakeup_word=wakeup, short_version=short_version,
        long_version=(p.get("long_version") or "").strip(),
        nomi_pid=(p.get("nomi_pid") or "").strip(),
        speech_pid=(p.get("speech_pid") or "").strip(),
        collect_mem=collect_mem,
        collect_cpu=bool(p.get("collect_cpu")),
        collect_top2=bool(p.get("collect_top2")),
        is_b_test=bool(p.get("is_b_test")),
        scenarios=scenarios,
        output_root=output_root, session_dir=session_dir,
        queries=cfg.get("queries") or {},
        ssh_host=ssh["ssh_host"], ssh_user=ssh["ssh_user"],
        ssh_password=ssh["ssh_password"],
        top2_path=(p.get("top2_path") or "").strip(),
    )
    j = _new_job("run")

    def fn(_j):
        from core.test_engine import TestEngine
        engine = TestEngine(config)
        _j.engine = engine

        def done(ok, msg):
            _j.result = {"ok": ok, "summary": msg}

        engine.log_signal.connect(_j.log)
        engine.progress_signal.connect(
            lambda cur, total: _j.log(f"[进度] {cur}/{total}"))
        engine.finished_signal.connect(done)
        # 带入最近连接/检测记录（与桌面一致）
        try:
            from ui.connect_page import conn_log_snapshot
            snap = conn_log_snapshot()
            if snap:
                _j.log("---- 最近连接/检测记录（连接设备页） ----")
                _j.log("\n".join("  " + ln for ln in snap))
        except Exception:
            pass
        engine.run()
        if _j.result and _j.result.get("ok"):
            _j.ok = True
            _j.log(f"[引擎结束] {_j.result.get('summary')}")
        else:
            _j.ok = False
            _j.error = (_j.result or {}).get("summary") or "测试未正常完成"
    _spawn(j, fn)
    return {"started": True, "session_dir": session_dir,
            "session_name": session_name}


def stop_run():
    j = job("run")
    if j.engine is not None:
        try:
            j.engine.stop()
            return {"stopping": True}
        except Exception as e:
            return {"stopping": False, "error": str(e)}
    return {"stopping": False, "error": "没有正在运行的执行测试"}


# ==================== 日志测试 ====================
def logtest_meta():
    from core.constants import LOG_TEST_PLATFORMS, LOG_TEST_PLATFORM_TIPS
    from core.log_test_engine import load_module_config
    out = {"platforms": list(LOG_TEST_PLATFORMS.keys()),
           "tips": LOG_TEST_PLATFORM_TIPS,
           "scrcpy": detect_scrcpy()}
    mods = {}
    for plat, fn in LOG_TEST_PLATFORMS.items():
        m = load_module_config(ROOT, plat) or {}
        mods[plat] = {
            "wakeup_word": m.get("wakeup_word", ""),
            "modules": m.get("modules", []),
        }
    out["modules"] = mods
    return out


def detect_scrcpy():
    import shutil
    from core.constants import SCRCPY_CANDIDATES
    for cand in SCRCPY_CANDIDATES:
        try:
            if cand == "scrcpy" or not os.path.isabs(cand):
                found = shutil.which("scrcpy") or shutil.which("scrcpy.exe")
                if found:
                    return found
                continue
            if os.path.exists(cand):
                return cand
        except Exception:
            continue
    return ""


def start_logtest(p):
    cfg = load_config()
    output_root = (cfg.get("work_dir") or "").strip()
    if not output_root or not os.path.isdir(output_root):
        raise RuntimeError("输出目录无效，请先在「TTS / 音频」页设置 work_dir 并保存")
    platform = (p.get("platform") or "").strip()
    names = (p.get("modules") or [])          # 选中的模块名列表
    if not platform:
        raise RuntimeError("请选择日志测试平台")
    if not names:
        raise RuntimeError("请至少勾选一个模块")
    rj = job("run")
    if rj.running:
        raise RuntimeError("「执行测试」正在运行，请先停止后再开始日志测试")
    from core.log_test_engine import LogTestConfig, load_module_config
    plat_cfg = load_module_config(ROOT, platform) or {}
    wakeup = (plat_cfg.get("wakeup_word") or "").strip()
    all_mods = plat_cfg.get("modules", []) or []
    sel = [dict(m) for m in all_mods if m.get("name") in names]
    missing = [n for n in names if n not in {m.get("name") for m in all_mods}]
    if missing:
        raise RuntimeError(f"模块配置缺失: {', '.join(missing)}")
    seconds = int(p.get("seconds") or 60)
    trial = bool(p.get("trial"))
    if not trial:
        for m in sel:
            m["seconds"] = seconds
    # 连接参数: 日志测试平台 -> 连接设备平台
    cplat = LOGTEST_TO_CONNECT.get(platform, STATE["platform"])
    ssh = _ssh_from_cfg(_connect_cfg(cplat))
    version = (p.get("version") or "").strip()
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    session_name = (p.get("session_name") or "").strip()
    if not session_name:
        base = "日志测试" + (f"_{version}" if version else "") + f"_{platform}_{ts}"
        session_name = base
    err = _validate_session_name(session_name)
    if err:
        raise RuntimeError(err)
    session_dir = os.path.join(output_root, session_name)
    os.makedirs(session_dir, exist_ok=True)
    config = LogTestConfig(
        platform=platform, wakeup_word=wakeup,
        modules=sel, output_root=output_root, session_dir=session_dir,
        record_video=bool(p.get("record_video")) and not trial,
        scrcpy_path=(p.get("scrcpy_path") or detect_scrcpy()),
        clear_logs_before=bool(p.get("clear_logs_before")) and not trial,
        pull_logd_after=bool(p.get("pull_logd_after")) and not trial,
        pull_slog_after=bool(p.get("pull_slog_after")) and not trial,
        voice_enabled=bool(p.get("voice_enabled")),
        trial_run=trial,
        ssh_host=ssh["ssh_host"], ssh_user=ssh["ssh_user"],
        ssh_password=ssh["ssh_password"])
    j = _new_job("logtest")

    def fn(_j):
        from core.log_test_engine import LogTestEngine
        engine = LogTestEngine(config)
        if plat_cfg.get("apps"):
            engine.set_apps(plat_cfg.get("apps", {}))
        _j.engine = engine
        engine.log_signal.connect(_j.log)
        engine.progress_signal.connect(
            lambda cur, total: _j.log(f"[进度] {cur}/{total}"))
        engine.module_signal.connect(
            lambda name: setattr(_j, "waiting", name or ""))
        engine.pause_signal.connect(
            lambda name: (_j.log(f"[等待人工] 模块 [{name}] 完成车机操作后点击「继续」"),
                          setattr(_j, "waiting", f"pause:{name}")))

        def done(ok, msg):
            _j.ok = bool(ok)
            _j.result = {"ok": bool(ok), "summary": msg}
        engine.finished_signal.connect(done)
        engine.run()
        _j.waiting = ""
        if _j.result:
            _j.log(f"[引擎结束] {_j.result.get('summary')}")
            _j.ok = bool(_j.result.get("ok"))
            if not _j.ok:
                _j.error = _j.result.get("summary") or "日志测试未正常完成"
    _spawn(j, fn)
    return {"started": True, "session_dir": session_dir,
            "session_name": session_name, "trial": trial}


def logtest_control(cmd):
    j = job("logtest")
    if j.engine is None:
        return {"error": "没有运行中的日志测试"}
    try:
        if cmd == "stop":
            j.engine.stop()
            return {"ok": True}
        if cmd == "resume":
            j.waiting = ""
            j.engine.resume()
            return {"ok": True}
    except Exception as e:                    # noqa: BLE001
        return {"error": str(e)}
    return {"error": f"未知命令: {cmd}"}


# ==================== 响应时延分析 ====================
def upload_target(kind):
    return os.path.join(UPLOAD_ROOT, kind)


def _safe_upload(kind, filename, body):
    base = os.path.basename(filename or "upload.bin")
    base = "".join(c for c in base if c not in '\\/:*?"<>|').strip() or "file.bin"
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(upload_target(kind), f"{ts}_{base}")
    with open(path, "wb") as f:
        f.write(body)
    return path


def analyze_files():
    cfg = load_config()
    wd = cfg.get("work_dir") or ""
    media = _walk(os.path.join(UPLOAD_ROOT, "media"),
                  (".wav", ".mp3", ".mp4", ".m4a", ".flac"))
    tpl = _walk(os.path.join(UPLOAD_ROOT, "template"), (".xlsx",))
    wake = _walk(os.path.join(UPLOAD_ROOT, "wake"), (".wav", ".mp3"))
    # 工作区可选文件（顶层 + audio 目录，避免深层扫描过慢）
    if wd and os.path.isdir(wd):
        media += _walk(wd, (".wav", ".mp3", ".mp4", ".m4a", ".flac"),
                       depth=1)
        tpl += _walk(wd, (".xlsx",), depth=1)
        audio = os.path.join(wd, "audio")
        if os.path.isdir(audio):
            wake += _walk(audio, (".wav", ".mp3"))
    return {"media": media, "templates": tpl, "wake": wake,
            "default_wake": _default_wake_path(cfg)}


def _default_wake_path(cfg):
    wd = cfg.get("work_dir") or ""
    if not wd:
        return ""
    word = (cfg.get("wakeup_word") or "HI NOMI").strip()
    audio = os.path.join(wd, "audio")
    if not os.path.isdir(audio):
        return ""
    for f in os.listdir(audio):
        if os.path.splitext(f)[0] == word and \
                f.lower().endswith((".wav", ".mp3")):
            return os.path.join(audio, f)
    return ""


def _walk(d, exts, depth=0):
    out = []
    if not d or not os.path.isdir(d):
        return out
    for name in sorted(os.listdir(d)):
        p = os.path.join(d, name)
        if os.path.isfile(p) and name.lower().endswith(exts):
            out.append({"name": name, "path": p,
                        "size": _fmt_size(os.path.getsize(p)),
                        "mtime": datetime.fromtimestamp(
                            os.path.getmtime(p)).strftime("%m-%d %H:%M")})
    return out


def _fmt_size(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f}{u}"
        n /= 1024
    return f"{n:.1f}TB"


def start_analyze(p):
    media = (p.get("media_path") or "").strip()
    template = (p.get("template_path") or "").strip()
    if not media or not os.path.exists(media):
        raise RuntimeError("请选择（或上传）待分析的录音/视频文件")
    if not template or not os.path.exists(template):
        raise RuntimeError("请选择（或上传）Query 模板 Excel")
    wake = (p.get("wake_path") or "").strip()
    if wake and not os.path.exists(wake):
        raise RuntimeError("唤醒词模板音频不存在: " + wake)
    j = _new_job("analyze")

    def fn(_j):
        # 分析（含 faster-whisper/ctranslate2 加载）放到独立子进程：
        # 本机 PyQt 与 ctranslate2 同进程会 native crash，子进程绝不 import Qt
        import json as _json
        import subprocess
        import sys
        import tempfile
        _args = {"media_path": media, "template_path": template,
                 "model_name": (p.get("model_name") or "base"),
                 "language": (p.get("language") or "auto"),
                 "wake_path": wake, "wake_text": (p.get("wake_text") or ""),
                 "gap_ms": int(p.get("gap_ms") or 150)}
        fd1, args_path = tempfile.mkstemp(suffix=".json", prefix="nomian_")
        with os.fdopen(fd1, "w", encoding="utf-8") as f:
            _json.dump(_args, f, ensure_ascii=False)
        fd2, res_path = tempfile.mkstemp(suffix=".json", prefix="nomian_res")
        os.close(fd2)
        worker = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "analyze_worker.py")
        _j.log("启动 ASR 分析子进程（不占用服务进程，避免 DLL 冲突/卡顿）...")
        try:
            proc = subprocess.Popen(
                [sys.executable, "-u", worker, args_path, res_path],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace")
        except Exception as e:              # noqa: BLE001
            _j.error = f"子进程启动失败: {e}"
            _j.ok = False
            _cleanup(args_path, res_path)
            return

        def pump():
            assert proc.stdout is not None
            for line in proc.stdout:
                line = line.rstrip("\n")
                if line:
                    _j.log(line)
            proc.wait()
        import threading as _th
        t = _th.Thread(target=pump, daemon=True, name="analyze-reader")
        t.start()
        t.join()
        rc = proc.returncode
        if rc == 0 and os.path.exists(res_path):
            try:
                with open(res_path, "r", encoding="utf-8") as f:
                    _j.result = _json.load(f)
                _j.ok = True
            except Exception as e:          # noqa: BLE001
                _j.ok = False
                _j.error = f"子进程结果解析失败: {e}"
        else:
            _j.ok = False
            _j.error = f"分析子进程退出码 {rc}（详见上方日志）"
        _cleanup(args_path, res_path)
    _spawn(j, fn)
    return {"started": True}


def _cleanup(*paths):
    import shutil
    for p in paths:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


def _jsonable(obj):
    import numpy as np

    def conv(o):
        if isinstance(o, dict):
            return {k: conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, float):
            return None if o != o else o        # NaN -> null
        return o
    return conv(obj)


def analyze_fix(row_idx, cmd_id, reply_id):
    """按人工选择的语音段重算一行（对应桌面 _recompute_row 纯逻辑）"""
    j = job("analyze")
    res = j.result
    if not res:
        return {"error": "尚无分析结果"}
    results = res.get("results") or []
    if not (0 <= row_idx < len(results)):
        return {"error": "行号越界"}
    units = res.get("units") or []
    cal = float(res.get("cal_s") or 0.0) * 1000.0
    unit_by_id = {u["index"]: u for u in units}
    row = results[row_idx]
    cmd_u = unit_by_id.get(int(cmd_id)) if cmd_id not in (None, "", -1) \
        else None
    if cmd_u is None:
        return {"error": "请选择正确的指令语音段"}
    row["cmd_unit_ids"] = [cmd_u["index"]]
    row["cmd_start_s"] = cmd_u["start_s"]
    row["cmd_end_s"] = cmd_u["end_s"]
    row["note"] = "人工修正"
    reply_u = None
    if reply_id not in (None, "", -1):
        reply_u = unit_by_id.get(int(reply_id))
    if reply_u is None:
        for u in units:
            if u["start_s"] > cmd_u["end_s"] + 0.005:
                reply_u = u
                break
    if reply_u is not None:
        row["reply_unit_id"] = reply_u["index"]
        row["reply_start_s"] = reply_u["start_s"]
        row["b_ms"] = int(round((reply_u["start_s"] - cmd_u["end_s"])
                                * 1000.0 - cal))
        if row["b_ms"] < -150 or row["b_ms"] > 12000:
            row["status"] = "warn"
            row["note"] = "时延值异常，请核对端点"
        else:
            row["status"] = "ok"
    else:
        row["b_ms"] = None
        row["status"] = "warn"
        row["note"] = "指令后未找到回复段"
    return {"row": row_idx, "result": _jsonable(row)}


def analyze_set_cell(row_idx, col, val):
    """直接手工填值 col: a|b"""
    j = job("analyze")
    res = j.result
    if not res:
        return {"error": "尚无分析结果"}
    results = res.get("results") or []
    if not (0 <= row_idx < len(results)):
        return {"error": "行号越界"}
    row = results[row_idx]
    try:
        v = int(float(val)) if str(val).strip() else None
    except ValueError:
        return {"error": "请输入整数毫秒或留空"}
    if col == "a":
        row["a_ms"] = v
    else:
        row["b_ms"] = v
    row["status"] = "ok" if row.get("b_ms") is not None else "warn"
    row["note"] = "人工填值"
    return {"row": row_idx, "result": _jsonable(row)}


def analyze_write_excel(pass_no):
    """全部行 ok 后写入模板 Excel（对应桌面 _write_excel）"""
    j = job("analyze")
    res = j.result
    if not res:
        return {"error": "尚无分析结果"}
    results = res.get("results") or []
    bad = [i for i, r in enumerate(results) if r["status"] != "ok"]
    if bad:
        return {"error": f"仍有 {len(bad)} 行未确认（橙/红），请先修正: "
                         + "、".join(str(i + 1) for i in bad[:20])}
    template = res.get("template_path") or ""
    if not template or not os.path.exists(template):
        return {"error": "模板文件不存在，请重新选择模板"}
    try:
        from core.latency_excel import LatencyExcel
        xl = LatencyExcel(template)
    except Exception as e:                 # noqa: BLE001
        return {"error": f"模板打开失败: {e}"}
    values = [{"a_ms": r.get("a_ms"), "b_ms": r.get("b_ms")}
              for r in results]
    if len(values) > len(xl.all_rows):
        return {"error": "结果行数超过模板 Query 行数，请检查模板"}
    xl.fill_pass(int(pass_no or 1), values)
    xl.write_summary()
    out = xl.save()
    n_filled = sum(1 for v in values
                   if v["a_ms"] is not None or v["b_ms"] is not None)
    return {"ok": True, "path": out,
            "filled": n_filled, "pass_no": int(pass_no or 1)}


# ==================== TTS（保留 + 缺省唤醒生成入口） ====================
def voices_overview():
    import core.tts as tts
    return {"groups": tts.VOICE_GROUPS,
            "styles": tts.VOICE_STYLES,
            "style_labels": tts.STYLE_LABELS,
            "default_voice": tts.DEFAULT_VOICE,
            "default_type": tts.DEFAULT_VOICE_TYPE}
